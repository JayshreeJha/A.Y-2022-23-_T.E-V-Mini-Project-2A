<!DOCTYPE html>
<html>
<head>
	<title>LOGIN</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<style>
            body {
               
                background-image: url('https://th.bing.com/th/id/R.e4f5d15bb2208620899423938e4ade4f?rik=ftC7vwi247lwIg&riu=http%3a%2f%2fgetwallpapers.com%2fwallpaper%2ffull%2f1%2f4%2fc%2f373861.jpg&ehk=2%2fgv9KnVECKMkSANRa79wfuYEnIqAaJniAhcQdzooec%3d&risl=&pid=ImgRaw&r=0');
                
                background-repeat: no-repeat;
                background-size: 100% 100%; 

            }
			</style>
<body>
     <form action="login.php" method="post">
     	<h2>LOGIN</h2>
     	<?php if (isset($_GET['error'])) { ?>
     		<p class="error"><?php echo $_GET['error']; ?></p>
     	<?php } ?>
     	<label>User Name</label>
     	<input type="text" name="uname" placeholder="User Name"><br>

     	<label>Password</label>
     	<input type="password" name="password" placeholder="Password"><br>

     	<button type="submit">Login</button>
          <a href="signup.php" class="ca">Create an account</a>
     </form>
</body>
</html>