
<?php 
session_start();

if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

 ?>
<!DOCTYPE html>
<html>
<head>
	<title>HOME</title>

  <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="sty.css">
</head>
<body style="background:black;">


<<nav class="navbar navbar-expand-lg bg-light">
  <div class="container-fluid">
  
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Genre
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="action.html">Action</a></li>
            <li><a class="dropdown-item" href="darma.html">Darma</a></li>
            
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Language
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="action.html">Hindi</a></li>
            <li><a class="dropdown-item" href="english.html">English</a></li>
            
            <li><a class="dropdown-item" href="telgu.html">Telugu</a></li>
            
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="contactus.html">Contact Us</a>
        </li>
        <li>
          <a class="nav-link" href="feedback.html">Feeback</a>
        </li>
      </ul>
      
    </div>
  </div>
</nav>
  <main>

    <div class="headline">
      <img src="./images/logo-name.png" alt="">

      
  </div>
  

 

   
    <h1 style="font-size:60px; color:red; text-align:center; "class="alert alert-light font-style: New Time Roman;" role="alert">BigScreen  </h1>
    \<!-- Carousel -->
    <h2 class="text-center section-heading" style="color: white;">Now Upcoming <i class="fas fa-compact-disc"></i></h2>
      
<div id="demo" class="carousel slide" data-bs-ride="carousel">

<!-- Indicators/dots -->
<div class="carousel-indicators">
  <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active"></button>
  <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
  <button type="button" data-bs-target="#demo" data-bs-slide-to="2"></button>
</div>

<!-- The slideshow/carousel -->
<div class="carousel-inner">
  <div class="carousel-item active">
    <center>
    <img src="https://th.bing.com/th/id/OIP.KNXuZ7CI-z-jWBSXewq20wHaGL?pid=ImgDet&rs=1" alt="Los Angeles" class="d-block w-100" style="width:10px; height:350px;">
</center>
  </div>
  <div class="carousel-item">
    <img src="https://th.bing.com/th/id/OIP.w5yfrTQcJGzTVNmEVdYjuAHaEK?pid=ImgDet&rs=1" alt="Chicago" class="d-block w-100" style="width:10px; height:350px;">
  </div>
  <div class="carousel-item">
    <img src="https://th.bing.com/th/id/OIP.IbgjyTA1JAsBmkJHVYd3zQHaD4?pid=ImgDet&rs=1" alt="New York" class="d-block w-100" style="width:10px; height:350px;">
  </div>
</div>

<!-- Left and right controls/icons -->
<button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
  <span class="carousel-control-prev-icon"></span>
</button>
<button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
  <span class="carousel-control-next-icon"></span>
</button>
</div>
</div>

<section class="main-section">
      <h2 class="text-center section-heading" style="color: white;">Now Showing <i class="fas fa-compact-disc"></i></h2>
      <article class="now-showing-movie">
        <h3 class="d-none">.</h3>
        <div class="showing-movie-poster">
        <div class="position-relative">
      <a href="#"><img src="https://th.bing.com/th/id/OIP.IdWesSN352Ul44t37_5dCQHaDz?pid=ImgDet&rs=1" alt="" class="movie-img"></a>
      <span class="float-absolute-bottom"><a href="rrr.html">BOOK NOW</a></span>
              <span class="float-absolute-top text-center"><em>NEW !</em></span>
            </div>
            <div class="movie-detail text-center">
              <span><span class="mov-name-like"><i class="fas fa-thumbs-up"></i><span> 45k </span></span> <br> <span>Votes</span> </span> <br><span><span class="mov-name-like">RRR</span><br><span>15 Sep <span>|</span> Hindi</span></span>
            </div>
              </div>
        <div class="showing-movie-poster">
       <div class="position-relative">
        <a href="#"><img src="https://telugubullet.com/wp-content/uploads/2020/04/Pushpa-Movie-4.jpg" alt="" class="movie-img"></a>
        <span class="float-absolute-bottom"><a href="pushpa1.html">BOOK NOW</a></span>
                <span class="float-absolute-top text-center"><em>NEW !</em></span>
               </div>
               <div class="movie-detail text-center">
                <span><span class="mov-name-like"><i class="fas fa-thumbs-up"></i><span> 100k </span></span> <br> <span>Votes</span> </span> <span><span class="mov-name-like">Pushpa: The Rise - Part 1</span><br><span> 30 Aug <span>|</span> Hindi</span></span>
              </div>
              </div>
        <div class="showing-movie-poster">
         <div class="position-relative">
          <a href="#"><img src="https://m.media-amazon.com/images/M/MV5BMGM4MDkxMTQtYWU0OS00ZThmLWJhODctYzAxZjhkNDlmYTlhXkEyXkFqcGdeQXVyODE5NzE3OTE@._V1_.jpg" alt="" class="movie-img"></a>
            <span class="float-absolute-bottom"><a href="dab.html">BOOK NOW</a></span>

           </div>
           <div class="movie-detail text-center">
            <span><span class="mov-name-like"><i class="fas fa-thumbs-up"></i><span> 75k </span></span> <br> <span>Votes</span> </span> <br><span><span class="mov-name-like">Dabbang 3</span><br><span>2 Apr <span>|</span> Hindi</span></span>
          </div>
        </div>
        <div class="showing-movie-poster"><
           <div class="position-relative">
            <a href="#"><img src="https://m.media-amazon.com/images/M/MV5BNjZjYzRhMmEtMTU0Ny00YWI4LThiZjEtNWZjMDQ3MTgwZmVhXkEyXkFqcGdeQXVyMTA5NzIyMDY5._V1_.jpg" alt="" class="movie-img"></a>
              <span class="float-absolute-bottom"><a href="bookings.html">BOOK NOW</a></span>
             </div>
             <div class="movie-detail text-center">
              <span><span class="mov-name-like"><i class="fas fa-thumbs-up"></i><span> 50k </span></span> <br> <span>Votes</span> </span> <br><span><span class="mov-name-like">Chhapak</span><br><span>12 sep <span>|</span> Hindi</span></span>
            </div>
        </div>

        <div class="showing-movie-poster">
          <div class="position-relative">
           <a href="#"><img src="https://m.media-amazon.com/images/M/MV5BMDRiNTAwNmYtZWY0Ni00MzI4LTg5OTYtZDdjYjNlM2E2ZmRkXkEyXkFqcGdeQXVyNTIzOTk5ODM@._V1_FMjpg_UX1000_.jpg" alt="" class="movie-img"></a>
                <span class="float-absolute-bottom"><a href="stooges.html">BOOK NOW</a></span>
                  </div>
                  <div class="movie-detail text-center">
                   <span><span class="mov-name-like"><i class="fas fa-thumbs-up"></i><span> 1.2k </span></span> <br> <span>Votes</span> </span><br> <span><span class="mov-name-like">THE THREE STOOGES</span><br><span>5 sep <span>|</span> Hindi</span></span>
                 </div>
             </div>

       <div class="showing-movie-poster">
        <div class="position-relative">
         <a href="#"><img src="https://upload.wikimedia.org/wikipedia/en/3/3d/The_Lion_King_poster.jpg" alt="" class="movie-img"></a>
         <span class="float-absolute-bottom"><a href="thelion.html">BOOK NOW</a></span>
                </div>
                <div class="movie-detail text-center">
                 <span><span class="mov-name-like"><i class="fas fa-thumbs-up"></i><span> 100k </span></span> <br> <span>Votes</span> </span><br> <span><span class="mov-name-like">The Lion</span><br><span> 11 sep <span>|</span> Hindi</span></span>
               </div>
             </div>
      </article>
     <h3 class="text-center"><a href="#" class="heading-link"> Back TO Top <i class="fas fa-angle-down"></i></a></h3>
    </section>

    <section class="main-section">
      <h2 class="text-center section-heading">Upcoming Movies <i class="far fa-caret-square-down"></i></h2>
      <article class="upcoming-movie">
        <h3 class="d-none">.</h3>
        <div class="upcoming-movie-poster">
        <a href="#"><img src="https://m.media-amazon.com/images/M/MV5BZTAxNWE2MDItZWFlNS00MWM1LWI1ZjQtN2I5NDBhNWYzZjNhXkEyXkFqcGdeQXVyODE5NzE3OTE@._V1_.jpg" alt="" class="upcoming-movie-img"></a>
         <div class="upcoming-detail">
         <span><span class="upcoming-detail-heading">Release Date: </span> <span>12 May, 2020</span></span> <br>
         <span><span class="upcoming-detail-heading">Cast: </span> <span> <em>Tiger Shroff, Shraddha Kapoor</em> </span></span> <br>
         <span><span class="upcoming-detail-heading">Genre: </span> <span>Action</span></span> <br>
         <a href="#" class="text-center see-more-link">See more details<i class="fas fa-angle-down"></i></a>
           
         </div>
       </div>
       <div class="upcoming-movie-poster">
        <a href="#"><img src="https://m.media-amazon.com/images/M/MV5BNTlmNDMzOWQtYzg4Ny00OWQ0LWFhN2MtNmQ2MDczZGZhNTU5XkEyXkFqcGdeQXVyODE5NzE3OTE@._V1_.jpg" alt="" class="upcoming-movie-img"></a>
         <div class="upcoming-detail">
         <span><span class="upcoming-detail-heading">Release Date: </span> <span>12 May, 2020</span></span> <br>
         <span><span class="upcoming-detail-heading">Cast: </span> <span> <em>Tiger Shroff, Shraddha Kapoor</em> </span></span> <br>
         <span><span class="upcoming-detail-heading">Genre: </span> <span>Action</span></span> <br>
         <a href="#" class="text-center see-more-link">See more details<i class="fas fa-angle-down"></i></a>
           
         </div>
       </div>
       <div class="upcoming-movie-poster">
        <a href="#"><img src="https://m.media-amazon.com/images/M/MV5BMTNhOWM4Y2MtZDhjNC00ZTZmLWJkMDUtNGE4Nzg2MzhmMzY0XkEyXkFqcGdeQXVyOTAzMTc2MjA@._V1_.jpg" alt="" class="upcoming-movie-img"></a>
         <div class="upcoming-detail">
         <span><span class="upcoming-detail-heading">Release Date: </span> <span>12 May, 2020</span></span> <br>
         <span><span class="upcoming-detail-heading">Cast: </span> <span> <em>Tiger Shroff, Shraddha Kapoor</em> </span></span> <br>
         <span><span class="upcoming-detail-heading">Genre: </span> <span>Action</span></span> <br>
         <a href="#" class="text-center see-more-link">See more details<i class="fas fa-angle-down"></i></a>
           
         </div>
       </div>
      

       
      
       
       
       
      </article>
      <h3 class="text-center"><a href="#" class="heading-link"> Back To Top<i class="fas fa-angle-down"></i></a></h3>
    </section>
  </main>

  <footer>
    
   
      
        </div>
      
    </div>
    
    </div>
  </footer>
  <?php echo $_SESSION['name']; ?>
    
     <a href="logout.php">Logout</a>
</body>
</html>

<?php 
}else{
     header("Location: index.php");
     exit();
}
 ?>