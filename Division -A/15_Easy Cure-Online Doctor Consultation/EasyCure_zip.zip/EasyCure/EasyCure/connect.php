<?php
$host="localhost";
$user="root";
$password="";
$db="userlog";

mysql_connect($host,$user,$password);
mysql_select_db($db)


    $conn = new mysqli('localhost','root','test');
    if($conn->connect_error){
        die('Connection failed   : '.conn->connect_error);

    }else{
        $stmt = $conn->prepare("inert into registration(firstName, lastName, gender, email)
            values(?, ?, ?, ?, ?)");
        $stmt->bind_param("")    
    }
       


if(isset(['username'])){
    $uname=$_POST['username']
    $password=$_POST['password']

    $sql="select * from loginform where user='".$uname."' AND pass='".$password."'
    limit 1 ";

    $result=mysql_query($sql);

    if(mysql_num_rows($result)==1){
        header("Location:index.html");

        exit()
    }
    else{
        echo "You have entered incorrect password"
    }

}


?>




