var express = require("express")
var bodyParser = require("body-parser")
var mongoose = require("mongoose")


const app = express()
// const popup = require('node-popup')


app.use(bodyParser.json())
app.use(express.static('public'))
app.use(bodyParser.urlencoded({
    extended:true
}))

mongoose.connect('mongodb://localhost:27017/mydb',{
    useNewUrlParser: true,
    useUnifiedTopology: true
});
var db = mongoose.connection;

db.on('error',()=>console.log("Error in Connecting to Database"));
db.once('open',()=>console.log("Connected to Database"))

app.post("/sign_up",(req,res)=>{
    var name = req.body.name;
    var email = req.body.email;
    var phone_no = req.body.phone_no;
    var password = req.body.password;
    var conf_pass = req.body.conf_pass;

    if(password == conf_pass && password.length>=8)
    {

    var data = {
        "name": name,
        "email" : email,
        "phone_no": phone_no,
        "password" : password,
        "conf_pass" : conf_pass
    }
    }
    else
        res.send("Password Error")

    db.collection('users').insertOne(data,(err,collection)=>{
        if(err){
            throw err;
        }
        console.log("Record Inserted Successfully");
    });

    return res.redirect('Cart2.html')

})

app.get("/",(req,res)=>{
    res.set({
        "Allow-access-Allow-Origin": '*'
    })
    return res.redirect('index.html');
}).listen(3000);

//login
app.post("/login", async(req,res) =>{
        var email = req.body.email;
        var password = req.body.password;

       var useremail = await db.collection("users").findOne({email:email});
       
       if(useremail.password == password) {
        res.redirect('Cart2.html')
       }
       else{
        res.send("Invalid Login Details");
       }
        
    })

    app.post("/forgot",(req,res)=>{
        // var name = req.body.name;
        var email = req.body.email;
        // var phone_no = req.body.phone_no;
        var password = req.body.password;
        var conf_pass = req.body.conf_pass;
    
        if(password == conf_pass)
        {
    
        var data = {
            // "name": name,
            "email" : email,
            // "phone_no": phone_no,
            "password" : password,
            "conf_pass" : conf_pass
        }
        }
        else
            // res.send('Password does not match')
            alert("Password does not match");
    
        db.collection('users').insertOne(data,(err,collection)=>{
            if(err){
                throw err;
            }
            console.log("Record Inserted Successfully");
        });
        return res.redirect('index.html')

    })


console.log("Listening on PORT 3000");