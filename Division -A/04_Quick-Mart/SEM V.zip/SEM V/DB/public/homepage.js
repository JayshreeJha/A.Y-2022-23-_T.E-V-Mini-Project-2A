// $(document).ready(function(){
  // $(".btn-success").click(function(){
    // $(".btn-success").replaceWith("<button>-</button> 1 <button>+</button>")
    // button.addClass("btn")
  // });
//   Start here
  
//   ended above
// });
// </script>

const search = () =>{
  const searchbox = document.getElementById("search-item").value.toUpperCase();
  const storeitems = document.getElementById("product-list")
  const product = document.querySelectorAll(".grid-item")
  const pname = document.getElementsByTagName("h4")

  for(var i=0;i< pname.length;i++){
      let match = product[i].getElementsByTagName('h4')[0];
      
      if(match){
          let textvalue = match.textContent || match.innerHTML

          if(textvalue.toUpperCase().indexOf(searchbox) > -1){
              product[i].style.display = "";
                      }else{
                  product[i].style.display = "none"
              }
          }

      }
  }


