function lsPush(){
    const storedprods = JSON.parse(localStorage.getItem('product'));
    lsContent.push(storedprods)
    displayProducts();
}