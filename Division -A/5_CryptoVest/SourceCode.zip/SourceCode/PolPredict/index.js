const axios = require('axios')
const cheerio = require('cheerio')
const express = require('express')

async function getPolkaPredict(){
    try{
        const siteUrl = 'https://cryptopredictions.com/polkadot/'
        const {data} = await axios ({
            method: "GET",
            url: siteUrl,
        })
        const $ = cheerio.load(data)
        const pol22 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(2) > div > table > tbody > tr'
        const pol23 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(4) > div > table > tbody > tr'
        const pol24 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(6) > div > table > tbody > tr'
        const pol25 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(8) > div > table > tbody > tr'
        const pol26 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(10) > div > table > tbody > tr'
        const Polkey = [
            'month',
            'minimumprice',
            'maximumprice',
            'averageprice',
            'change'
        ]
        const PolArr = []
               //2022
               $(pol22).each((parentIdx, parentElem)=>{
                let keyIdx = 0
                const coinObj= {}
                $(parentElem).children().each((childIdx,childElem)=>{
                    
                    const tdValue = $(childElem).text()
                    if(tdValue){
                        coinObj[Polkey[keyIdx]] = tdValue
                        keyIdx++
                    }               
                })
                PolArr.push(coinObj)
            })

            //2023
            $(pol23).each((parentIdx, parentElem)=>{
                let keyIdx = 0
                const coinObj= {}
                $(parentElem).children().each((childIdx,childElem)=>{
                    
                    const tdValue = $(childElem).text()
                    if(tdValue){
                        coinObj[Polkey[keyIdx]] = tdValue
                        keyIdx++
                    }               
                })
                PolArr.push(coinObj)
            })

            //2024
            $(pol24).each((parentIdx, parentElem)=>{
                let keyIdx = 0
                const coinObj= {}
                $(parentElem).children().each((childIdx,childElem)=>{
                    
                    const tdValue = $(childElem).text()
                    if(tdValue){
                        coinObj[Polkey[keyIdx]] = tdValue
                        keyIdx++
                    }               
                })
                PolArr.push(coinObj)
            })

            //2025
            $(pol25).each((parentIdx, parentElem)=>{
                let keyIdx = 0
                const coinObj= {}
                $(parentElem).children().each((childIdx,childElem)=>{
                    
                    const tdValue = $(childElem).text()
                    if(tdValue){
                        coinObj[Polkey[keyIdx]] = tdValue
                        keyIdx++
                    }               
                })
                PolArr.push(coinObj)
            })

            
            //2026
            $(pol26).each((parentIdx, parentElem)=>{
                let keyIdx = 0
                const coinObj= {}
                $(parentElem).children().each((childIdx,childElem)=>{
                    
                    const tdValue = $(childElem).text()
                    if(tdValue){
                        coinObj[Polkey[keyIdx]] = tdValue
                        keyIdx++
                    }               
                })
                PolArr.push(coinObj)
            })
            
            return PolArr
    }
    catch(err){
        console.log(err)
    }
}
const app = express()
app.get('/api/PredictPol', async (req,res)=>{
    try{
        const coinpredict  = await getPolkaPredict()
        return res.status(200).json({
            result: coinpredict,
        })
        
    } catch(err){
        return res.status(500).json({
            err: err.toString(),
        })
    }
})



app.listen(5000, ()=>{
    console.log("running on port 5000")
})