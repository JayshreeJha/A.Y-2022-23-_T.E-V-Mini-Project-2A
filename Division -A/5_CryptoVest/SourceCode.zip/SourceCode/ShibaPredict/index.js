const axios = require('axios')
const cheerio = require('cheerio')
const express = require('express')

async function getShibaPredict(){
    try{
        const siteUrl = 'https://cryptopredictions.com/shiba-inu/'
        const {data} = await axios ({
            method: "GET",
            url: siteUrl,
        })
        const $ = cheerio.load(data)
        const shiba22 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(2) > div > table > tbody > tr'
        const shiba23 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(4) > div > table > tbody > tr'
        const shiba24 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(6) > div > table > tbody > tr'
        const shiba25 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(8) > div > table > tbody > tr'
        const shiba26 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(10) > div > table > tbody > tr'
        const shibakey = [
            'month',
            'minimumprice',
            'maximumprice',
            'averageprice',
            'change'
        ]
        const shibaArr = []
               //2022
               $(shiba22).each((parentIdx, parentElem)=>{
                let keyIdx = 0
                const coinObj= {}
                $(parentElem).children().each((childIdx,childElem)=>{
                    
                    const tdValue = $(childElem).text()
                    if(tdValue){
                        coinObj[shibakey[keyIdx]] = tdValue
                        keyIdx++
                    }               
                })
                shibaArr.push(coinObj)
            })

            //2023
            $(shiba23).each((parentIdx, parentElem)=>{
                let keyIdx = 0
                const coinObj= {}
                $(parentElem).children().each((childIdx,childElem)=>{
                    
                    const tdValue = $(childElem).text()
                    if(tdValue){
                        coinObj[shibakey[keyIdx]] = tdValue
                        keyIdx++
                    }               
                })
                shibaArr.push(coinObj)
            })

            //2024
            $(shiba24).each((parentIdx, parentElem)=>{
                let keyIdx = 0
                const coinObj= {}
                $(parentElem).children().each((childIdx,childElem)=>{
                    
                    const tdValue = $(childElem).text()
                    if(tdValue){
                        coinObj[shibakey[keyIdx]] = tdValue
                        keyIdx++
                    }               
                })
                shibaArr.push(coinObj)
            })

            //2025
            $(shiba25).each((parentIdx, parentElem)=>{
                let keyIdx = 0
                const coinObj= {}
                $(parentElem).children().each((childIdx,childElem)=>{
                    
                    const tdValue = $(childElem).text()
                    if(tdValue){
                        coinObj[shibakey[keyIdx]] = tdValue
                        keyIdx++
                    }               
                })
                shibaArr.push(coinObj)
            })

            
            //2026
            $(shiba26).each((parentIdx, parentElem)=>{
                let keyIdx = 0
                const coinObj= {}
                $(parentElem).children().each((childIdx,childElem)=>{
                    
                    const tdValue = $(childElem).text()
                    if(tdValue){
                        coinObj[shibakey[keyIdx]] = tdValue
                        keyIdx++
                    }               
                })
                shibaArr.push(coinObj)
            })
            
            return shibaArr
    }
    catch(err){
        console.log(err)
    }
}
const app = express()
app.get('/api/PredictShiba', async (req,res)=>{
    try{
        const coinpredict  = await getShibaPredict()
        return res.status(200).json({
            result: coinpredict,
        })
        
    } catch(err){
        return res.status(500).json({
            err: err.toString(),
        })
    }
})



app.listen(4500, ()=>{
    console.log("running on port 4500")
})