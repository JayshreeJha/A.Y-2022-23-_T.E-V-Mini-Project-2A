const axios = require('axios')
const cheerio = require('cheerio')
const express = require('express')

async function getSolanaPrice(){
    try{
        const siteUrl = 'https://cryptopredictions.com/cardano/'
        const {data} = await axios ({
            method: "GET",
            url: siteUrl,
        })
        const $ = cheerio.load(data)
        const car22 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(2) > div > table > tbody > tr'
        const car23 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(4) > div > table > tbody > tr'
        const car24 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(6) > div > table > tbody > tr'
        const car25 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(8) > div > table > tbody > tr'
        const car26 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(10) > div > table > tbody > tr'
        const carkey = [
            'month',
            'minimumprice',
            'maximumprice',
            'averageprice',
            'change'
        ]
        const carArr = []
        //2022
        $(car22).each((parentIdx, parentElem)=>{
            let keyIdx = 0
            const coinObj= {}
            $(parentElem).children().each((childIdx,childElem)=>{
                
                const tdValue = $(childElem).text()
                if(tdValue){
                    coinObj[carkey[keyIdx]] = tdValue
                    keyIdx++
                }               
            })
            carArr.push(coinObj)
        })
        //2023
        $(car23).each((parentIdx, parentElem)=>{
            let keyIdx = 0
            const coinObj= {}
            $(parentElem).children().each((childIdx,childElem)=>{
                
                const tdValue = $(childElem).text()
                if(tdValue){
                    coinObj[carkey[keyIdx]] = tdValue
                    keyIdx++
                }               
            })
            carArr.push(coinObj)
        })
        //2024
        $(car24).each((parentIdx, parentElem)=>{
            let keyIdx = 0
            const coinObj= {}
            $(parentElem).children().each((childIdx,childElem)=>{
                
                const tdValue = $(childElem).text()
                if(tdValue){
                    coinObj[carkey[keyIdx]] = tdValue
                    keyIdx++
                }               
            })
            carArr.push(coinObj)
        })
        //2025
        $(car25).each((parentIdx, parentElem)=>{
            let keyIdx = 0
            const coinObj= {}
            $(parentElem).children().each((childIdx,childElem)=>{
                
                const tdValue = $(childElem).text()
                if(tdValue){
                    coinObj[carkey[keyIdx]] = tdValue
                    keyIdx++
                }               
            })
            carArr.push(coinObj)
        })
        //2026
        $(car26).each((parentIdx, parentElem)=>{
            let keyIdx = 0
            const coinObj= {}
            $(parentElem).children().each((childIdx,childElem)=>{
                
                const tdValue = $(childElem).text()
                if(tdValue){
                    coinObj[carkey[keyIdx]] = tdValue
                    keyIdx++
                }               
            })
            carArr.push(coinObj)
        })
        return carArr
    }
    catch(err){
        console.log(err)
    }
}
const app = express()
app.get('/api/PredictCar', async (req,res)=>{
    try{
        const coinpredict  = await getSolanaPrice()
        return res.status(200).json({
            result: coinpredict,
        })
        
    } catch(err){
        return res.status(500).json({
            err: err.toString(),
        })
    }
})
app.listen(4600, ()=>{
    console.log("running on port 4600")
})