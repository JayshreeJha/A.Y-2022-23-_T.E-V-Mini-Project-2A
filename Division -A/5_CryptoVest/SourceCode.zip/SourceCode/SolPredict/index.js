const axios = require('axios')
const cheerio = require('cheerio')
const express = require('express')

async function getSolanaPrice(){
    try{
        const siteUrl = 'https://cryptopredictions.com/solana/'
        const {data} = await axios ({
            method: "GET",
            url: siteUrl,
        })
        const $ = cheerio.load(data)
        const sol22 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(2) > div > table > tbody > tr'
        const sol23 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(4) > div > table > tbody > tr'
        const sol24 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(6) > div > table > tbody > tr'
        const sol25 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(8) > div > table > tbody > tr'
        const sol26 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(10) > div > table > tbody > tr'
        const solkey = [
            'month',
            'minimumprice',
            'maximumprice',
            'averageprice',
            'change'
        ]
        const solArr = []
        //2022
        $(sol22).each((parentIdx, parentElem)=>{
            let keyIdx = 0
            const coinObj= {}
            $(parentElem).children().each((childIdx,childElem)=>{
                
                const tdValue = $(childElem).text()
                if(tdValue){
                    coinObj[solkey[keyIdx]] = tdValue
                    keyIdx++
                }               
            })
            solArr.push(coinObj)
        })
        //2023
        $(sol23).each((parentIdx, parentElem)=>{
            let keyIdx = 0
            const coinObj= {}
            $(parentElem).children().each((childIdx,childElem)=>{
                
                const tdValue = $(childElem).text()
                if(tdValue){
                    coinObj[solkey[keyIdx]] = tdValue
                    keyIdx++
                }               
            })
            solArr.push(coinObj)
        })
        //2024
        $(sol24).each((parentIdx, parentElem)=>{
            let keyIdx = 0
            const coinObj= {}
            $(parentElem).children().each((childIdx,childElem)=>{
                
                const tdValue = $(childElem).text()
                if(tdValue){
                    coinObj[solkey[keyIdx]] = tdValue
                    keyIdx++
                }               
            })
            solArr.push(coinObj)
        })
        //2025
        $(sol25).each((parentIdx, parentElem)=>{
            let keyIdx = 0
            const coinObj= {}
            $(parentElem).children().each((childIdx,childElem)=>{
                
                const tdValue = $(childElem).text()
                if(tdValue){
                    coinObj[solkey[keyIdx]] = tdValue
                    keyIdx++
                }               
            })
            solArr.push(coinObj)
        })
        //2026
        $(sol26).each((parentIdx, parentElem)=>{
            let keyIdx = 0
            const coinObj= {}
            $(parentElem).children().each((childIdx,childElem)=>{
                
                const tdValue = $(childElem).text()
                if(tdValue){
                    coinObj[solkey[keyIdx]] = tdValue
                    keyIdx++
                }               
            })
            solArr.push(coinObj)
        })
        return solArr
    }
    catch(err){
        console.log(err)
    }
}
const app = express()
app.get('/api/PredictSol', async (req,res)=>{
    try{
        const coinpredict  = await getSolanaPrice()
        return res.status(200).json({
            result: coinpredict,
        })
        
    } catch(err){
        return res.status(500).json({
            err: err.toString(),
        })
    }
})
app.listen(4200, ()=>{
    console.log("running on port 4200")
})