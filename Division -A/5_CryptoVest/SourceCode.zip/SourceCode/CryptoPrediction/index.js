const axios = require('axios')
const cheerio = require('cheerio')
const express = require('express')

async function getPriceFeed(){
    try{
        const siteUrl = 'https://cryptopredictions.com/bitcoin/s'
        const {data} = await axios ({
            method: "GET",
            url: siteUrl,
        })

        const $ = cheerio.load(data)
        const elemSelector = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(2) > div > table > tbody > tr'
        const elemSelectors = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(6) > div > table > tbody > tr'
        const elemSelectorss = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(4) > div > table > tbody > tr'
        const elemSelector2025 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(8) > div > table > tbody > tr'
        const elemSelector2026 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(10) > div > table > tbody > tr'

        const keys = [
            'month',
            'minimumprice',
            'maximumprice',
            'averageprice',
            'change'
        ]
        const coinArr = []
        // 2022
        $(elemSelector).each((parentIdx, parentElem)=>{
            let keyIdx = 0
            const coinObj= {}
            $(parentElem).children().each((childIdx,childElem)=>{
                
                const tdValue = $(childElem).text()
                if(tdValue){
                    coinObj[keys[keyIdx]] = tdValue
                    keyIdx++
                }               
            })
            coinArr.push(coinObj)
        })
        //2023
        $(elemSelectors).each((parentIdx, parentElem)=>{
            let keyIdx = 0
            const coinObj= {}
            $(parentElem).children().each((childIdx,childElem)=>{
                
                const tdValue = $(childElem).text()
                if(tdValue){
                    coinObj[keys[keyIdx]] = tdValue
                    keyIdx++
                }               
            })
            coinArr.push(coinObj)
        })
        //2024
        $(elemSelectorss).each((parentIdx, parentElem)=>{
            let keyIdx = 0
            const coinObj= {}
            $(parentElem).children().each((childIdx,childElem)=>{
                
                const tdValue = $(childElem).text()
                if(tdValue){
                    coinObj[keys[keyIdx]] = tdValue
                    keyIdx++
                }               
            })
            coinArr.push(coinObj)
        })
        //2025
        $(elemSelector2025).each((parentIdx, parentElem)=>{
            let keyIdx = 0
            const coinObj= {}
            $(parentElem).children().each((childIdx,childElem)=>{
                
                const tdValue = $(childElem).text()
                if(tdValue){
                    coinObj[keys[keyIdx]] = tdValue
                    keyIdx++
                }               
            })
            coinArr.push(coinObj)
        })
        //2026
        $(elemSelector2026).each((parentIdx, parentElem)=>{
            let keyIdx = 0
            const coinObj= {}
            $(parentElem).children().each((childIdx,childElem)=>{
                
                const tdValue = $(childElem).text()
                if(tdValue){
                    coinObj[keys[keyIdx]] = tdValue
                    keyIdx++
                }               
            })
            coinArr.push(coinObj)
        })
        return coinArr
    }
     catch(err){
        console.log(err)
    }
}

async function getEthPrice(){
    try{
        const siteUrl = 'https://cryptopredictions.com/ethereum/'
        const {data} = await axios ({
            method: "GET",
            url: siteUrl,
        })
        const $ = cheerio.load(data)
        const eth22 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(2) > div > table > tbody > tr'
        const eth23 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(4) > div > table > tbody > tr'
        const eth24 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(6) > div > table > tbody > tr'
        const eth25 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(8) > div > table > tbody > tr'
        const eth26 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(10) > div > table > tbody > tr'




        const ethkey = [
            'month',
            'minimumprice',
            'maximumprice',
            'averageprice',
            'change'
        ]

        const ethArr = []
        //2022
        $(eth22).each((parentIdx, parentElem)=>{
            let keyIdx = 0
            const coinObj= {}
            $(parentElem).children().each((childIdx,childElem)=>{
                
                const tdValue = $(childElem).text()
                if(tdValue){
                    coinObj[ethkey[keyIdx]] = tdValue
                    keyIdx++
                }               
            })
            ethArr.push(coinObj)
        })
        //2023
        $(eth23).each((parentIdx, parentElem)=>{
            let keyIdx = 0
            const coinObj= {}
            $(parentElem).children().each((childIdx,childElem)=>{
                
                const tdValue = $(childElem).text()
                if(tdValue){
                    coinObj[ethkey[keyIdx]] = tdValue
                    keyIdx++
                }               
            })
            ethArr.push(coinObj)
        })
        //2024
        $(eth24).each((parentIdx, parentElem)=>{
            let keyIdx = 0
            const coinObj= {}
            $(parentElem).children().each((childIdx,childElem)=>{
                
                const tdValue = $(childElem).text()
                if(tdValue){
                    coinObj[ethkey[keyIdx]] = tdValue
                    keyIdx++
                }               
            })
            ethArr.push(coinObj)
        })
        //2025
        $(eth25).each((parentIdx, parentElem)=>{
            let keyIdx = 0
            const coinObj= {}
            $(parentElem).children().each((childIdx,childElem)=>{
                
                const tdValue = $(childElem).text()
                if(tdValue){
                    coinObj[ethkey[keyIdx]] = tdValue
                    keyIdx++
                }               
            })
            ethArr.push(coinObj)
        })
        //2026
        $(eth26).each((parentIdx, parentElem)=>{
            let keyIdx = 0
            const coinObj= {}
            $(parentElem).children().each((childIdx,childElem)=>{
                
                const tdValue = $(childElem).text()
                if(tdValue){
                    coinObj[ethkey[keyIdx]] = tdValue
                    keyIdx++
                }               
            })
            ethArr.push(coinObj)
        })
        return ethArr
    }
    catch(err){
        console.log(err)
    }
}


async function getPolkaPredict(){
    try{
        const siteUrl = 'https://cryptopredictions.com/polkadot/'
        const {data} = await axios ({
            method: "GET",
            url: siteUrl,
        })
        const $ = cheerio.load(data)
        const pol22 = '#page > div.container.detail-page > div.crypto-info > div.tables > div:nth-child(2) > div > table > tbody > tr'
        const Polkey = [
            'month',
            'minimumprice',
            'maximumprice',
            'averageprice',
            'change'
        ]
        const PolArr = []
               //2022
               $(pol22).each((parentIdx, parentElem)=>{
                let keyIdx = 0
                const coinObj= {}
                $(parentElem).children().each((childIdx,childElem)=>{
                    
                    const tdValue = $(childElem).text()
                    if(tdValue){
                        coinObj[Polkey[keyIdx]] = tdValue
                        keyIdx++
                    }               
                })
                PolArr.push(coinObj)
            })
            return PolArr
    }
    catch(err){
        console.log(err)
    }
}
const app = express()
app.get('/api/CryptoPrediction', async (req,res)=>{
    try{
        const coinpredict  = await getPriceFeed()
        return res.status(200).json({
            result: coinpredict,
        })
        
    } catch(err){
        return res.status(500).json({
            err: err.toString(),
        })
    }
})
app.get('/api/PredictEth', async (req,res)=>{
    try{
        const coinpredict  = await getEthPrice()
        return res.status(200).json({
            result: coinpredict,
        })
        
    } catch(err){
        return res.status(500).json({
            err: err.toString(),
        })
    }
})
app.get('/api/PredictSol', async (req,res)=>{
    try{
        const coinpredict  = await getSolanaPrice()
        return res.status(200).json({
            result: coinpredict,
        })
        
    } catch(err){
        return res.status(500).json({
            err: err.toString(),
        })
    }
})
app.get('/api/PredictPol', async (req,res)=>{
    try{
        const coinpredict  = await getPolkaPredict()
        return res.status(200).json({
            result: coinpredict,
        })
        
    } catch(err){
        return res.status(500).json({
            err: err.toString(),
        })
    }
})



app.listen(3000, ()=>{
    console.log("running on port 3000")
})

