async function getEthPrice(){
//     try{
//         const siteUrl = 'https://cryptopredictions.com/bitcoin/s'
//         const {data} = await axios ({
//             method: "GET",
//             url: siteUrl,
//         })
//         const $ = cheerio.load(data)
//         //2022

//     }


// }