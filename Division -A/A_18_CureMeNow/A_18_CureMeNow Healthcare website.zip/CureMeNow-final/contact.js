function submittMessage(){
    var name = $("#name").val();
    var email = $("#email").val();
    var phone = $("#phone").val();
    var message = $("#message").val();
    $.post("contact.php", {name:name, email:email, phone:phone, message:message},
    function(data){
        $('#results').html(data);
        $('#contactForm')[0].reset();
    });
}
function contactlog(){
    var men = "contact";
    localStorage.setItem("myvalue", men);
    window.location.href = "http://localhost/CureMeNow-final/login.html"; 
}
