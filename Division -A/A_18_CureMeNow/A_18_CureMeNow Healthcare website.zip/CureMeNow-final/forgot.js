function forgotSubmit(){
    var email = $("#email").val();
    var securityQ = $("#securityQ").val();
    var securityA = $("#securityA").val();
    $.post("forgot.php", {email:email,securityQ:securityQ,securityA:securityA},
    function(data){
        if(data == "done"){
            $('#result').html(data);
            $('#forgotForm')[0].reset();
            window.location.href = "http://localhost/CureMeNow-final/change.html";  
            localStorage.setItem("email",email)
        }
});  
}