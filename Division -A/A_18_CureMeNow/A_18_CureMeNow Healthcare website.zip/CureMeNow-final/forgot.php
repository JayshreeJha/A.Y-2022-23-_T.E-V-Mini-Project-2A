<?php
$email = $_POST['email'];
$securityQ = $_POST['securityQ'];
$securityA = $_POST['securityA'];
$con = mysqli_connect('localhost', 'root', 'Ashmina27@','login');
    $query = "SELECT * FROM `register` WHERE email='$email' && securityQ='$securityQ' && securityA='$securityA'";
    $result = $con->query($query);
                            
    if ($result->num_rows > 0) 
    {
        echo 'done';
    } 
    else {
        echo '<script>alert("Invalid credentials. Please try again !")</script>';
    }
?>