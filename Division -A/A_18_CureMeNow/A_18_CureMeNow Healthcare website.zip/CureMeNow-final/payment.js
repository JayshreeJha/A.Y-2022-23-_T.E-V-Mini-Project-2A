function buynow(){
    var name = document.getElementById("namee").textContent;
    var mobile = document.getElementById("mobile").textContent;
    var email = document.getElementById("emaill").textContent;
    var amount = document.getElementById("pricee").textContent;
    var address = document.getElementById("address").value;
    var city = document.getElementById("city").value;
    var state = document.getElementById("state").value;
    var payopt = document.getElementsByName('payOpt');
    for(i = 0; i < payopt.length; i++) {
        if(payopt[i].checked){
            var Payopt = payopt[i].value;
        }
    }   
    if(name == "" || mobile == "" || email == "" || amount == "" || address == "" || city == "" || state == "" || Payopt == ""){
        alert("To proceed for payment, all the fields must be filled.")
        
    }
    else if(Payopt == "Cash On Delivery"){
        alert("Your order is been placed.");
        window.location.href = "http://localhost/CureMeNow-final/ShopCart.html";
    }
    else if(Payopt == "online"){
        $.post("paymentdetails.php", {name:name, mobile:mobile, email:email, amount:amount, address:address, city:city, state:state},
        function(data){
            $('#result').html(data);
            $('#payform')[0].reset();  
            window.location.href = "http://localhost/CureMeNow-final/start.php";
            localStorage.setItem("emailp",email);
            localStorage.setItem("name",name);
            localStorage.setItem("mobile",mobile);
            localStorage.setItem("price",amount); 
        });
    }
}