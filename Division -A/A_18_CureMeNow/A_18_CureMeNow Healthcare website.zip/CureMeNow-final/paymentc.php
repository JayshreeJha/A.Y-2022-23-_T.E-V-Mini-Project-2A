<?php
$email = $_POST['email'];
$con = mysqli_connect('localhost', 'root', 'Ashmina27@','login');
$query = "SELECT * FROM `register` WHERE email='$email'";
$result = $con->query($query);
                           
if ($result->num_rows > 0) 
{
    while($row = $result->fetch_assoc()) {
        echo $row['mob'];
    }
} 
else {
    echo '<script>alert("Invalid credentials. Please try again !")</script>';
}
$con->close();
?>