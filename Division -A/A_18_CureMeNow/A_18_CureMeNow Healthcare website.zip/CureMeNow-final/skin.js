function skinForm(){
    var concern = $("#concern").val();
    var onemonth = document.getElementsByName('1month');
    var threemonth = document.getElementsByName('3month');
    var always = document.getElementsByName('always');
    var scars = $("#scars").val();
    var app = [];
    for(i = 0;i < onemonth.length; i++){
        if(onemonth[i].checked){
            app.push(onemonth[i].value);
            var appear = app.toString();
        }
    }
    for(j = 0;j < threemonth.length; j++){
        if(threemonth[j].checked){
            app.push(threemonth[j].value);
            var appear = app.toString();
        }
    }
    for(k = 0;k < always.length; k++){
        if(always[k].checked){
            app.push(always[k].value);
            var appear = app.toString();
        }
    }
    $.post("skin.php", {concern:concern, appear:appear, scars:scars},
    function(data){
        $('#result').html(data);
        $('#skinform')[0].reset();
    });  
}
function skinlog(){
    var men = "skin";
    localStorage.setItem("myvalue", men);
    window.location.href = "http://localhost/CureMeNow-final/login.html"; 
}