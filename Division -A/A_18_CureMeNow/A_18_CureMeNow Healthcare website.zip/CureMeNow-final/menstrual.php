<?php
$days = $_POST['days'];
$pain = $_POST['pain'];
$flow = $_POST['flow'];
$con = mysqli_connect('localhost', 'root', 'Ashmina27@','dummy_docter');
$query = "SELECT recom FROM `menstruation` WHERE days='$days' && flow='$flow' && pain='$pain'";
                            // FETCHING DATA FROM DATABASE
$result = $con->query($query);
                            
    if ($result->num_rows > 0) 
    {
        // OUTPUT DATA OF EACH ROW
        while($row = $result->fetch_assoc())
            {
                $recom = $row['recom'];
                echo $recom;
            }
    } 
    else {
        echo "0 results";
    }
                            
$con->close();
                            
?>