function changedSubmit(){
    var email = $("#email").val();
    var pass = $("#pass").val();
    var cpass = $("#cpass").val();
    var paswd=  /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,20}$/;
    if(email == "" || pass == "" || cpass == ""){
        alert("Enter all fields");
    }
    else if(pass != cpass){
        alert("Sorry password didn't match, Check again!");
    }
    else if(!pass.match(paswd)){
        alert("Length of password must be between 8 to 20 along with atleast one numerical and special character present.");
    }
    else{
        $.post("change.php", {email:email, pass:pass},
        function(data){
            $('#result').html(data);
            $('#changedForm')[0].reset();
            window.location.href = "http://localhost/CureMeNow-final/login.html"; 
            var value = "changed"; 
            localStorage.setItem("changed",value)
    });  
}
}