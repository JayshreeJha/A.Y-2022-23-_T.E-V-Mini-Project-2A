<?php
$fname = $_POST['fname'];
$lname = $_POST['lname'];
$mob = $_POST['mob'];
$email = $_POST['email'];
$pass = $_POST['pass'];
$gender = $_POST['gender'];
$securityQ = $_POST['securityQ'];
$securityA = $_POST['securityA'];
$con = mysqli_connect('localhost', 'root', 'Ashmina27@','login');
$query = "INSERT INTO `register`(`fname`, `lname`, `gender`, `mob`, `email`, `pass`, `securityQ`, `securityA`) VALUES ('$fname','$lname','$gender','$mob','$email',md5('($pass)'),'$securityQ','$securityA')";
// FETCHING DATA FROM DATABASE
$rs = mysqli_query($con, $query);
if($rs)
{
    echo '<script>alert("You are now successfully registered. You may login now!");</script>'; 
}
else{
    echo '<script>alert("Please try again to reach us.");</script>';
}
$con->close(); 
?>