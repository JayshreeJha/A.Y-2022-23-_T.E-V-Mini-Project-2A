function feverForm(){
    var temp = $("#temp").val();
    var coug = document.getElementsByName('cough');
    var cold = document.getElementsByName('cold');
    var head = document.getElementsByName('head');
    var symptoms = $("#symptoms").val();
    var pro = [];
    for(i = 0;i < coug.length; i++){
        if(coug[i].checked){
            pro.push(coug[i].value);
            var prob = pro.toString();
        }
    }
    for(j = 0;j < cold.length; j++){
        if(cold[j].checked){
            pro.push(cold[j].value);
            var prob = pro.toString();
        }
    }
    for(k = 0;k < head.length; k++){
        if(head[k].checked){
            pro.push(head[k].value);
            var prob = pro.toString();
        }
    }
    $.post("fever.php", {temp:temp, prob:prob, symptoms:symptoms},
    function(data){
        $('#result').html(data);
        $('#feverform')[0].reset();
    });  
}
function feverlog(){
    var men = "fever";
    localStorage.setItem("myvalue", men);
    window.location.href = "http://localhost/CureMeNow-final/login.html"; 
}