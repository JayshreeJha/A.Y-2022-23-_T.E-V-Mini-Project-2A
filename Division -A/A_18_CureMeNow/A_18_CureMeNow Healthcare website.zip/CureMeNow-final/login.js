function loginSubmit(){
    var email = $("#email").val();
    var pass = $("#pass").val();
    var result = localStorage.getItem("myvalue");
    $.post("login.php", {email:email, pass:pass},   
        function(data){
            if(result == "homepage" && data == "done"){
                $('#result').html(data);
                $('#loginForm')[0].reset();
                window.location.href = "http://localhost/CureMeNow-final/homepage.html";              
            }
            else if(result == "menstrual" && data == "done"){
                $('#result').html(data);
                $('#loginForm')[0].reset();
                window.location.href = "http://localhost/CureMeNow-final/menstrual.html";            
            }
            else if(result == "bodypain" && data == "done"){
                $('#result').html(data);
                $('#loginForm')[0].reset();
                window.location.href = "http://localhost/CureMeNow-final/bodypain.html";            
            }
            else if(result == "fever" && data == "done"){
                $('#result').html(data);
                $('#loginForm')[0].reset();
                window.location.href = "http://localhost/CureMeNow-final/fever.html";            
            }
            else if(result == "diabetes" && data == "done"){
                $('#result').html(data);
                $('#loginForm')[0].reset();
                window.location.href = "http://localhost/CureMeNow-final/daibetes.html";            
            }
            else if(result == "diarrhea" && data == "done"){
                $('#result').html(data);
                $('#loginForm')[0].reset();
                window.location.href = "http://localhost/CureMeNow-final/diarrhea.html";            
            }
            else if(result == "skin" && data == "done"){
                $('#result').html(data);
                $('#loginForm')[0].reset();
                window.location.href = "http://localhost/CureMeNow-final/skin.html";            
            }
            else if(result == "about" && data == "done"){
                $('#result').html(data);
                $('#loginForm')[0].reset();
                window.location.href = "http://localhost/CureMeNow-final/about.html";            
            }
            else if(result == "blog" && data == "done"){
                $('#result').html(data);
                $('#loginForm')[0].reset();
                window.location.href = "http://localhost/CureMeNow-final/blog.html";            
            }
            else if(result == "contact" && data == "done"){
                $('#result').html(data);
                $('#loginForm')[0].reset();
                window.location.href = "http://localhost/CureMeNow-final/contact.html";            
            }
            else if(result == "maps" && data == "done"){
                $('#result').html(data);
                $('#loginForm')[0].reset();
                window.location.href = "http://localhost/CureMeNow-final/map.html";            
            }
            else if(result == "shopcart" && data == "done"){
                $('#result').html(data);
                $('#loginForm')[0].reset();
                window.location.href = "http://localhost/CureMeNow-final/ShopCart.html";            
            }
            else if(result == "buy" && data == "done"){
                $('#result').html(data);
                $('#loginForm')[0].reset();
                window.location.href = "http://localhost/CureMeNow-final/Payment.html";   
                localStorage.setItem("email", email);     
            }
            else if(result == "changed" && data == "done"){
                $('#result').html(data);
                $('#loginForm')[0].reset();
                window.location.href = "http://localhost/CureMeNow-final/homepage.html";            
            }
            else {
                $('#result').html(data);
                $('#loginForm')[0].reset();
                window.location.href = "http://localhost/CureMeNow-final/homepage.html"; 
            }
            

    });    
}
