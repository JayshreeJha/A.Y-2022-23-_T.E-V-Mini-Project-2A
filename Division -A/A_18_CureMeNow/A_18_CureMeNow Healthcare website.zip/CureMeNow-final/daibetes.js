function diabetesform(){
    var dizzy = $("#dizzy").val();
    var urine = $("#urine").val();
    var wounds = $("#wounds").val();
    $.post("daibetes.php", {dizzy:dizzy, urine:urine, wounds:wounds},
    function(data){
        $('#result').html(data);
        $('#daibetesForm')[0].reset();
    });  
}
function diabeteslog(){
    var men = "diabetes";
    localStorage.setItem("myvalue", men);
    window.location.href = "http://localhost/CureMeNow-final/login.html"; 
}