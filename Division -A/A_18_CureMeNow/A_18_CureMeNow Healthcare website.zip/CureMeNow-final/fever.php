<?php
$temp = $_POST['temp'];
$prob = $_POST['prob'];
$symptoms = $_POST['symptoms'];
$con = mysqli_connect('localhost', 'root', 'Ashmina27@','dummy_docter');
$query = "SELECT recom FROM `fever` WHERE temp='$temp' && prob='$prob' && symptoms='$symptoms'";
$result = $con->query($query);                           
    if ($result->num_rows > 0) 
    {
        while($row = $result->fetch_assoc())
            {
                $recom = $row['recom'];
                echo $recom;
            }
    } 
    else {
        echo "0 results";
    }                       
$con->close();
?>