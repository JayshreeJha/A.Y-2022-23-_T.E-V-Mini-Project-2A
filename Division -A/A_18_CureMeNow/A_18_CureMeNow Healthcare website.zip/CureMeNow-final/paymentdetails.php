<?php
$name = $_POST['name'];
$mobile = $_POST['mobile'];
$email = $_POST['email'];
$amount = $_POST['amount'];
$address = $_POST['address'];
$city = $_POST['city'];
$state = $_POST['state'];
$con = mysqli_connect('localhost', 'root', 'Ashmina27@','login');
$query = "INSERT INTO `orderdetails`(`name`, `mobile`, `email`, `amount`, `address`, `city`,`state`) VALUES ('$name','$mobile','$email','$amount','$address','$city','$state')";
// FETCHING DATA FROM DATABASE
$rs = mysqli_query($con, $query);
if($rs)
{
    echo '<script>alert("You can now proceed for payment.");</script>'; 
}
else{
    echo '<script>alert("Please make sure you have filled the correct details.");</script>';
}
$con->close(); 
?>