<?php
$email = $_POST['email'];
$pass = $_POST['pass'];
$con = mysqli_connect('localhost', 'root', 'Ashmina27@','login');
$query = "UPDATE `register` SET `pass`=md5('($pass)') WHERE `email`='$email'";
$rs = mysqli_query($con, $query);
if($rs)
{
    echo '<script>alert("Your password is changed successfully. You can login now");</script>'; 
}
else{
    echo '<script>alert("Please try again later.");</script>';
}
$con->close(); 
?>
?>