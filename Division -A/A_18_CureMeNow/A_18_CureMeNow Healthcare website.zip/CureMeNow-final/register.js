function registerSubmit(){
    var fname = $("#fname").val();
    var lname = $("#lname").val();
    var mob = $("#mob").val();
    var email = $("#email").val();
    var pass = $("#pass").val();
    var cpass = $("#cpass").val();
    var securityQ = $("#securityQ").val();
    var securityA = $("#securityA").val();
    var gen = document.getElementsByName('gender');
    var paswd=  /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,20}$/;
    for(i = 0; i < gen.length; i++) {
        if(gen[i].checked){
            var gender = gen[i].value;
        }
    }   
    if(fname == "" || lname == "" || mob == "" || email == "" || pass == "" || cpass == ""){
        alert("Enter all the fields to register.");
    }
    else if(pass != cpass){
        alert("Sorry password didn't match, Check again!");
    }
    else if(!pass.match(paswd)){
        alert("Length of password must be between 8 to 20 along with atleast one numerical and special character present.");
    }
    else{
        $.post("register.php", {fname:fname, lname:lname, mob:mob, email:email, pass:pass, gender:gender,securityQ:securityQ,securityA:securityA},
        function(data){
            $('#result').html(data);
            $('#registerForm')[0].reset();
    });  
    }
    
}