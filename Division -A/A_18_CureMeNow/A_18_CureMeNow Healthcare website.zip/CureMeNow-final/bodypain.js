function bodypainForm(){
    var area = $("#area").val();
    var severe = $("#severe").val();
    var time = $("#time").val();
    $.post("bodypain.php", {area:area, severe:severe, time:time},
    function(data){
        $('#result').html(data);
        $('#bodypainform')[0].reset();
    });  
}
function bodylog(){
    var men = "bodypain";
    localStorage.setItem("myvalue", men);
    window.location.href = "http://localhost/CureMeNow-final/login.html"; 
}