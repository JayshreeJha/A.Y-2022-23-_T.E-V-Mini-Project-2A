<?php
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$message = $_POST['message'];
if($name == "" || $email == "" || $phone == "" || $message == ""){
    echo '<script>alert("Enter all the fields !")</script>';
}
else {
    $con = mysqli_connect('localhost', 'root', 'Ashmina27@','login');
    $query = "INSERT INTO `contact_us`(`name`, `email`, `mob`, `message`) VALUES ('$name','$email','$phone','$message')";
    // FETCHING DATA FROM DATABASE
    $rs = mysqli_query($con, $query);

    if($rs)
    {
        echo '<script>alert("Your message has reached us. We will make sure to revert back soon. Thank you");</script>'; 
    }
    else{
        echo '<script>alert("Please try again to reach us.");</script>';
    }
    $con->close();                               
}
// echo '<script>alert("Done")</script>'

?>