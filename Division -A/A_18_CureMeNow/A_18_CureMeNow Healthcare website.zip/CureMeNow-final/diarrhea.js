function diarrheaForm(){
    var freq = $("#freq").val();
    var when = $("#when").val();
    var severe = $("#severe").val();
    $.post("diarrhea.php", {freq:freq, when:when, severe:severe},
    function(data){
        $('#result').html(data);
        $('#diarrheaform')[0].reset();
    });  
}
function diarrhealog(){
    var men = "diarrhea";
    localStorage.setItem("myvalue", men);
    window.location.href = "http://localhost/CureMeNow-final/login.html"; 
}