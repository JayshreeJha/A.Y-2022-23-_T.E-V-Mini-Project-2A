function mapslog(){
    var men = "maps";
    localStorage.setItem("myvalue", men);
    window.location.href = "http://localhost/CureMeNow-final/login.html"; 
}