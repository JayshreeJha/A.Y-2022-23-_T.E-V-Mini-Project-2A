function  loginf(){
    var home = "homepage";
    localStorage.setItem("myvalue", home);
    window.location.href = "http://localhost/CureMeNow-final/login.html";
}
