<?php
$freq = $_POST['freq'];
$when = $_POST['when'];
$severe = $_POST['severe'];
$con = mysqli_connect('localhost', 'root', 'Ashmina27@','dummy_docter');
$query = "SELECT recom FROM `diarrhea` WHERE freq='$freq' && time='$when' && severe='$severe'";
                            // FETCHING DATA FROM DATABASE
$result = $con->query($query);
                            
    if ($result->num_rows > 0) 
    {
        // OUTPUT DATA OF EACH ROW
        while($row = $result->fetch_assoc())
            {
                $recom = $row['recom'];
                echo $recom;
            }
    } 
    else {
        echo "0 results";
    }
                            
$con->close();