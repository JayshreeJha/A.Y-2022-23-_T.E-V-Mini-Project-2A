function menstrualform(){
    var days = $("#days").val();
    var pain = $("#pain").val();
    var flow = $("#flow").val();
    $.post("menstrual.php", {days:days, pain:pain, flow:flow},
    function(data){
        $('#result').html(data);
        $('#menstrualForm')[0].reset();
    });  
}
function menslog(){
    var men = "menstrual";
    localStorage.setItem("myvalue", men);
    window.location.href = "http://localhost/CureMeNow-final/login.html"; 
}