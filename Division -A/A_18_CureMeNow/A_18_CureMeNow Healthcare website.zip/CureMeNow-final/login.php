<?php
$email = $_POST['email'];
$pass = $_POST['pass'];
if($email == "" || $pass == ""){
    echo '<script>alert("Enter all your credentials")</script>';
}
else{
    $con = mysqli_connect('localhost', 'root', 'Ashmina27@','login');
    $query = "SELECT * FROM `register` WHERE email='$email' && pass=md5('($pass)')";
    $result = $con->query($query);
                            
    if ($result->num_rows > 0) 
    {
        echo 'done';
    } 
    else {
        echo '<script>alert("Invalid credentials. Please try again !")</script>';
    }
}
?>