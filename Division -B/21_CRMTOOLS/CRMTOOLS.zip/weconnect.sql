-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 01, 2022 at 08:37 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `weconnect`
--

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` int(6) UNSIGNED NOT NULL,
  `companyname` varchar(100) NOT NULL,
  `url` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phoneno` varchar(100) DEFAULT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `companyname`, `url`, `email`, `phoneno`, `reg_date`) VALUES
(4, 'AMJH Exports', 'http://amjhexports.in', 'ceo_amjh@amjh.ac.in', '8271934650', '2022-10-08 17:30:05'),
(5, 'Jeelani Exports', 'http://www.jeelani.com', 'ceo@jeelani.co.in', '7894561230', '2022-10-10 14:15:25'),
(6, 'Riya Exports', 'http://riyaexports.in', 'riya@riya.com', '7894561230', '2022-10-13 11:38:22');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `name` varchar(100) NOT NULL,
  `company` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` int(10) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `zip` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `currency` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`name`, `company`, `email`, `phone`, `address`, `city`, `state`, `zip`, `country`, `currency`, `password`) VALUES
('Atharv', 'AMJH Exports', 'atharvsathe11@gmail.com', 2147483647, 'Durvankur', 'Ratnagiri', 'Maharashtra', '415639', 'India', 'INR', '123456'),
('adho', 'AMJH Exports', 'demo@example.com', 2147483647, 'ergerg', 'ergesgd', 'Maha', '415639', 'Sri Lanka', 'INR', '12'),
('Atharv', 'AMJH Exports', 'demo@example.com', 2147483647, 'ergerg', 'ergesgd', 'wemf ', '415639', 'United States', 'INR', '120'),
('Atharv', 'AMJH Exports', 'demo@example.com', 2147483647, 'ergerg', 'ergesgd', 'Maha', 'demo@example.com', 'United States', 'INR', '12345678'),
('Atharv', 'AMJH Exports', 'demo@example.com', 2147483647, 'ergerg', 'ergesgd', 'wemf ', '415639', 'United States', 'INR', '120'),
('Jayesh Singh', 'AMJH Exports', 'jayesh@gmail.com', 2147483647, 'Vardayini', 'Thane', 'Maharashtra', '789456', 'India', 'INR', '123456'),
('Prasanna Sathe', 'AMJH Exports', 'pvsathe.21@gmail.com', 2147483647, 'abc', 'kjnhf', 'Maharashtra', '789456', 'India', 'INR', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `expense`
--

CREATE TABLE `expense` (
  `money` int(100) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `expense`
--

INSERT INTO `expense` (`money`, `date`) VALUES
(100, '14-10-2022');

-- --------------------------------------------------------

--
-- Table structure for table `income`
--

CREATE TABLE `income` (
  `money` int(100) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `income`
--

INSERT INTO `income` (`money`, `date`) VALUES
(0, '13-10-2022'),
(0, '14-10-2022'),
(0, '14-10-2022'),
(0, '14-10-2022'),
(2360, '14-10-2022'),
(2360, '14-10-2022'),
(2360, '14-10-2022'),
(2360, '14-10-2022'),
(2360, '14-10-2022'),
(21200, '23-10-2022');

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `id` int(11) NOT NULL,
  `item` varchar(255) DEFAULT NULL,
  `quantity` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `totalind` varchar(255) DEFAULT NULL,
  `taxper` varchar(255) DEFAULT NULL,
  `item1` varchar(255) DEFAULT NULL,
  `quantity1` varchar(255) DEFAULT NULL,
  `price1` varchar(255) DEFAULT NULL,
  `totalind1` varchar(255) DEFAULT NULL,
  `taxper1` varchar(255) DEFAULT NULL,
  `item2` varchar(255) DEFAULT NULL,
  `quantity2` varchar(255) DEFAULT NULL,
  `price2` varchar(255) DEFAULT NULL,
  `totalind2` varchar(255) DEFAULT NULL,
  `taxper2` varchar(255) DEFAULT NULL,
  `item3` varchar(255) DEFAULT NULL,
  `quantity3` varchar(255) DEFAULT NULL,
  `price3` varchar(255) DEFAULT NULL,
  `totalind3` varchar(255) DEFAULT NULL,
  `taxper3` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `customer` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `duedate` varchar(255) DEFAULT NULL,
  `salestax` varchar(255) DEFAULT NULL,
  `invoterm` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `item`, `quantity`, `price`, `totalind`, `taxper`, `item1`, `quantity1`, `price1`, `totalind1`, `taxper1`, `item2`, `quantity2`, `price2`, `totalind2`, `taxper2`, `item3`, `quantity3`, `price3`, `totalind3`, `taxper3`, `subtotal`, `taxamount`, `total`, `customer`, `email`, `status`, `date`, `duedate`, `salestax`, `invoterm`) VALUES
(1, 'Medicine', '10', '20', '200', '6', 'Medicine', '10', '20', '200', '6', 'Medicine', '10', '20', '200', '6', 'Medicine', '10', '20', '200', '6', '800', '48', '848', 'Atharv', '', 'Unpaid', '11-10-2022', 'due_on_receipt', 'Sales Tax (1.50 %)', 'Nothing'),
(2, 'Medicine', '10', '20', '200', '18', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', '200', '36', '236', 'Atharv', '', 'Paid', '11-10-2022', 'due_on_receipt', '', ''),
(11, 'Medicine', '10', '20', '200', '12', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', '200', '24', '224', 'Atharv', 'atharvsathe11@gmail.com', 'Paid', '12-10-2022', 'due_on_receipt', 'Sales Tax (1.50 %)', ''),
(12, 'Medicine', '10', '20', '200', '12', 'Medicine', '16', '20', '320', '12', 'Medicine', '15', '20', '300', '12', 'Medicine', '14', '20', '280', '12', '1100', '132', '1232', 'Atharv', 'atharvsathe11@gmail.com', 'Paid', '13-10-2022', 'due_on_receipt', 'Sales Tax (1.50 %)', 'NA'),
(13, 'Medicine', '10', '200', '2000', '12', 'Medicine', '16', '20', '320', '12', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', '2320', '278.4', '2598.4', 'Atharv', 'atharvsathe11@gmail.com', 'Paid', '13-10-2022', 'due_on_receipt', '', ''),
(14, 'Medicine', '10', '200', '2000', '18', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', '2000', '360', '2360', 'Atharv', 'atharvsathe11@gmail.com', 'Unpaid', '13-10-2022', 'due_on_receipt', 'Sales Tax (1.50 %)', 'NA'),
(15, 'Medicine', '100', '200', '20000', '6', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', '20000', '1200', '21200', 'Atharv', 'atharvsathe11@gmail.com', 'Paid', '13-10-2022', 'due_on_receipt', '', ''),
(16, 'Medicine', '100', '20', '2000', '18', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', '2000', '360', '2360', 'Atharv', 'atharvsathe11@gmail.com', 'Unpaid', '13-10-2022', 'due_on_receipt', 'Sales Tax (1.50 %)', ''),
(17, 'Medicine', '10', '200', '2000', '12', 'Medicine', '16', '20', '320', '6', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', '2320', '259.2', '2579.2', 'Atharv', 'atharvsathe11@gmail.com', 'Unpaid', '14-10-2022', 'due_on_receipt', '', ''),
(18, 'Medicine', '10', '20', '200', '12', 'Medicine', '16', '20', '320', '6', 'Medicine', '15', '45', '675', '6', 'CAr', '14', '20', '280', '6', '1475', '100.5', '1575.5', 'Prasanna Sathe', 'pvsathe.21@gmail.com', 'Unpaid', '23-10-2022', 'due_on_receipt', '', ''),
(19, 'CAr', '10', '20', '200', '6', 'Medicine', '80', '30', '2400', '6', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', '2600', '156', '2756', 'Prasanna Sathe', 'pvsathe.21@gmail.com', 'Unpaid', '23-10-2022', 'due_on_receipt', '', 'na');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `products` varchar(100) DEFAULT NULL,
  `customer` varchar(100) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `status` varchar(100) DEFAULT NULL,
  `price` varchar(100) DEFAULT NULL,
  `billing` varchar(100) DEFAULT NULL,
  `date` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `products`, `customer`, `email`, `status`, `price`, `billing`, `date`) VALUES
(1, 'Medicine', 'Atharv', '', 'Active', '1000', 'One Time', '11-10-2022'),
(4, 'Medicine', 'Atharv', 'atharvsathe11@gmail.com', NULL, NULL, NULL, '13-10-2022'),
(5, 'Medicine', 'Atharv', 'atharvsathe11@gmail.com', 'Active', '1000', 'weeks2', '13-10-2022'),
(6, 'Medicine', 'Atharv', 'atharvsathe11@gmail.com', 'xx', NULL, NULL, '13-10-2022');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `paymeth` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`paymeth`) VALUES
('UPI');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `name` varchar(100) NOT NULL,
  `sprice` varchar(100) NOT NULL,
  `itemno` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`name`, `sprice`, `itemno`, `description`) VALUES
('Medicine', '2000', '1', 'ergerg'),
('CAr', '1000', '12', 'Na');

-- --------------------------------------------------------

--
-- Table structure for table `quotes`
--

CREATE TABLE `quotes` (
  `id` int(11) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `customer` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `date` varchar(255) DEFAULT NULL,
  `expiry` varchar(255) DEFAULT NULL,
  `quoteprefix` varchar(255) DEFAULT NULL,
  `quote` varchar(255) DEFAULT NULL,
  `stage` varchar(255) DEFAULT NULL,
  `salestax` varchar(255) DEFAULT NULL,
  `proposal` varchar(255) DEFAULT NULL,
  `item` varchar(255) DEFAULT NULL,
  `quantity` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `totalind` varchar(255) DEFAULT NULL,
  `taxper` varchar(255) DEFAULT NULL,
  `item1` varchar(255) DEFAULT NULL,
  `quantity1` varchar(255) DEFAULT NULL,
  `price1` varchar(255) DEFAULT NULL,
  `totalind1` varchar(255) DEFAULT NULL,
  `taxper1` varchar(255) DEFAULT NULL,
  `item2` varchar(255) DEFAULT NULL,
  `quantity2` varchar(255) DEFAULT NULL,
  `price2` varchar(255) DEFAULT NULL,
  `totalind2` varchar(255) DEFAULT NULL,
  `taxper2` varchar(255) DEFAULT NULL,
  `item3` varchar(255) DEFAULT NULL,
  `quantity3` varchar(255) DEFAULT NULL,
  `price3` varchar(255) DEFAULT NULL,
  `totalind3` varchar(255) DEFAULT NULL,
  `taxper3` varchar(255) DEFAULT NULL,
  `subtotal` varchar(255) DEFAULT NULL,
  `taxamount` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `custnot` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `quotes`
--

INSERT INTO `quotes` (`id`, `subject`, `customer`, `email`, `date`, `expiry`, `quoteprefix`, `quote`, `stage`, `salestax`, `proposal`, `item`, `quantity`, `price`, `totalind`, `taxper`, `item1`, `quantity1`, `price1`, `totalind1`, `taxper1`, `item2`, `quantity2`, `price2`, `totalind2`, `taxper2`, `item3`, `quantity3`, `price3`, `totalind3`, `taxper3`, `subtotal`, `taxamount`, `total`, `custnot`) VALUES
(1, '', 'Select', '', '23-10-2022', '23-10-2022', '', '', 'Accepted', '1', '', 'Select', '1', '20', '20', '12', 'Select', '1', '20', '220', '12', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', '240', '28.799999999999997', '268.8', ''),
(10, '', 'Atharv', 'atharvsathe11@gmail.com', '23-10-2022', '23-10-2022', 'NA', '', 'Accepted', '1', '', 'Medicine', '10', '20', '20', '12', 'Select', '1', '20', '220', '12', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', '240', '28.799999999999997', '268.8', ''),
(13, 'Quote Request', 'Atharv', 'atharvsathe11@gmail.com', '23-10-2022', '23-10-2022', NULL, NULL, 'Accepted', '1', 'NA', 'Medicine', '10', '20', '20', '12', 'Medicine', '10', '20', '220', '12', 'Medicine', '15', '', '0', '6', 'Medicine', '14', '', '0', '6', '240', '28.799999999999997', '268.8', 'REVERT ASAP'),
(14, 'Quote Request', 'Atharv', 'atharvsathe11@gmail.com', '23-10-2022', '23-10-2022', 'NA', '', 'Accepted', '1', 'NOTHING', 'Medicine', '10', '20', '20', '12', 'Medicine', '16', '20', '220', '12', 'Medicine', '15', '', '0', '6', 'Medicine', '14', '', '0', '6', '240', '28.799999999999997', '268.8', 'NA'),
(15, 'Quote Request', 'Atharv', 'atharvsathe11@gmail.com', '23-10-2022', '23-10-2022', NULL, NULL, 'Accepted', '1', 'Nothing', 'Medicine', '10', '20', '20', '12', 'Medicine', '16', '20', '220', '12', 'Medicine', '15', '', '0', '6', 'Medicine', '14', '', '0', '6', '240', '28.799999999999997', '268.8', 'REPLY ASAP'),
(16, 'Quote Request', 'Atharv', 'atharvsathe11@gmail.com', '23-10-2022', '23-10-2022', NULL, NULL, 'Accepted', '1', '', 'CAr', '1', '20', '20', '12', 'Medicine', '11', '20', '220', '12', 'Select', '1', '', '0', '6', 'Select', '1', '', '0', '6', '240', '28.799999999999997', '268.8', 'REPLY ASAP');

-- --------------------------------------------------------

--
-- Table structure for table `reqquote`
--

CREATE TABLE `reqquote` (
  `id` int(11) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `customer` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `proposal` varchar(255) DEFAULT NULL,
  `item` varchar(255) DEFAULT NULL,
  `quantity` varchar(255) DEFAULT NULL,
  `item1` varchar(255) DEFAULT NULL,
  `quantity1` varchar(255) DEFAULT NULL,
  `item2` varchar(255) DEFAULT NULL,
  `quantity2` varchar(255) DEFAULT NULL,
  `item3` varchar(255) DEFAULT NULL,
  `quantity3` varchar(255) DEFAULT NULL,
  `custnot` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reqquote`
--

INSERT INTO `reqquote` (`id`, `subject`, `customer`, `email`, `proposal`, `item`, `quantity`, `item1`, `quantity1`, `item2`, `quantity2`, `item3`, `quantity3`, `custnot`) VALUES
(1, 'Quote Request', 'Atharv', 'atharvsathe11@gmail.com', 'NA', 'Medicine', '11', 'Select', '1', 'Select', '1', 'Select', '1', 'Need It ASAP');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quotes`
--
ALTER TABLE `quotes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reqquote`
--
ALTER TABLE `reqquote`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `quotes`
--
ALTER TABLE `quotes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `reqquote`
--
ALTER TABLE `reqquote`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
