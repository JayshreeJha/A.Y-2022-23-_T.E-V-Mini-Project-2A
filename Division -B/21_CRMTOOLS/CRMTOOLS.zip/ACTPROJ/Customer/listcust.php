<!DOCTYPE html>

<html>

<head>

<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>WeConnect</title>

    <link rel="apple-touch-icon" sizes="180x180" href="/icons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/icons/favicon-16x16.png">
    <link rel="manifest" href="/icons/site.webmanifest">
    <link rel="mask-icon" href="/icons/safari-pinned-tab.svg" color="#5bbad5">
    <link rel="shortcut icon" href="/icons/favicon.ico">
    <meta name="msapplication-TileColor" content="#2d89ef">
    <meta name="msapplication-config" content="/icons/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
    <link href="../weconnect.css" rel="stylesheet">
    <link href="../dark_extra.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="modal.css" />
    <link rel="stylesheet" type="text/css" href="select2.min.css" />
    
    
</head>

<body class="fixed-nav ">
<section>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">

                <ul class="nav" id="side-menu">

    <li class="nav-header">
        <div class="dropdown profile-element"> <span>

                        <img src="../default-user-avatar.png"  class="img-circle" style="max-width: 64px;" alt="">
                                                             </span>
            <a data-toggle="dropdown" class="dropdown-toggle" href="#" aria-expanded="false">
                            <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold">Administrator</strong>
                             </span> <span class="text-muted text-xs block">My Account <b class="caret"></b></span> </span> </a>
            <ul class="dropdown-menu animated fadeIn m-t-xs">

                <li><a href="../DropdownAdmin/editprofile.php">Edit Profile</a></li>
                <li><a href="../DropdownAdmin/changepass.php">Change Password</a></li>

                <li class="divider"></li>
                <li><a href="../Loginpage/loginpage.php">Logout</a></li>
            </ul>
        </div>
    </li>

    

            <li class="active"><a href="../Dashboard/dashboard.php"></i> <span class="nav-label">Dashboard</span></a></li>
        

        <li class="">
        <a href="#"></i> <span class="nav-label">Customers &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼ </span></a>
        <ul class="nav nav-second-level">
            <li><a href="../Customer/addcust.php">Add Customer</a></li>
            <li><a href="../Customer/listcust.php">List Customers</a></li>
            
                    </ul>
    </li>
    

        <li ><a href="../Companies/companies.php"> <span class="nav-label">Companies</span></a></li>
            

            <li class="">
                <a href="#"><span class="nav-label">Sales &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼ </span></span></a>
                <ul class="nav nav-second-level">

                        <li><a href="../Sales/invoices.php">Invoices</a></li>
                        <li><a href="../Sales/newinvoice.php">New Invoice</a></li>
                        <li><a href="../Sales/recurinvo.php">Recurring Invoices</a></li>
                        <li><a href="../Sales/quotes.php">Quotes</a></li>
                        <li><a href="../Sales/newquotes.php">Create New Quote</a></li>
                        <li><a href="../Sales/quotesreq.php">Requested Quotes</a></li>

                </ul>
            </li>



            <li class="">
                <a href="#"></i> <span class="nav-label">Orders &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼</span></span></a>
                <ul class="nav nav-second-level">
                
                    <li><a href="../Order/listorder.php">List All Orders</a></li>
                    <li><a href="../Order/addorder.php">Add New Order</a></li>
                    <li><a href="../Order/listorderreq.php">Requested Order</a></li>

                </ul>
            </li>
    
            <li class="">
            <a href="#"><span class="nav-label">Products & Services &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼</span></span></a>
            <ul class="nav nav-second-level">
                <li><a href="../Pns/products.php">Products</a></li>
                <li><a href="../Pns/newproduct.php">New Product</a></li>

            </ul>
        </li>
            
            <li class="">
            <a href="#"> <span class="nav-label">Reports &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼</span></span></a>
            <ul class="nav nav-second-level">


                <li><a href="../Reports/incomereports.php">Income Reports</a></li>
                <li><a href="../Reports/expense.php">Expense Reports</a></li>
                <li><a href="../Reports/incvsexp.php">Income Vs Expense</a></li>
                <li><a href="../Reports/alltransact.php">All Transactions</a></li>

            </ul>
            </li>

            
                <li class="" id="li_settings">
            <a href="#"> <span class="nav-label">Settings &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼ </span></span></a>
            <ul class="nav nav-second-level">
                
                
                <li><a href="../Settings/paymeth.php">Payment Methods</a></li>
               
            </ul>
            </li>
    



</ul>

            </div>
        </nav>
        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-fixed-top white-bg" role="navigation" style="margin-bottom: 0">

                    <img class="logo" style="max-height: 40px; width: auto;" src="abc.png" alt="Logo">

                  
                    
                    <ul class="nav navbar-top-links navbar-right pull-right">


                        <li class="dropdown navbar-user">

                            <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
                                <img src="../default-user-avatar.png" alt="">
                                <span class="hidden-xs">Administrator</span> <b class="caret"></b>
                            </a>
                            <ul class="dropdown-menu animated fadeIn">
                                <li class="arrow"></li>

                                <li><a href="../DropdownAdmin/editprofile.php">Edit Profile</a></li>
                                <li><a href="../DropdownAdmin/changepass.php">Change Password</a></li>
                                <li class="divider"></li>
                                <li><a href="../Loginpage/loginpage.php">Logout</a></li>

                            </ul>
                        </li>


                    </ul>

                </nav>
            </div>

            <div class="row wrapper white-bg page-heading">
                <div class="col-lg-12">
                    <h2 style="color: #2F4050; font-size: 16px; font-weight: 400; margin-top: 18px"> Contacts </h2>

                </div>

            </div>

            <div class="wrapper wrapper-content animated fadeIn">
                
                
    
        <div class="row">



            <div class="col-md-12">



                <div class="panel panel-default">
                    <div class="panel-body">

                        <a href="addcust.php" class="btn btn-success"></i> Add Customer</a>
                    </div>
                    <div class="panel-body">

                        

                        <table class="table table-bordered table-hover sys_table footable"  data-filter="#foo_filter" data-page-size="50">
                            <thead>
                            <tr>
                                
                                <th>Name</th>
                                <th>Company Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                
                            </tr>
                            
                            </thead>
                         
                            <tbody>

                            
                            </tbody>

                            <tfoot>
                            
                            <?php
                                include("../../OurProj/Connectionfile.php");
                                $sql = "SELECT name,company,email,phone FROM customer";
                                $result = $conn->query($sql);
                                if ($result->num_rows > 0) {
                                    $options= mysqli_fetch_all($result, MYSQLI_ASSOC);
                                }
                                $conn->close();
                                    
                                foreach ($options as $option)
                                 {
                                                ?>
                                        <tr> 
                                            <td> <?php echo $option['name'];?></td> 
                                            <td> <?php echo $option['company'];?></td> 
                                            <td> <?php echo $option['email'];?></td> 
                                            <td> <?php echo $option['phone'];?></td>
                                        </tr>
                                <?php
                                 }
                            ?>
                            <tr>
                                <td colspan="7">
                                    <ul class="pagination">
                                    </ul>
                                </td>
                            </tr>
                            </tfoot>

                        </table>

                    </div>
                </div>
            </div>

        </div>



                <div id="ajax-modal" class="modal container fade-scale" tabindex="-1" style="display: none;"></div>
            </div>

                            
                            
        </div>

       




<script src="weconnect.js"></script>



    <script type="text/javascript" src="footable.all.min.js"></script>

<script>
    $(function () {
        "use strict";
        matForms();
            });

</script>
</body>

        </html>