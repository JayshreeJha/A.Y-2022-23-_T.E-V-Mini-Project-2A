<!DOCTYPE html>

<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>WeConnect</title>

    <link rel="apple-touch-icon" sizes="180x180" href="/icons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/icons/favicon-16x16.png">
    <link rel="manifest" href="/icons/site.webmanifest">
    <link rel="mask-icon" href="/icons/safari-pinned-tab.svg" color="#5bbad5">
    <link rel="shortcut icon" href="/icons/favicon.ico">
    <meta name="msapplication-TileColor" content="#2d89ef">
    <meta name="msapplication-config" content="/icons/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
    <link href="../weconnect.css" rel="stylesheet">
    <link href="../dark_extra.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="modal.css" />
    <link rel="stylesheet" type="text/css" href="select2.min.css" />
    
    <?php
    
    $fullname = NULL;
    $company = NULL; 
    $email = NULL; 
    $phone = NULL; 
    $address= NULL; 
    $city= NULL; 
    $state= NULL; 
    $zip= NULL; 
    $country= NULL; 
    $currency= NULL; 
    $password= NULL; 
    $confirmpassword= NULL;
    $name_error = NULL ;
    $email_error = NULL ;
    $phone_error = NULL ;
    $address_error = NULL ;
    $city_error = NULL ;
    $state_error = NULL ;
    $zip_error = NULL ;
    $password_error = NULL ;
    $confirmpassword_error = NULL ;
    $passwordmatch_error = NULL;
    $success = NULL;
    $phonenumeric_error = NULL;
    $phonedigi_error = NULL;


        if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
            if (isset($_POST['abc'])) 
            {
                $fullname = $_POST['account'];
                $company = $_POST['cid'];
                $email = $_POST['email'];
                $phone = $_POST['phone'];
                $address= $_POST['address'];
                $city= $_POST['city'];
                $state= $_POST['state'];
                $zip= $_POST['zip'];
                $country= $_POST['country'];
                $currency= $_POST['currency'];
                $password= $_POST['password'];
                $confirmpassword= $_POST['cpassword'];

                if(empty($fullname) == TRUE ){echo $name_error = "Name field is Required";
                    if($name_error != null){
                    ?> <style>.name-error{display:block}</style> <?php
                }}
                elseif(empty($email) == TRUE ){echo $email_error = "Email field is Required"; 
                    if($email_error != null){
                        ?> <style>.email-error{display:block}</style> <?php
                    }}
                elseif(empty($phone) == TRUE ){echo $phone_error = "Phone Number field is Required";
                    if($phone_error != null){
                        ?> <style>.phone-error{display:block}</style> <?php
                    }
                    }
                elseif(empty($address) == TRUE ){echo $address_error = "Address field is Required";if($address_error != null){
                    ?> <style>.address-error{display:block}</style> <?php
                }}
                elseif(empty($city) == TRUE ){echo $city_error = "City field is Required";if($city_error != null){
                    ?> <style>.city-error{display:block}</style> <?php
                }
                }
                elseif(empty($state) == TRUE ){echo $state_error = "State field is Required";
                    if($state_error != null){
                        ?> <style>.state-error{display:block}</style> <?php
                    }}
                elseif(empty($zip) == TRUE ){echo $zip_error = "Zip field is Required";if($zip_error != null){
                    ?> <style>.zip-error{display:block}</style> <?php
                }
                }
                elseif(empty($password) == TRUE ){echo $password_error = "Password field is Required";if($password_error != null){
                    ?> <style>.password-error{display:block}</style> <?php
                }
                }
                elseif(empty($confirmpassword) == TRUE ){echo $confirmpassword_error = "Confirmpassword field is Required";if($confirmpassword_error != null){
                    ?> <style>.confirmpassword-error{display:block}</style> <?php
                }}
                elseif(is_numeric($phone)== FALSE){echo $phonenumeric_error = "Phone Number must be Numeric";if($phonenumeric_error != null){
                    ?> <style>.phonenumeric-error{display:block}</style> <?php
                }}
                elseif(strlen($phone) <> 10 ){echo $phonedigi_error = "Phone Number must be of 10 Digits only";if($phonedigi_error != null){
                    ?> <style>.phonedigi-error{display:block}</style> <?php
                }}
                elseif($password == $confirmpassword)
                    {
                        include("../../OurProj/Connectionfile.php");
                        $sql = "Insert into customer (name,company,email,phone,address,city,state,zip,country,currency,password) VALUES('$fullname','$company','$email','$phone','$address','$city','$state','$zip','$country','$currency','$confirmpassword')";
                        $result = $conn->query($sql);
                        $conn->close();
                        $fullname = NULL;
                        $company = NULL; 
                        $email = NULL; 
                        $phone = NULL; 
                        $address= NULL; 
                        $city= NULL; 
                        $state= NULL; 
                        $zip= NULL; 
                        $country= NULL; 
                        $currency= NULL; 
                        $password= NULL; 
                        $confirmpassword= NULL;
                        echo $success = "User Created Successfully";
                       

                    }
                else{echo $passwordmatch_error = "Password Fields Do Not Match";if($passwordmatch_error != null){
                    ?> <style>.passwordmatch-error{display:block}</style> <?php
                }}
                
               
            }
        
        }
    ?>
<head>    

<body class="fixed-nav ">
<section>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">

                <ul class="nav" id="side-menu">

    <li class="nav-header">
        <div class="dropdown profile-element"> <span>

                        <img src="../default-user-avatar.png"  class="img-circle" style="max-width: 64px;" alt="">
                                                             </span>
            <a data-toggle="dropdown" class="dropdown-toggle" href="#" aria-expanded="false">
                            <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold">Administrator</strong>
                             </span> <span class="text-muted text-xs block">My Account <b class="caret"></b></span> </span> </a>
            <ul class="dropdown-menu animated fadeIn m-t-xs">

                <li><a href="../DropdownAdmin/editprofile.php">Edit Profile</a></li>
                <li><a href="../DropdownAdmin/changepass.php">Change Password</a></li>

                <li class="divider"></li>
                <li><a href="../Loginpage/loginpage.php">Logout</a></li>
            </ul>
        </div>
    </li>

    

            <li class="active"><a href="../Dashboard/dashboard.php"></i> <span class="nav-label">Dashboard</span></a></li>
        

        <li class="">
        <a href="#"></i> <span class="nav-label">Customers &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼ </span></a>
        <ul class="nav nav-second-level">
            <li><a href="../Customer/addcust.php">Add Customer</a></li>
            <li><a href="../Customer/listcust.php">List Customers</a></li>
            
                    </ul>
    </li>
    

        <li ><a href="../Companies/companies.php"> <span class="nav-label">Companies</span></a></li>
            

            <li class="">
                <a href="#"><span class="nav-label">Sales &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼ </span></span></a>
                <ul class="nav nav-second-level">

                        <li><a href="../Sales/invoices.php">Invoices</a></li>
                        <li><a href="../Sales/newinvoice.php">New Invoice</a></li>
                        <li><a href="../Sales/recurinvo.php">Recurring Invoices</a></li>
                        <li><a href="../Sales/quotes.php">Quotes</a></li>
                        <li><a href="../Sales/newquotes.php">Create New Quote</a></li>
                        <li><a href="../Sales/quotesreq.php">Requested Quotes</a></li>

                </ul>
            </li>



            <li class="">
                <a href="#"></i> <span class="nav-label">Orders &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼</span></span></a>
                <ul class="nav nav-second-level">
                
                    <li><a href="../Order/listorder.php">List All Orders</a></li>
                    <li><a href="../Order/addorder.php">Add New Order</a></li>
                    <li><a href="../Order/listorderreq.php">Requested Order</a></li>

                </ul>
            </li>
    
            <li class="">
            <a href="#"><span class="nav-label">Products & Services &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼</span></span></a>
            <ul class="nav nav-second-level">
                <li><a href="../Pns/products.php">Products</a></li>
                <li><a href="../Pns/newproduct.php">New Product</a></li>

            </ul>
        </li>
            
            <li class="">
            <a href="#"> <span class="nav-label">Reports &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼</span></span></a>
            <ul class="nav nav-second-level">


                <li><a href="../Reports/incomereports.php">Income Reports</a></li>
                <li><a href="../Reports/expense.php">Expense Reports</a></li>
                <li><a href="../Reports/incvsexp.php">Income Vs Expense</a></li>
                <li><a href="../Reports/alltransact.php">All Transactions</a></li>

            </ul>
            </li>

            
                <li class="" id="li_settings">
            <a href="#"> <span class="nav-label">Settings &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼ </span></span></a>
            <ul class="nav nav-second-level">
                
                <li><a href="../Settings/paymeth.php">Payment Methods</a></li>
               
            </ul>
            </li>
    



</ul>

            </div>
        </nav>
        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-fixed-top white-bg" role="navigation" style="margin-bottom: 0">

                    <img class="logo" style="max-height: 40px; width: auto;" src="abc.png" alt="Logo">

                  
                    
                    <ul class="nav navbar-top-links navbar-right pull-right">


                        <li class="dropdown navbar-user">

                            <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
                                <img src="../default-user-avatar.png" alt="">
                                <span class="hidden-xs">Administrator</span> <b class="caret"></b>
                            </a>
                            <ul class="dropdown-menu animated fadeIn">
                                <li class="arrow"></li>

                                <li><a href="../DropdownAdmin/editprofile.php">Edit Profile</a></li>
                                <li><a href="../DropdownAdmin/changepass.php">Change Password</a></li>
                                <li class="divider"></li>
                                <li><a href="../Loginpage/loginpage.php">Logout</a></li>

                            </ul>
                        </li>


                    </ul>

                </nav>
            </div>

            <div class="row wrapper white-bg page-heading">
                <div class="col-lg-12">
                    <h2 style="color: #2F4050; font-size: 16px; font-weight: 400; margin-top: 18px"> Contacts </h2>

                </div>

            </div>

            <div class="wrapper wrapper-content animated fadeIn">
                
                

    <div class="wrapper wrapper-content">
        <div class="row">

            <div class="col-md-12">



                    <div class="ibox-content" id="ibox_form">
                        <div class="alert alert-danger" id="emsg">
                            <span id="emsgbody"></span>
                        </div>

                        <form class="form-horizontal" action ='' method = 'post' id="rform">

                            <div class="row">
                                <div class="col-md-6 col-sm-12">
                                    <div class="form-group"><label class="col-md-4 control-label" for="account" >Full Name<small class="red">*</small> </label>

                                        <div class="col-lg-8"><input type="text" id="account" name="account" class="form-control" value="<?php echo $fullname; ?>"autofocus>
                                        <p class = "error name-error"><?php echo $name_error; ?></p>

                                        </div>
                                    </div>

                                    <?php include("..\..\OurProj\Connectionfile.php")?>

                                    <?php

                                    $sql = "select companyname from companies";

                                        $result = $conn->query($sql);
                                
                                        if ($result->num_rows > 0) {
                                            $options= mysqli_fetch_all($result, MYSQLI_ASSOC);
                                        }
                                        
                                        $conn->close();

                                    ?>
                                    

                                    <div class="form-group"><label class="col-md-4 control-label" for="cid">Company</label>

                                        <div class="col-lg-8">

                                            <select id="cid" name="cid" class="form-control">

                                                <?php 
                                                    foreach ($options as $option) {
                                                ?>
                                                    <option><?php echo $option['companyname']; ?> </option>
                                                        
                                                <?php 
                                                    }
                                                ?>
                                            </select>
                                            
                                            <span class="help-block"><a href="../Companies/newcompany.php" class="add_company"> New Company</a> </span>

                                        </div>
                                    </div>

                                    <div class="form-group"><label class="col-md-4 control-label" for="email">Email</label>

                                        <div class="col-lg-8"><input type="text" id="email" name="email" value = "<?php echo $email?>"class="form-control">
                                        <p class = "error email-error"><?php echo $email_error; ?></p>

                                        </div>
                                    </div>
                                    <div class="form-group"><label class="col-md-4 control-label" for="phone">Phone</label>

                                        <div class="col-lg-8"><input type="text" id="phone" name="phone" value = "<?php echo $phone?>"class="form-control">
                                        <p class = "error phone-error"><?php echo $phone_error; ?></p>
                                        <p class = "error phonedigi-error"><?php echo $phonedigi_error; ?></p>
                                        <p class = "error phonenumeric-error"><?php echo $phonenumeric_error; ?></p>

                                        </div>
                                    </div>
                                    <div class="form-group"><label class="col-md-4 control-label" for="address">Address</label>

                                        <div class="col-lg-8"><input type="text" id="address" name="address" value = "<?php echo $address?>" class="form-control">
                                        <p class = "error address-error"><?php echo $address_error; ?></p>

                                        </div>
                                    </div>


                                    <div class="form-group"><label class="col-md-4 control-label" for="city">City</label>

                                        <div class="col-lg-8"><input type="text" id="city" name="city" value = "<?php echo $city?>"class="form-control">
                                        <p class = "error city-error"><?php echo $city_error; ?></p>

                                        </div>
                                    </div>
                                    <div class="form-group"><label class="col-md-4 control-label" for="state">State/Region</label>

                                        <div class="col-lg-8"><input type="text" id="state" name="state" value = "<?php echo $state?>"class="form-control">
                                        <p class = "error state-error"><?php echo $state_error; ?></p>

                                        </div>
                                    </div>
                                    <div class="form-group"><label class="col-md-4 control-label" for="zip">ZIP/Postal Code </label>

                                        <div class="col-lg-8"><input type="text" id="zip" name="zip"value = "<?php echo $zip?>" class="form-control">
                                        <p class = "error zip-error"><?php echo $zip_error; ?></p>

                                        </div>
                                    </div>
                                    <div class="form-group"><label class="col-md-4 control-label" for="country">Country</label>

                                        <div class="col-lg-8">

                                            <select name="country" id="country" class="form-control">
                                                <option value="">Select Country</option>
                                                <option value="Afghanistan">Afghanistan</option>
                                                <option value="Australia">Australia</option>
                                                <option value="Bangladesh">Bangladesh</option>
                                                <option value="Brazil">Brazil</option>
                                                <option value="Canada">Canada</option>
                                                <option value="China">China</option>
                                                <option value="India">India</option>
                                                <option value="Italy">Italy</option>
                                                <option value="Japan">Japan</option>
                                                <option value="Malaysia">Malaysia</option>
                                                <option value="Romania">Romania</option>
                                                <option value="Russian Federation">Russian Federation</option>
                                                <option value="Sri Lanka">Sri Lanka</option>
                                                <option value="United Arab Emirates">United Arab Emirates</option>
                                                <option value="United Kingdom">United Kingdom</option>
                                                <option value="United States" selected="selected">United States</option>
                                                <option value="Zimbabwe">Zimbabwe</option>
                                            </select>

                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-6 col-sm-12">


                                    <div class="form-group"><label class="col-md-4 control-label" for="currency">Currency</label>

                                        <div class="col-lg-8">
                                            <select id="currency" name="currency" class="form-control">
                                                    <option >INR</option>

                                                    
                                            </select>
                                        </div>
                                    </div>

                                    
                                    <div class="form-group"><label class="col-md-4 control-label" for="password">Password</label>

                                        <div class="col-lg-8"><input type="password" id="password" value = "<?php echo $password?>" name="password" class="form-control">
                                        <p class = "error password-error"><?php echo $password_error; ?></p>

                                        </div>
                                    </div>

                                    <div class="form-group"><label class="col-md-4 control-label" for="cpassword">Confirm Password</label>

                                        <div class="col-lg-8"><input type="password" id="cpassword" value = "<?php echo $confirmpassword?>"name="cpassword" class="form-control">
                                        <p class = "error confirmpassword-error"><?php echo $confirmpassword_error; ?></p>
                                        <p class = "error passwordmatch-error"><?php echo $passwordmatch_error; ?></p>

                                        </div>
                                    </div>

                                </div>
                            </div>


                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="col-md-offset-2 col-lg-10">

                                            <button class="md-btn md-btn-primary waves-effect waves-light" name= 'abc' type="submit" id="submit">Save</button>
                                            <p class = "error success"><?php echo $success; ?></p>

                                        </div>
                                    </div>
                                </div>
                            </div>


                        </form>
                    </div>
                </div>
            </div>
        </div>


    </div>


                <div id="ajax-modal" class="modal container fade-scale" tabindex="-1" style="display: none;"></div>
            </div>


    </div>


<script src="weconnect.js"></script>
<script type="text/javascript" src="modal.js"></script>
<script type="text/javascript" src="select2.min.js"></script>
<script type="text/javascript" src="en.js"></script>
<script type="text/javascript" src="add-contact.js"></script>
        

<script>
    $(function () {
        "use strict";
        matForms();
                
 $("#country").select2({
 theme: "bootstrap"
 });
 
            });

</script>
</body>

        </html>





        