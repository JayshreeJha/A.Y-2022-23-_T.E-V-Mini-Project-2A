<!DOCTYPE html>

<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>WeConnect</title>

    <link rel="apple-touch-icon" sizes="180x180" href="/icons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/icons/favicon-16x16.png">
    <link rel="manifest" href="/icons/site.webmanifest">
    <link rel="mask-icon" href="/icons/safari-pinned-tab.svg" color="#5bbad5">
    <link rel="shortcut icon" href="/icons/favicon.ico">
    <meta name="msapplication-TileColor" content="#2d89ef">
    <meta name="msapplication-config" content="/icons/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
    <link href="../weconnect.css" rel="stylesheet">
    <link href="../dark_extra.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="modal.css" />
    <link rel="stylesheet" type="text/css" href="select2.min.css" />

    
    
            <link rel="stylesheet" type="text/css" href="select2.min.css" />
        <link rel="stylesheet" type="text/css" href="modal.css" />
        <link rel="stylesheet" type="text/css" href="datepicker.min.css" />
        <link rel="stylesheet" type="text/css" href="redactor.css" />
    
        <?php
        $success = NULL;
        if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
            if(isset($_POST['jay'])){
                
                $item = $_POST['desc'];
                $item1 = $_POST['desc1'];
                $item2 = $_POST['desc2'];
                $item3 = $_POST['desc3'];
                $quantity = $_POST['qty'];
                $quantity1 = $_POST['qty1'];
                $quantity2 = $_POST['qty2'];
                $quantity3 = $_POST['qty3'];
                $price = $_POST['amount'];
                $price1 = $_POST['amount1'];
                $price2 = $_POST['amount2'];
                $price3 = $_POST['amount3'];
                $totalind = $_POST['auth'];
                $totalind1 = $_POST['auth1'];
                $totalind2 = $_POST['auth2'];
                $totalind3 = $_POST['auth3'];
                $taxper = $_POST['taxed'];
                $taxper1 = $_POST['taxed1'];
                $taxper2 = $_POST['taxed2'];
                $taxper3 = $_POST['taxed3'];
                $subtotal = $_POST['ppp'];
                $taxamount = $_POST['lll'];
                $total = $_POST['kkk'];
                $customer = $_POST['cid'];
                $status = $_POST['currency'];
                $date = date("d-m-Y");
                $duedate = $_POST['duedate'];
                $salestax = $_POST['tid'];
                $invoterm = $_POST['not'];
                $a = strpos($customer,"-");
                $b = substr($customer,$a,);
                $custname = substr($customer,0,$a);
                $custemail = substr($b,1);



                include("../../OurProj/Connectionfile.php");

                $sql = "Insert into invoices (item,quantity,price,totalind,taxper,item1,quantity1,price1,totalind1,taxper1,item2,quantity2,price2,totalind2,taxper2,item3,quantity3,price3,totalind3,taxper3,subtotal,taxamount,total,customer,email,status,date,duedate,salestax,invoterm) VALUES('$item','$quantity','$price','$totalind','$taxper','$item1','$quantity1','$price1','$totalind1','$taxper1','$item2','$quantity2','$price2','$totalind2','$taxper2','$item3','$quantity3','$price3','$totalind3','$taxper3','$subtotal','$taxamount','$total','$custname','$custemail','$status','$date','$duedate','$salestax','$invoterm')";
                $result = $conn->query($sql);
                $conn->close();
                ?>
                <!DOCTYPE html>
                <html>
                    <meta http-equiv = "refresh" content = "0; url =../Sales/invoices.php"/>
                </html>
            <?php
            }
        }
        ?>  
    
    
</head>

<body class="fixed-nav ">
<section>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">

                <ul class="nav" id="side-menu">

    <li class="nav-header">
        <div class="dropdown profile-element"> <span>

                        <img src="../default-user-avatar.png"  class="img-circle" style="max-width: 64px;" alt="">
                                                             </span>
            <a data-toggle="dropdown" class="dropdown-toggle" href="#" aria-expanded="false">
                            <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold">Administrator</strong>
                             </span> <span class="text-muted text-xs block">My Account <b class="caret"></b></span> </span> </a>
            <ul class="dropdown-menu animated fadeIn m-t-xs">

                <li><a href="../DropdownAdmin/editprofile.php">Edit Profile</a></li>
                <li><a href="../DropdownAdmin/changepass.php">Change Password</a></li>

                <li class="divider"></li>
                <li><a href="../Loginpage/loginpage.php">Logout</a></li>
            </ul>
        </div>
    </li>

    

            <li class="active"><a href="../Dashboard/dashboard.php"></i> <span class="nav-label">Dashboard</span></a></li>
        

        <li class="">
        <a href="#"></i> <span class="nav-label">Customers &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼ </span></a>
        <ul class="nav nav-second-level">
            <li><a href="../Customer/addcust.php">Add Customer</a></li>
            <li><a href="../Customer/listcust.php">List Customers</a></li>
            
                    </ul>
    </li>
    

        <li ><a href="../Companies/companies.php"> <span class="nav-label">Companies</span></a></li>
            

            <li class="">
                <a href="#"><span class="nav-label">Sales &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼ </span></span></a>
                <ul class="nav nav-second-level">

                        <li><a href="../Sales/invoices.php">Invoices</a></li>
                        <li><a href="../Sales/newinvoice.php">New Invoice</a></li>
                        <li><a href="../Sales/recurinvo.php">Recurring Invoices</a></li>
                        <li><a href="../Sales/quotes.php">Quotes</a></li>
                        <li><a href="../Sales/newquotes.php">Create New Quote</a></li>
                        <li><a href="../Sales/quotesreq.php">Requested Quotes</a></li>

                </ul>
            </li>



            <li class="">
                <a href="#"></i> <span class="nav-label">Orders &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼</span></span></a>
                <ul class="nav nav-second-level">
                
                    <li><a href="../Order/listorder.php">List All Orders</a></li>
                    <li><a href="../Order/addorder.php">Add New Order</a></li>
                    <li><a href="../Order/listorderreq.php">Requested Order</a></li>

                </ul>
            </li>
    
            <li class="">
            <a href="#"><span class="nav-label">Products & Services &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼</span></span></a>
            <ul class="nav nav-second-level">
                <li><a href="../Pns/products.php">Products</a></li>
                <li><a href="../Pns/newproduct.php">New Product</a></li>

            </ul>
        </li>
            
            <li class="">
            <a href="#"> <span class="nav-label">Reports &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼</span></span></a>
            <ul class="nav nav-second-level">


                <li><a href="../Reports/incomereports.php">Income Reports</a></li>
                <li><a href="../Reports/expense.php">Expense Reports</a></li>
                <li><a href="../Reports/incvsexp.php">Income Vs Expense</a></li>
                <li><a href="../Reports/alltransact.php">All Transactions</a></li>

            </ul>
            </li>

            
                <li class="" id="li_settings">
            <a href="#"> <span class="nav-label">Settings &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼ </span></span></a>
            <ul class="nav nav-second-level">
                
             
                <li><a href="../Settings/paymeth.php">Payment Methods</a></li>
               
            </ul>
            </li>
    



</ul>

            </div>
        </nav>
        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-fixed-top white-bg" role="navigation" style="margin-bottom: 0">

                    <img class="logo" style="max-height: 40px; width: auto;" src="../abc.png" alt="Logo">

                  
                    
                    <ul class="nav navbar-top-links navbar-right pull-right">


                        <li class="dropdown navbar-user">

                            <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
                                <img src="../default-user-avatar.png" alt="">
                                <span class="hidden-xs">Administrator</span> <b class="caret"></b>
                            </a>
                            <ul class="dropdown-menu animated fadeIn">
                                <li class="arrow"></li>

                                <li><a href="../DropdownAdmin/editprofile.php">Edit Profile</a></li>
                                <li><a href="../DropdownAdmin/changepass.php">Change Password</a></li>
                                <li class="divider"></li>
                                <li><a href="../Loginpage/loginpage.php">Logout</a></li>

                            </ul>
                        </li>


                    </ul>

                </nav>
            </div>

            <div class="row wrapper white-bg page-heading">
                <div class="col-lg-12">
                    <h2 style="color: #2F4050; font-size: 16px; font-weight: 400; margin-top: 18px"> Add Invoice </h2>

                </div>

            </div>

            <div class="wrapper wrapper-content animated fadeIn">
                
                

    <div class="row" id="ibox_form">

        <form id="invform" method="post">
            <div class="col-md-12">
                <div class="alert alert-danger" id="emsg">
                    <span id="emsgbody"></span>
                </div>
            </div>

            <div class="col-md-8">

                <div class="panel panel-default">
                    <div class="panel-body">

                        <div class="table-responsive m-t">
                            <table class="table invoice-table" id="invoice_items">
                                <thead>
                                <tr>
                                    <th width="10%">#</th>
                                    <th width="50%">Item Name</th>
                                    <th width="10%">Qty</th>
                                    <th width="10%">Price</th>
                                    <th width="10%">Total</th>
                                    <th width="10%">Tax (%)</th>

                                </tr>
                                </thead>
                                <tbody>
                                <tr> 
                                    <td></td> 
                                    <td> <select class="form-control taxed" id= "abc" name="desc">
                                    <option>Select</option>
                                    
                                    <?php include("..\..\OurProj\Connectionfile.php")?>

                                    <?php

                                    $sql = "select name from products";

                                        $result = $conn->query($sql);

                                        if ($result->num_rows > 0) {
                                            $opt= mysqli_fetch_all($result, MYSQLI_ASSOC);
                                        }
                                        
                                        $conn->close();

                                    ?>
                                    <?php 
                                                    foreach ($opt as $option) {
                                                ?>
                                                    <option><?php echo $option['name']; ?> </option>
                                                        
                                                <?php 
                                                    }
                                                ?>

                                    </select> </td> 
                                    <td><input type="text" id = "abc1" onchange="getChecked()" class="form-control qty" value="1" name="qty"></td>
                                    <td><input type="text" id = "abc2" onchange="getChecked()" class="form-control item_price" name="amount" value=""></td> 
                                    <td><input type="text" id = "abc3" class="form-control lvtota" name="auth" readonly="" value= ""></td> 
                                    <td> <select class="form-control taxed" onchange="getChecked()"id= "abc4" name="taxed"> <option>6</option><option>12</option> <option>18</option></select></td>
                                </tr>
                            
                                    <tr> 
                                    <td></td> 
                                    <td> <select class="form-control taxed" id= "abc10" name="desc1">
                                    <option>Select</option>
                                    
                                    <?php include("..\..\OurProj\Connectionfile.php")?>

                                    <?php

                                    $sql = "select name from products";

                                        $result = $conn->query($sql);

                                        if ($result->num_rows > 0) {
                                            $opt= mysqli_fetch_all($result, MYSQLI_ASSOC);
                                        }
                                        
                                        $conn->close();

                                    ?>
                                    <?php 
                                                    foreach ($opt as $option) {
                                                ?>
                                                    <option><?php echo $option['name']; ?> </option>
                                                        
                                                <?php 
                                                    }
                                                ?>
                                
                                    </select> </td> 
                                    <td><input type="text" id = "abc11" onchange="getChecked()" class="form-control qty" value="1" name="qty1"></td>
                                    <td><input type="text" id = "abc12" onchange="getChecked()" class="form-control item_price" name="amount1" value=""></td> 
                                    <td><input type="text" id = "abc13" class="form-control lvtota" readonly="" name="auth1" value= ""></td> 
                                    <td> <select class="form-control taxed" onchange="getChecked()"id= "abc14" name="taxed1"> <option>6</option><option>12</option> <option>18</option></select></td>
                                </tr>

                                <tr> 
                                    <td></td> 
                                    <td> <select class="form-control taxed" id= "abc20" name="desc2">
                                    <option>Select</option>
                                    
                                    <?php include("..\..\OurProj\Connectionfile.php")?>

                                    <?php

                                    $sql = "select name from products";

                                        $result = $conn->query($sql);

                                        if ($result->num_rows > 0) {
                                            $opt= mysqli_fetch_all($result, MYSQLI_ASSOC);
                                        }
                                        
                                        $conn->close();

                                    ?>
                                    <?php 
                                                    foreach ($opt as $option) {
                                                ?>
                                                    <option><?php echo $option['name']; ?> </option>
                                                        
                                                <?php 
                                                    }
                                                ?>
                                
                                    </select> </td> 
                                    <td><input type="text" id = "abc21" onchange="getChecked()" class="form-control qty" value="1" name="qty2"></td>
                                    <td><input type="text" id = "abc22" onchange="getChecked()" class="form-control item_price" name="amount2" value=""></td> 
                                    <td><input type="text" id = "abc23" class="form-control lvtota" name="auth2" readonly="" value= ""></td> 
                                    <td> <select class="form-control taxed" onchange="getChecked()"id= "abc24" name="taxed2"> <option>6</option><option>12</option> <option>18</option></select></td>
                                </tr>

                                <tr> 
                                    <td></td> 
                                    <td> <select class="form-control taxed" id= "abc30" name="desc3">
                                    <option>Select</option>
                                    
                                    <?php include("..\..\OurProj\Connectionfile.php")?>

                                    <?php

                                    $sql = "select name from products";

                                        $result = $conn->query($sql);

                                        if ($result->num_rows > 0) {
                                            $opt= mysqli_fetch_all($result, MYSQLI_ASSOC);
                                        }
                                        
                                        $conn->close();

                                    ?>
                                    <?php 
                                                    foreach ($opt as $option) {
                                                ?>
                                                    <option><?php echo $option['name']; ?> </option>
                                                        
                                                <?php 
                                                    }
                                                ?>
                                
                                    </select> </td> 
                                    <td><input type="text" id = "abc31" onchange="getChecked()" class="form-control qty" value="1" name="qty3"></td>
                                    <td><input type="text" id = "abc32" onchange="getChecked()" class="form-control item_price" name="amount3" value=""></td> 
                                    <td><input type="text" id = "abc33" class="form-control lvtota" name="auth3" readonly="" value= ""></td> 
                                    <td> <select class="form-control taxed" onchange="getChecked()"id= "abc34" name="taxed3"> <option>6</option><option>12</option> <option>18</option></select></td>
                                </tr>
                                    
                                    
                                </tbody>
                            </table>

                        </div>
                
                        <br>
                        <br>
                        <hr>
                        <textarea class="form-control" name="not" id="not" rows="3"
                                  placeholder="Invoice Terms..."></textarea>
                        <br>
                        <input type="hidden" id="is_recurring" value="no">
                        



                    </div>
                </div>



            </div>

            <div class="col-md-4">

                <div class="panel panel-default">
                    <div class="panel-body">

                        <div class="text-right">
                            <input type="hidden" id="_dec_point" name="_dec_point" value=".">
                        
                            <button class="btn btn-info" method= "post" name= "jay" id="save_n"> Save & Close </button>

                        </div>

                    </div>
                </div>

                <div class="panel panel-default">
                    <div class="panel-body">

                        <table class="table invoice-total">
                            <tbody>
                            <tr>
                                <td><strong>Sub Total (₹):</strong></td>
                                <td>
                                
                                <input  name="ppp" id="pqr" readonly=""value="">
                                </td>
                                
                            </tr>
                            <tr>
                                <td><strong>TAX (₹):</strong></td>
                                <td>
                                
                                <input id="pqr1"name="lll" readonly=""value="">
                                </td>
                            </tr>
                            <tr>
                                <td><strong>TOTAL (₹):</strong></td>
                                <td>
                               
                                <input id="pqr2" name="kkk" readonly=""value="">
                                </td>
                            </tr>
                            </tbody>
                        </table>

                    </div>
                </div>

                <div class="panel panel-default">
                    <div class="panel-body">

                        <div>



                            <div class="form-group">
                                
                                <label for="cid">Customer</label>
                                <?php include("..\..\OurProj\Connectionfile.php")?>

                                <?php

                                $sql = "select name,email from customer";

                                    $result = $conn->query($sql);

                                    if ($result->num_rows > 0) {
                                        $opt= mysqli_fetch_all($result, MYSQLI_ASSOC);
                                    }
                                    
                                    $conn->close();

                                ?>
                                
                                <select id="cid" name="cid" class="form-control">
                                    <option>Select</option>
                                <?php 
                                                    foreach ($opt as $option) {
                                                ?>
                                                    <option><?php echo $option['name']; echo "-"; echo $option['email'] ?> </option>
                                                        
                                                <?php 
                                                    }
                                                ?>

                                </select>
                                <span class="help"><a href="../Customer/addcust.php" id="contact_a"> | Or Add New Customer</a> </span>
                            </div>

                            <div class="form-group">
                                <label for="currency">Status</label>

                                <select id="currency" name="currency" class="form-control">

                                                                            <option
                                                selected="selected">Unpaid</option>
                                                <option
                                            >Paid</option>
                                        
                                </select>

                            </div>                            

                            
                            <div class="form-group">
                                <label for="idate">Invoice Date</label>

                                <input type="text" class="form-control" id="idate" name="idate" datepicker
                                       data-date-format="dd-mm-yyyy" startDate ="<?php echo date("d-m-Y")?>" data-auto-close="true"
                                       value=<?php echo date("d-m-Y")?> >
                            </div>
                            <div class="form-group">
                                
                            <label for="duedate">Payment Terms</label>

                                <select class="form-control" name="duedate" id="duedate">

                                    <option value="due_on_receipt" selected>Due On Receipt</option>
                                    <option value="days3">+3 days</option>
                                    <option value="days5">+5 days</option>
                                    <option value="days7">+7 days</option>
                                    <option value="days10">+10 days</option>
                                    <option value="days15">+15 days</option>
                                    <option value="days30">+30 days</option>
                                    <option value="days45">+45 days</option>
                                    <option value="days60">+60 days</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="tid">Sales TAX</label>

                                <select id="tid" name="tid" class="form-control">
                                    <option value="">None</option>
                                                                            <option>Sales Tax
                                            (1.50
                                            %)
                                        </option>
                                    
                                </select>
                            
                            </div>

                            

                        </div>

                    </div>
                </div>


            </div>
        </form>


    </div>

    
    <input type="hidden" id="_lan_set_discount" value="Set Discount">
    <input type="hidden" id="_lan_discount" value="Discount">
    <input type="hidden" id="_lan_discount_type" value="Discount Type">
    <input type="hidden" id="_lan_percentage" value="Percentage">
    <input type="hidden" id="_lan_fixed_amount" value="Fixed Amount">
    <input type="hidden" id="_lan_btn_save" value="Save">

    <input type="hidden" id="_lan_no_results_found" value="No results found">




                <div id="ajax-modal" class="modal container fade-scale" tabindex="-1" style="display: none;"></div>
            </div>
                        
        </div>

    </div>



        
</script>

<script src="weconnect.js"></script>



    <script type="text/javascript" src="redactor.min.js"></script>
        <script type="text/javascript" src="select2.min.js"></script>
        <script type="text/javascript" src="en.js"></script>
        <script type="text/javascript" src="datepicker.min.js"></script>
        <script type="text/javascript" src="en.js"></script>
        <script type="text/javascript" src="numeric.js"></script>
        <script type="text/javascript" src="modal.js"></script>
        <script type="text/javascript" src="invoice_add_v2.js"></script>
        
<script>        
function getChecked() {

  //1
  const quan = document.getElementById('abc1').value;
  const pri = document.getElementById('abc2').value;
  const aaa = quan*pri ;
  const checkBox = document.getElementById('abc3').value = aaa ;
  const taxper = document.getElementById('abc4').value;
  const aab = taxper*(quan*pri)/100 ;
  //2
  const quan2 = document.getElementById('abc11').value;
  const pri2 = document.getElementById('abc12').value;
  const aaa2 = quan2*pri2 ;
  const checkBox2 = document.getElementById('abc13').value = aaa2 ;
  const taxper2 = document.getElementById('abc14').value;
  const aab2 = taxper2*(quan2*pri2)/100 ;
  //3
  const quan3 = document.getElementById('abc21').value;
  const pri3 = document.getElementById('abc22').value;
  const aaa3 = quan3*pri3 ;
  const checkBox3 = document.getElementById('abc23').value = aaa3 ;
  const taxper3 = document.getElementById('abc24').value;
  const aab3 = taxper3*(quan3*pri3)/100 ;
  //4
  const quan4 = document.getElementById('abc31').value;
  const pri4 = document.getElementById('abc32').value;
  const aaa4 = quan4*pri4 ;
  const checkBox4 = document.getElementById('abc33').value = aaa4 ;
  const taxper4 = document.getElementById('abc34').value;
  const aab4 = taxper4*(quan4*pri4)/100 ;

  const check = document.getElementById('pqr').value = parseInt(aaa)+parseInt(aaa2)+parseInt(aaa3)+parseInt(aaa4) ;
  const checkB = document.getElementById('pqr1').value = parseFloat(aab)+parseFloat(aab2)+parseFloat(aab3)+parseFloat(aab4) ;
  const aac =  parseInt(check)+ parseFloat(checkB) ;
  const che = document.getElementById('pqr2').value = aac ;

};
</script>
</body>

</html>