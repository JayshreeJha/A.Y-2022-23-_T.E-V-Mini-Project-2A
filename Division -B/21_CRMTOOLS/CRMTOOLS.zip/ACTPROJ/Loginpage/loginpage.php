<?php include 'header.php';?>
<body>
  <?php
  include("../../OurProj/Connectionfile.php");
  $success = NULL;
  if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
            if (isset($_POST['login'])) 
            {   
               
                $email = $_POST['email'];
                $password =$_POST['password'];
                  if($email == "admin@admin" && $password == "123456")
                  { 
                    sleep(3);
                    header("Location:../Dashboard/dashboard.php");
                  }
                  else
                  {
                      $sql = "SELECT password FROM customer where email='$email'";
                      $result = $conn->query($sql);
                      $conn->close();
                      if ($result->num_rows > 0) 
                        {
                              $options= mysqli_fetch_all($result, MYSQLI_ASSOC);
                              foreach ($options as $option)
                              {
                                $a = $option['password'];
                              }
                          
                              if($a == $password)
                              {
                                sleep(3);
                                session_start();
                                $_SESSION['ema'] = "$email"; 
                                header("Location:../../Customerside/Dashboard/dashboard.php");
                              }
                              else{
                                ?><script>console.log("erro");</script><?php
                                echo $success = "Password Does Not Match";}
                        }
                        else{ 
                          ?><script>console.log("erro");</script><?php
                          echo $success = "No such Username Found"; 
                        }
                  
                      
                  }
                
                
              }
          }
            ?>
    
<!-- Section: Design Block -->
<section class="background-radial-gradient overflow-hidden">
  <style>
    section{
        height: 100vh;
    }
    .background-radial-gradient {
      background-color: hsl(218, 41%, 15%);
      background-image: radial-gradient(650px circle at 0% 0%,
          hsl(218, 41%, 35%) 15%,
          hsl(218, 41%, 30%) 35%,
          hsl(218, 41%, 20%) 75%,
          hsl(218, 41%, 19%) 80%,
          transparent 100%),
        radial-gradient(1250px circle at 100% 100%,
          hsl(218, 41%, 45%) 15%,
          hsl(218, 41%, 30%) 35%,
          hsl(218, 41%, 20%) 75%,
          hsl(218, 41%, 19%) 80%,
          transparent 100%);
    }

    #radius-shape-1 {
      height: 220px;
      width: 220px;
      top: -60px;
      left: -130px;
      background: radial-gradient(#44006b, #ad1fff);
      overflow: hidden;
    }

    #radius-shape-2 {
      border-radius: 38% 62% 63% 37% / 70% 33% 67% 30%;
      bottom: -60px;
      right: -110px;
      width: 300px;
      height: 300px;
      background: radial-gradient(#44006b, #ad1fff);
      overflow: hidden;
    }

    .bg-glass {
      background-color: hsla(0, 0%, 100%, 0.9) !important;
      backdrop-filter: saturate(200%) blur(25px);
    }
  </style>

  <div class="container px-4 py-5 px-md-5 text-center text-lg-start my-5">
    <div class="row gx-lg-5 align-items-center mb-5">
      <div class="col-lg-6 mb-5 mt-lg-5" style="z-index: 10">
        <h1 class="my-5 display-5 fw-bold ls-tight" style="color: hsl(218, 81%, 95%)">
          WeConnect<br />
          <span style="color: hsl(218, 81%, 75%)">for your business</span>
        </h1>

      </div>

      <div class="col-lg-6 mb-5 mt-lg-5 position-relative">
        <div id="radius-shape-1" class="position-absolute rounded-circle shadow-5-strong"></div>
        <div id="radius-shape-2" class="position-absolute shadow-5-strong"></div>

        <div class="card bg-glass">
          <div class="card-body px-4 py-5 px-md-5">
            <form action="" action="dashboard.php" method="post">
              <div class="form-outline mb-4">
                <input type="email" id="form3Example4" class="form-control" name="email" required/>
                <label class="form-label" for="form3Example4">email</label>
              </div>
              <!-- Password input -->
              <div class="form-outline mb-4">
                <input type="password" id="form3Example5" class="form-control" name="password" required/>
                <label class="form-label" for="form3Example5">Password</label>
              </div>
              <!-- Submit button -->
              <button type="submit" method= "post "class="btn btn-primary btn-block mb-4" name="login">
                login
              </button>
              <p class = "error-success"><?php echo $success; ?></p>
              
              
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- Section: Design Block -->
</body>
<?php include 'footer.php';?>