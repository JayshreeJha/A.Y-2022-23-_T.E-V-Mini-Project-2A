<!DOCTYPE html>

<?php 
session_start();
$loguser = $_SESSION["ema"];?>

<?php include("../../OurProj/Connectionfile.php");
    $sql = "SELECT * FROM customer where email='$loguser'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $options= mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
    $conn->close();
        ?>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>WeConnect</title>

    <link rel="apple-touch-icon" sizes="180x180" href="/icons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/icons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/icons/favicon-16x16.png">
    <link rel="manifest" href="/icons/site.webmanifest">
    <link rel="mask-icon" href="/icons/safari-pinned-tab.svg" color="#5bbad5">
    <link rel="shortcut icon" href="/icons/favicon.ico">
    <meta name="msapplication-TileColor" content="#2d89ef">
    <meta name="msapplication-config" content="/icons/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
    <link href="../weconnect.css" rel="stylesheet">
    <link href="../dark_extra.css" rel="stylesheet">
    <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
   
  <link rel="stylesheet" href="../plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  
        
</head>
<?php
        $success = NULL;
        if ($_SERVER["REQUEST_METHOD"] == "POST") 
        {
            if(isset($_POST['hrshtan'])){
                $subject = $_POST['subject'];
                $proposal = $_POST['proposal_text'];
                $item = $_POST['desc'];
                $item1 = $_POST['desc1'];
                $item2 = $_POST['desc2'];
                $item3 = $_POST['desc3'];
                $quantity = $_POST['qty'];
                $quantity1 = $_POST['qty1'];
                $quantity2 = $_POST['qty2'];
                $quantity3 = $_POST['qty3'];
                $custnot = $_POST['customer_notes'];
                $total = "xx";
                foreach ($options as $option) {$custname = $option['name'];}
                foreach ($options as $option) {$custemail = $option['email'];}
                

                include("../../OurProj/Connectionfile.php");
                $sql = "Insert into quotes (subject,customer,email,proposal,item,quantity,item1,quantity1,item2,quantity2,item3,quantity3,total,custnot) 
                VALUES('$subject','$custname','$custemail','$proposal','$item','$quantity','$item1','$quantity1','$item2','$quantity2','$item3','$quantity3','$total','$custnot')";
                $result = $conn->query($sql);
                $conn->close();
                ?>
                <!DOCTYPE html>
                <html>
                    <meta http-equiv = "refresh" content = "0; url =../Sales/quotesreq.php"/>
                </html>
            <?php
            }
        }
        ?>  

<body class="fixed-nav ">
<section>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">

                <ul class="nav" id="side-menu">

    <li class="nav-header">
        <div class="dropdown profile-element"> <span>

                        <img src="../default-user-avatar.png"  class="img-circle" style="max-width: 64px;" alt="">
                                                             </span>
            <a data-toggle="dropdown" class="dropdown-toggle" href="#" aria-expanded="false">
                            <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold"><?php foreach ($options as $option) { ?> <strong><?php echo $option['name'];?></strong> <?php }  ?></strong>
                             </span> <span class="text-muted text-xs block">My Account <b class="caret"></b></span> </span> </a>
            <ul class="dropdown-menu animated fadeIn m-t-xs">
                <li><a href="../../ACTPROJ/DropdownAdmin/editprofile.php">Edit Profile</a></li>
                <li><a href="../../ACTPROJ/DropdownAdmin/changepass.php">Change Password</a></li>
                <li class="divider"></li>
                <li><a href="../../ACTPROJ/Loginpage/loginpage.php">Logout</a></li>
            </ul>
        </div>
    </li>

    

            <li class="active"><a href="../Dashboard/dashboard.php"></i> <span class="nav-label">Dashboard</span></a></li>
    
            <li class="">
                <a href="#"><span class="nav-label">Sales &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼ </span></span></a>
                <ul class="nav nav-second-level">
                <li><a href="../Sales/invoices.php">Invoices</a></li>
                        <li><a href="../Sales/recurinvo.php">Recurring Invoices</a></li>
                        <li><a href="../Sales/quotes.php">Quotes</a></li>
                        <li><a href="../Sales/quotesreq.php">Requested Quotes</a></li>
                        <li><a href="../Sales/newquotes.php">Request New Quote</a></li>

                </ul>
            </li>



            <li class="">
                <a href="#"></i> <span class="nav-label">Orders &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ▼</span></span></a>
                <ul class="nav nav-second-level">
                    <li><a href="../Order/listorder.php">List All Orders</a></li>
                    <li><a href="../Order/addorder.php">Add New Order</a></li>

                </ul>
            </li>
    
        
                <li class="" id="li_settings">
            <a href="../DropdownAdmin/editprofile.php"> <span class="nav-label">Profile</span></span></a>
            </li>
    



</ul>

            </div>
        </nav>
        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-fixed-top white-bg" role="navigation" style="margin-bottom: 0">

                    <img class="logo" style="max-height: 40px; width: auto;" src="../../ACTPROJ/abc.png" alt="Logo">

                  
                    
                    <ul class="nav navbar-top-links navbar-right pull-right">


                        <li class="dropdown navbar-user">

                            <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
                                <img src="../default-user-avatar.png" alt="">
                                <span class="hidden-xs"><?php foreach ($options as $option) { ?> <strong><?php echo $option['name'];?></strong> <?php }  ?></span> <b class="caret"></b>
                            </a>
                            <ul class="dropdown-menu animated fadeIn">
                                <li class="arrow"></li>

                                <li><a href="../../ACTPROJ/DropdownAdmin/editprofile.php">Edit Profile</a></li>
                                <li><a href="../../ACTPROJ/DropdownAdmin/changepass.php">Change Password</a></li>
                                <li class="divider"></li>
                                <li><a href="../../ACTPROJ/Loginpage/loginpage.php">Logout</a></li>

                            </ul>
                        </li>


                    </ul>

                </nav>
            </div>

            <div class="row wrapper white-bg page-heading">
                <div class="col-lg-12">
                    <h2 style="color: #2F4050; font-size: 16px; font-weight: 400; margin-top: 18px"> Add Invoice </h2>

                </div>

            </div>

            <div class="wrapper wrapper-content animated fadeIn">
                
                

    <div class="row">
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>
                        Request New Quote 
                    </h5>

                </div>
                <div class="ibox-content" id="ibox_form">
                    <form id="invform" method="post">
                        <div class="ibox-content">
                            <div class="row">
                                <div class="alert alert-danger" id="emsg">
                                    <span id="emsgbody"></span>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="subject">Subject</label>
                                        <input type="text" class="form-control" name="subject" id="subject">
                                    </div>
                                    <hr>
                                </div>
                            </div>

                        

                            <div class="row">
                                <div class="col-md-12">
                                    <hr>
                                    <div class="form-group">
                                        <label for="proposal_text">Proposal Text</label>
                                        <textarea class="form-control" id="proposal_text" name="proposal_text" rows="6"></textarea>
                                        <span class="help-block">Displayed at the Top of the Quote</span>
                                    </div>
                                    <hr>
                                </div>
                            </div>



                            <div class="table-responsive m-t">
                                <table class="table invoice-table" id="invoice_items">
                                    <thead>
                                    <tr>
                                        <th width="60%">Item Name</th>
                                        <th width="10%">Qty</th>
                                        

                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr> 
                                   
                                    <td> <select class="form-control taxed" id= "abc" name="desc">
                                    <option>Select</option>
                                    
                                    <?php include("..\..\OurProj\Connectionfile.php")?>

                                    <?php

                                    $sql = "select name from products";

                                        $result = $conn->query($sql);

                                        if ($result->num_rows > 0) {
                                            $opt= mysqli_fetch_all($result, MYSQLI_ASSOC);
                                        }
                                        
                                        $conn->close();

                                    ?>
                                    <?php 
                                                    foreach ($opt as $option) {
                                                ?>
                                                    <option><?php echo $option['name']; ?> </option>
                                                        
                                                <?php 
                                                    }
                                                ?>

                                    </select> </td> 
                                    <td><input type="text" id = "abc1" onchange="getChecked()" class="form-control qty" value="1" name="qty"></td>
                                
                                </tr>
                            
                                    <tr> 
                                    
                                    <td> <select class="form-control taxed" id= "abc10" name="desc1">
                                    <option>Select</option>
                                    
                                    <?php include("..\..\OurProj\Connectionfile.php")?>

                                    <?php

                                    $sql = "select name from products";

                                        $result = $conn->query($sql);

                                        if ($result->num_rows > 0) {
                                            $opt= mysqli_fetch_all($result, MYSQLI_ASSOC);
                                        }
                                        
                                        $conn->close();

                                    ?>
                                    <?php 
                                                    foreach ($opt as $option) {
                                                ?>
                                                    <option><?php echo $option['name']; ?> </option>
                                                        
                                                <?php 
                                                    }
                                                ?>
                                
                                    </select> </td> 
                                    <td><input type="text" id = "abc11" onchange="getChecked()" class="form-control qty" value="1" name="qty1"></td>
                                    
                                   
                                </tr>

                                <tr> 
                                    <td> <select class="form-control taxed" id= "abc20" name="desc2">
                                    <option>Select</option>
                                    
                                    <?php include("..\..\OurProj\Connectionfile.php")?>

                                    <?php

                                    $sql = "select name from products";

                                        $result = $conn->query($sql);

                                        if ($result->num_rows > 0) {
                                            $opt= mysqli_fetch_all($result, MYSQLI_ASSOC);
                                        }
                                        
                                        $conn->close();

                                    ?>
                                    <?php 
                                                    foreach ($opt as $option) {
                                                ?>
                                                    <option><?php echo $option['name']; ?> </option>
                                                        
                                                <?php 
                                                    }
                                                ?>
                                
                                    </select> </td> 
                                    <td><input type="text" id = "abc21" onchange="getChecked()" class="form-control qty" value="1" name="qty2"></td>
                                    
                                   
                                </tr>

                                <tr> 
                                    
                                    <td> <select class="form-control taxed" id= "abc30" name="desc3">
                                    <option>Select</option>
                                    
                                    <?php include("..\..\OurProj\Connectionfile.php")?>

                                    <?php

                                    $sql = "select name from products";

                                        $result = $conn->query($sql);

                                        if ($result->num_rows > 0) {
                                            $opt= mysqli_fetch_all($result, MYSQLI_ASSOC);
                                        }
                                        
                                        $conn->close();

                                    ?>
                                    <?php 
                                                    foreach ($opt as $option) {
                                                ?>
                                                    <option><?php echo $option['name']; ?> </option>
                                                        
                                                <?php 
                                                    }
                                                ?>
                                
                                    </select> </td> 
                                    <td><input type="text" id = "abc31" onchange="getChecked()" class="form-control qty" value="1" name="qty3"></td>
                                    
                                    
                                </tr>

                                    </tbody>
                                </table>

                                <hr>

                            </div>
                            <!-- /table-responsive -->
                            
                            
                            <hr>

                            <div class="form-group">
                                <label for="customer_notes">Customer Notes</label>
                                <textarea class="form-control" id="customer_notes" name="customer_notes" rows="6"></textarea>
                                <span class="help-block">Displayed as a Footer to the Quote</span>
                            </div>

                            <div class="text-right">
                                <input type="hidden" id="_dec_point" name="_dec_point" value=".">
                                <input type="hidden" id="taxed_type" name="taxed_type" value="individual">
                                <button class="btn btn-primary" name="hrshtan" id="subm" method ="post"> Save</button>
                            </div>


                        </div>
                    </form>


                </div>
            </div>
        </div>

    </div>

   




                <div id="ajax-modal" class="modal container fade-scale" tabindex="-1" style="display: none;"></div>
            </div>

                            
                            
        </div>

    </div>

<script src="weconnect.js"></script>



    <script  src="redactor.min.js"></script>
        <script  src="select2.min.js"></script>
        <script  src="en.js"></script>
        <script  src="datepicker.min.js"></script>
        <script  src="en (2).js"></script>
        <script  src="numeric.js"></script>
        <script  src="modal.js"></script>
        <script  src="quotes.js"></script>
        
<script>        
function getChecked() {

  //1
  const quan = document.getElementById('abc1').value;
  const pri = document.getElementById('abc2').value;
  const aaa = quan*pri ;
  const checkBox = document.getElementById('abc3').value = aaa ;
  const taxper = document.getElementById('abc4').value;
  const aab = taxper*(quan*pri)/100 ;
  //2
  const quan2 = document.getElementById('abc11').value;
  const pri2 = document.getElementById('abc12').value;
  const aaa2 = quan2*pri2 ;
  const checkBox2 = document.getElementById('abc13').value = aaa2 ;
  const taxper2 = document.getElementById('abc14').value;
  const aab2 = taxper2*(quan2*pri2)/100 ;
  //3
  const quan3 = document.getElementById('abc21').value;
  const pri3 = document.getElementById('abc22').value;
  const aaa3 = quan3*pri3 ;
  const checkBox3 = document.getElementById('abc23').value = aaa3 ;
  const taxper3 = document.getElementById('abc24').value;
  const aab3 = taxper3*(quan3*pri3)/100 ;
  //4
  const quan4 = document.getElementById('abc31').value;
  const pri4 = document.getElementById('abc32').value;
  const aaa4 = quan4*pri4 ;
  const checkBox4 = document.getElementById('abc33').value = aaa4 ;
  const taxper4 = document.getElementById('abc34').value;
  const aab4 = taxper4*(quan4*pri4)/100 ;

  const check = document.getElementById('pqr').value = parseInt(aaa)+parseInt(aaa2)+parseInt(aaa3)+parseInt(aaa4) ;
  const checkB = document.getElementById('pqr1').value = parseFloat(aab)+parseFloat(aab2)+parseFloat(aab3)+parseFloat(aab4) ;
  const aac =  parseInt(check)+ parseFloat(checkB) ;
  const che = document.getElementById('pqr2').value = aac ;

};
</script>



</body>

</html>