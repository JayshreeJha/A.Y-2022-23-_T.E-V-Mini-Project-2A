<?php
	$con = mysqli_connect('localhost', 'root', '','database');

	$uname = $_POST['uname'];
	$email = $_POST['email'];
	$pass = $_POST['pass'];
	
	
	// Database connection
	//$conn = new mysqli('localhost','root','','database');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into user(username, email, password,) values(?, ?, ?,)");
		$stmt->bind_param("sss", $uname, $email, $pass,);
		$execval = $stmt->execute();
		echo $execval;
		echo "Registration successfully...";
		$stmt->close();
		$conn->close();
	}
?>