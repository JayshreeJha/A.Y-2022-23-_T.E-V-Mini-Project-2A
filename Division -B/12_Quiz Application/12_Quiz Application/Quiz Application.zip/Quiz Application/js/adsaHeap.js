let MCQS = [{
    question: "1. What is the time complexity of Build Heap operation. Build Heap is used to build a max(or min) binary heap from a given array. Build Heap is used in Heap Sort as a first step for sorting.",
    choice1: "a) O(nLogn)",
    choice2: "b) O(n^2)",
    choice3: "c) O(Logn)",
    choice4: "d) O(n)",
    answer: 4
},
{
    question: "Consider a binary max-heap implemented using an array. Which one of the following array represents a binary max-heap? ",
    choice1: "a) 25,12,16,13,10,8,14",
    choice2: "b) 25,12,16,13,10,8,14",
    choice3: "c) 25,14,16,13,10,8,12",
    choice4: "d) 25,14,12,13,10,8,16",
    answer: 3
},
{
    question: "What is the content of the array after two delete operations on the correct answer to the previous question?",
    choice1: "a) 14,13,12,10,8",
    choice2: "b) 14,12,13,8,10",
    choice3: "c) 14,13,8,12,10",
    choice4: "d) 14,13,12,8,10",
    answer: 4
},
{
    question: "In a binary max heap containing n numbers, the smallest element can be found in time ",
    choice1: "a) 0(n)",
    choice2: "b) O(logn)",
    choice3: "c) 0(loglogn)",
    choice4: "d) 0(1)",
    answer: 1
},
{
    question: "In a max-heap, element with the greatest key is always in the which node?",
    choice1: "a) Leaf node",
    choice2: "b) First node of left sub tree",
    choice3: "c) root node",
    choice4: "d) First node of right sub tree",
    answer: 3
},
{
    question: "What is the complexity of adding an element to the heap.",
    choice1: "a) O(log n)",
    choice2: "b) O(h)",
    choice3: "c) O(log n) & O(h)",
    choice4: " O(n)",
    answer: 3
},
{
    question: "5. Heap can be used as ________________",
    choice1: "a) Priority queue",
    choice2: "b)  Stack",
    choice3: "c) A decreasing order array",
    choice4: "d) Normal Array",
    answer: 1
},
{
    question: "An array consists of n elements. We want to create a heap using the elements. The time complexity of building a heap will be in order of",
    choice1: "a) O(n*n*logn)",
    choice2: "b) O(n*logn)",
    choice3: "c) O(n*n)",
    choice4: "d)  O(n *logn *logn)",
    answer: 2
},
{
    question: "1. What is the space complexity of searching in a heap?",
    choice1: "a) O(logn)",
    choice2: "b) O(n)",
    choice3: "c) O(1)",
    choice4: "d) O(nlogn)",
    answer: 2
},
{
    question: "What is the best case complexity in building a heap?",
    choice1: "a) O(nlogn)",
    choice2: "b) O(n2)",
    choice3: "c) O(n*longn *logn)",
    choice4: "d) O(n)",
    answer: 4
}];