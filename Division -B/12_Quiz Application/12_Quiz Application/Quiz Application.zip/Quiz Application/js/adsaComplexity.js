let MCQS = [{
    question: "3. The complexity of Binary search algorithm is _________",
    choice1: "O(n)",
    choice2: "O(log)",
    choice3: "O(n2)",
    choice4: "O(n log n)",
    answer: 2
},
{
    question: "The complexity of merge sort algorithm is _________",
    choice1: "a) O(n)",
    choice2: "b) O(log n)",
    choice3: "c) O(n2)",
    choice4: "d) O(n log n)",
    answer: 4
},
{
    question: "Which of the following case does not exist in complexity theory?",
    choice1: "a) Best case",
    choice2: "b) Worst case",
    choice3: "c) Average case",
    choice4: "d) Null case",
    answer: 4
},
{
    question: "The complexity of linear search algorithm is _________",
    choice1: "a) O(n)",
    choice2: "b) O(log n)",
    choice3: "c) O(n2)",
    choice4: "d) O(n log n)",
    answer: 4
},
{
    question: "The complexity of Bubble sort algorithm is _________",
    choice1: "a) O(n)",
    choice2: "b) O(log n)",
    choice3: "c) O(n2)",
    choice4: "d) O(n log n)",
    answer: 3
},
{
    question: "The Worst case occur in linear search algorithm when ________",
    choice1: "a) Item is somewhere in the middle of the array",
    choice2: "b) Item is not in the array at all",
    choice3: "c) Item is the last element in the array",
    choice4: "d) Item is the last element in the array or is not there at all",
    answer: 4
},
{
    question: "The worst case complexity for insertion sort is _________",
    choice1: "a) O(n)",
    choice2: "b) O(log n)",
    choice3: "c) O(n2)",
    choice4: "d) O(n log n)",
    answer: 3
},
{
    question: "The complexity of Fibonacci series is _________",
    choice1: "a) O(2n)",
    choice2: "b) O(log n)",
    choice3: "c) O(n2)",
    choice4: "d) O(n log n)",
    answer: 1
},
{
    question: "The worst case occurs in quick sort when _________",
    choice1: "a) Pivot is the median of the array",
    choice2: "b) Pivot is the smallest element",
    choice3: "c) Pivot is the middle element",
    choice4: "d) None of the mentioned",
    answer: 2
},
{
    question: "The worst case complexity of quick sort is _________",
    choice1: "a) O(n)",
    choice2: "b) O(log n)",
    choice3: "c) O(n2)",
    choice4: "d) O(n log n)",
    answer: 3
}];
