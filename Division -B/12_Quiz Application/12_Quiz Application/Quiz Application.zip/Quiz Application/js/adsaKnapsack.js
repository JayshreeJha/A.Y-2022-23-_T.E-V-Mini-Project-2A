let MCQS = [{
    question: "1. The Knapsack problem is an example of ____________",
    options: "a) Greedy algorithm",
    options: "b) 2D dynamic programming",
    options: "c) 1D dynamic programming",
    options: "d) Divide and conquer",
    answer: 2
    },
    {
    question: "2. Which of the following methods can be used to solve the Knapsack problem?",
    options: "a) Brute force algorithm",
    options: "b) Recursion",
    options: "c) Dynamic programming",
    options: "d) Brute force, Recursion and Dynamic Programming",
    answer: 4
    },
    {
    question: "3. You are given a knapsack that can carry a maximum weight of 60. There are 4 items with weights {20, 30, 40, 70} and values {70, 80, 90, 200}. What is the maximum value of the items you can carry using the knapsack?",
    options: "a) 160",
    options: "b) 200",
    options: "c) 170",
    options: "d) 90",
    answer: 1
    },
    {
    question: "5. What is the time complexity of the brute force algorithm used to solve the Knapsack problem?",
    options: "a) O(n)",
    options: "b) O(n!)",
    options: "c) O(2n)",
    options: "d) d) O(n3)",
    answer: 3
    },
    {
    question: "5) Fractional knapsack problem is also known as _____",
    options: "a) 0/1 knapsack problem",
    options: "b) Continuous knapsack problem",
    options: "c) Divisible knapsack problem",
    options: "d) Non continuous knapsack problem",
    answer: 2
    },
    {
    question: "6) Fractional knapsack problem is solved most efficiently by which of the following algorithm?",
    options: "a) Divide and conquer",
    options: "b) Dynamic programming",
    options: "c) Greedy algorithm",
    options: "d) Backtracking",
    answer: 3
    },
    {
    question: "7) What is the objective of the knapsack problem?",
    options: "a) To get maximum total value in the knapsack",
    options: "b) To get minimum total value in the knapsack",
    options: "c) To get maximum weight in the knapsack",
    options: "d) To get minimum weight in the knapsack",
    answer: 1
    },
    {
    question: "8) Given items as {value, weight} pairs {{40, 20}, {30, 10}, {20, 5}}. The capacity of knapsack=20. Find the maximum value output assuming items to be divisible.",
    options: "a) 60",
    options: "b) 80",
    options: "c) 100",
    options: "d) 40",
    answer: 1
    },
    {
    question: "9) The main time taking step in fractional knapsack problem is ____",
    options: "a) Breaking items into fraction",
    options: "b) Adding items into knapsack",
    options: "c) Sorting",
    options: "d) Looping through sorted items",
    answer: 3
    },
    {
    question: "10) Given items as {value, weight} pairs {{60, 20}, {50, 25}, {20, 5}}. The capacity of knapsack=40. Find the maximum value output assuming items to be divisible and nondivisible respectively.",
    options: "a) 100, 80",
    options: "b) 110, 70",
    options: "c) 130, 110",
    options: "d) 110, 80",
    answer: 4
    }];