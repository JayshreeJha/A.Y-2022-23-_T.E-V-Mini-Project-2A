let MCQS = [{
    question: "1) The ____________ model is 7-layer architecture where each layer is having some specific functionality to perform.",
    options: "a) TCP/IP",
    options: "b) Cloud",
    options: "c) OSI",
    options: "d) OIS",
    answer: 3
    },
    {
    question: "2) The full form of OSI is OSI model is ______________",
    options: "a) Open Systems Interconnection",
    options: "b) Open Software Interconnection",
    options: "c) Open Systems Internet",
    options: "d) Open Software Internet",
    answer: 1
    },
    {
    question: "3) Which of the following is not physical layer vulnerability?",
    options: "a) Physical theft of data & hardware",
    options: "b) Physical damage or destruction of data & hardware",
    options: "c) Unauthorized network access",
    options: "d) Keystroke & Other Input Logging",
    answer: 3
    },
    {
    question: "4) In __________________ layer, vulnerabilities are directly associated with physical access to networks and hardware.",
    options: "a) physical",
    options: "b) data-link",
    options: "c) network",
    options: "d) application",
    answer: 1
    },
    {
    question: "5) Which of the following is not a vulnerability of the data-link layer?",
    options: "a) MAC Address Spoofing",
    options: "b) VLAN circumvention",
    options: "c) c) Switches may be forced for flooding traffic to all VLAN ports",
    options: "d) Overloading of transport-layer mechanisms",
    answer: 4
    },
    {
    question: "6) Which of the following is not a vulnerability of the network layer?",
    options: "a) Route spoofing",
    options: "b) Identity & Resource ID Vulnerability",
    options: "c) IP Address Spoofing",
    options: "d) Weak or non-existent authentication",
    answer: 4
    },
    {
    question: "7) Which of the following is an example of physical layer vulnerability?",
    options: "a) MAC Address Spoofing",
    options: "b) Physical Theft of Data",
    options: "c) Route spoofing",
    options: "d) Weak or non-existent authentication",
    answer: 3
    },
    {
    question: "8) Which of the following is an example of data-link layer vulnerability?",
    options: "a) MAC Address Spoofing",
    options: "b) Physical Theft of Data",
    options: "c) Route spoofing",
    options: "d) Weak or non-existent authentication",
    answer: 2
    },
    {
    question: "9) Which of the following is an example of network layer vulnerability?",
    options: "a) MAC Address Spoofing",
    options: "b) Physical Theft of Data",
    options: "c) Route spoofing",
    options: "d) Weak or non-existent authentication",
    answer: 3
    },
    {
    question: "10) Which of the following is an example of data-link layer vulnerability?",
    options: "a) Physical Theft of Data",
    options: "b) VLAN circumvention",
    options: "c) Route spoofing",
    options: "d) Weak or non-existent authentication",
    answer: 2
    }];