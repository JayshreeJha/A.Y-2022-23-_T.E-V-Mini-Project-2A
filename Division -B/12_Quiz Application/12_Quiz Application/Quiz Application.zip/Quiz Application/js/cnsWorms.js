let MCQS = [{
    question: "1) There are _________ types of computer virus.",
    options: "a) 5",
    options: "b) 7",
    options: "c) 10",
    options: "d) 12",
    answer: 3
    },
    {
    question: "2) Which of the following is not a type of virus?",
    options: "a) Boot sector",
    options: "b) Polymorphic",
    options: "c) Multipartite",
    options: "d) Trojans",
    answer: 4
    },
    {
    question: "3)  A computer ________ is a malicious code which self-replicates by copying itself to other programs.",
    options: "a) program",
    options: "b) virus",
    options: "c) application",
    options: "d) worm",
    answer: 2
    },
    {
    question: "4) Which of them is not an ideal way of spreading the virus?",
    options: "a) Infected website",
    options: "b) Emails",
    options: "c) Official Antivirus CDs",
    options: "d) USBs",
    answer: 3
    },
    {
    question: "5) In which year Apple II virus came into existence?",
    options: "a) 1979",
    options: "b) 1980",
    options: "c) 1981",
    options: "d) 1982",
    answer: 3
    },
    {
    question: "6) The virus hides itself from getting detected by ______ different ways.",
    options: "a) 2",
    options: "b) 3",
    options: "c) 4",
    options: "d) 5",
    answer: 2
    },
    {
    question: "7) The viral envelope is made up of _______",
    options: "a) Proteins",
    options: "b) Glycoproteins",
    options: "c) Lipids and Proteins",
    options: "d) All of the above",
    answer: 4
    },
    {
    question: "8) Which of the following is a helical virus?",
    options: "a) TMV",
    options: "b) T4 phage",
    options: "c) Poxvirus",
    options: "d) Herpes virus",
    answer: 1
    },
    {
    question: "9) Which of the following statements are true about the viruses?",
    options: "a) Free-living",
    options: "b) Obligate parasites",
    options: "c) Both (a) and (b)",
    options: "d) None of the above",
    answer: 2
    },
    {
    question: "10) Direct Action Virus is also known as ___________ ",
    options: "a) Non-resident virus",
    options: "b) Boot Sector Virus",
    options: "c) Polymorphic Virus",
    options: "d) Multipartite Virus",
    answer: 1
    }];