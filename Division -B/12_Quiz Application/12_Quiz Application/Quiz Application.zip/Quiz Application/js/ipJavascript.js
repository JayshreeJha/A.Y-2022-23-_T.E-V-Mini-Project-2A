let MCQS = [{
    question: "What is JavaScript?",
    choice1: "a) JavaScript is a scripting language used to make the website interactive",
    choice2: "b) JavaScript is an assembly language used to make the website interactive",
    choice3: "c) JavaScript is a compiled language used to make the website interactive",
    choice4: "d) None of the above",
    answer: 1
    },
    {
    question: "Which of the following is correct about JavaScript",
    choice1: "a) JavaScript is an Object-Based language",
    choice2: "b) JavaScript is Assembly-language",
    choice3: "c) JavaScript is an Object-Oriented language",
    choice4: "d) JavaScript is a High-level language",
    answer: 1
    },
    {
    question: "Among the given statements, which statement defines closures in JavaScript?",
    choice1: "a) JavaScript is a function that is enclosed with references to its inner function scope",
    choice2: "b) JavaScript is a function that is enclosed with references to its lexical environment",
    choice3: "c) JavaScript is a function that is enclosed with the object to its inner function scope",
    choice4: "d) None of the mentioned",
    answer: 2
    },
    {
    question: "Arrays in JavaScript are defined by which of the following statements?",
    choice1: "a) It is an ordered list of values",
    choice2: "b) It is an ordered list of objects",
    choice3: "c) It is an ordered list of string",
    choice4: "d) It is an ordered list of functions",
    answer: 1
    },
    {
    question: "Which of the following is not javascript data types?",
    choice1: "a) Null type",
    choice2: "b) Undefined type",
    choice3: "c) Number type",
    choice4: "d) All of the mentioned",
    answer: 4
    },
    {
    question: "Where is Client-side JavaScript code is embedded within HTML documents?",
    choice1: "a) A URL that uses the special javascript:code",
    choice2: "b) A URL that uses the special javascript:protocol",
    choice3: "c) A URL that uses the special javascript:encoding",
    choice4: "d) A URL that uses the special javascript:stack",
    answer: 2
    },
    {
    question: "Which of the following object is the main entry point to all client-side JavaScript features and APIs?",
    choice1: "a) Position",
    choice2: "b) Window",
    choice3: "c) Standard",
    choice4: "d) Location",
    answer: 2
    },
    {
    question: "Which of the following can be used to call a JavaScript Code Snippet?",
    choice1: "a) Function/Method",
    choice2: "b) Preprocessor",
    choice3: "c) Triggering Event",
    choice4: "d) RMI",
    answer: 1
    },
    {
    question: "Which of the following explains correctly what happens when a JavaScript program is developed on a Unix Machine?",
    choice1: "a) will work perfectly well on a Windows Machine",
    choice2: "b) will be displayed as JavaScript text on the browser",
    choice3: "c) will throw errors and exceptions",
    choice4: "d) must be restricted to a Unix Machine only",
    answer: 1
    },
    {
    question: "Which of the following scoping type does JavaScript use?",
    choice1: "a) Sequential",
    choice2: "b) Segmental",
    choice3: "c) Lexical",
    choice4: "d) Literal",
    answer: 3
    }];