let MCQS = [{
    question: "1) What is the meaning of cipher in cryptography?",
    options: "a) an algorithm that performs encryption",
    options: "b) an algorithm that generates a secret code",
    options: "c) an algorithm that performs encryption or decryption",
    options: "d) a secret code",
    answer: 3
    },
    {
    question: "2) Vigenere cipher is an example of _____________",
    options: "a) mono-alphabetic cipher",
    options: "b) poly-alphabetic cipher",
    options: "c) transposition cipher",
    options: "d) additive cipher",
    answer: 2
    },
    {
    question: "3) Encryption in Vigenere cipher is done using ________",
    options: "a) vigenere formula",
    options: "b) vigenere cycle",
    options: "c) vigenere square",
    options: "d) vigenere addition",
    answer: 3
    },
    {
    question: "4) Which of the following correctly defines poly alphabetic cipher?",
    options: "a) a substitution based cipher which uses multiple substitution at different positions",
    options: "b) a substitution based cipher which uses fixed substitution over entire message",
    options: "c) a transposition based cipher which uses multiple substitution at different positions",
    options: "d) a transposition based cipher which uses fixed substitution over entire message",
    answer: 1
    },
    {
    question: "5) Which of the following is not a type of poly alphabetic cipher?",
    options: "a) Rotor cipher",
    options: "b) Hill cipher",
    options: "c) One time pad cipher",
    options: "d) Multiplicative cipher",
    answer: 4
    },
    {
    question: "6) Vigenere table consists of _________",
    options: "a) 26 rows and 26 columns",
    options: "b) 26 rows and 1 column",
    options: "c) 1 row and 26 columns",
    options: "d) 27 rows and 27 columns",
    answer: 1
    },
    {
    question: "7) What will be the plain text corresponding to cipher text “PROTO” if vigenere cipher is used with keyword as “HELLO”?",
    options: "a) SANFOUNDRY",
    options: "b) WORLD",
    options: "c) INDIA",
    options: "d) AMERICA",
    answer: 3
    },
    {
    question: "8) In which of the following cipher the plain text and the ciphered text does not have a same number of letters?",
    options: "a) affine cipher",
    options: "b) vigenere cipher",
    options: "c) columnar cipher",
    options: "d) additive cipher",
    answer: 2
    },
    {
    question: "9) What will be the ciphered text if the string “SANFOUNDRY” is given as input to the code of vigenere cipher with keyword as “HELLO”?",
    options: "a) UEWIIDKLL",
    options: "b) ZEYQCOCM",
    options: "c) ZEYQCBROCM",
    options: "d) ZEYQCBROCMJDH",
    answer: 3
    },
    {
    question: "10) Vigenere cipher is an example of _____",
    options: "a) mono-alphabetic cipher",
    options: "b) poly-alphabetic cipher",
    options: "c) transposition cipher",
    options: "d) additive cipher",
    answer: 2
    }];