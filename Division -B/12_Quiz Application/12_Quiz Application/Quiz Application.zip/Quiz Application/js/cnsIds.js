let MCQS = [{
    question: "1) What are the different ways to intrude?",
    options: "a) Buffer overflows",
    options: "b) Unexpected combinations and unhandled input",
    options: "c) Race conditions",
    options: "d) All of the mentioned",
    answer: 4
    },
    {
    question: "2) What are the major components of the intrusion detection system?",
    options: "a) Analysis Engine",
    options: "b) Event provider",
    options: "c) Alert Database",
    options: "d) All of the mentioned",
    answer: 4
    },
    {
    question: "3) What are the different ways to classify an IDS?",
    options: "a) anomaly detection",
    options: "b) signature based misuse",
    options: "c) stack based",
    options: "d) all of the mentioned",
    answer: 4
    },
    {
    question: "4) What are the different ways to classify an IDS?",
    options: "a) Zone based",
    options: "b) Host & Network based",
    options: "c) Network & Zone based",
    options: "d) Level based",
    answer: 2
    },
    {
    question: "5) What are the characteristics of anomaly based IDS?",
    options: "a) It models the normal usage of network as a noise characterization",
    options: "b) It doesn’t detect novel attacks",
    options: "c) Anything distinct from the noise is not assumed to be intrusion activity",
    options: "d) It detects based on signature",
    answer: 1
    },
    {
    question: "6) What is the major drawback of anomaly detection IDS?",
    options: "a) These are very slow at detection",
    options: "b) It generates many false alarms",
    options: "c) It doesn’t detect novel attacks",
    options: "d) None of the mentioned",
    answer: 2
    },
    {
    question: "7) What are the characteristics of signature based IDS?",
    options: "a) Most are based on simple pattern matching algorithms",
    options: "b) It is programmed to interpret a certain series of packets",
    options: "c) It models the normal usage of network as a noise characterization",
    options: "d) Anything distinct from the noise is assumed to be intrusion activity",
    answer: 1
    },
    {
    question: "8) What are the drawbacks of signature based IDS?",
    options: "a) They are unable to detect novel attacks",
    options: "b) They suffer from false alarms",
    options: "c) They have to be programmed again for every new pattern to be detected",
    options: "d) All of the mentioned",
    answer: 4
    },
    {
    question: "9) What are the characteristics of Host based IDS?",
    options: "a) The host operating system logs in the audit information",
    options: "b) Logs includes logins,file opens and program executions",
    options: "c) Logs are analysed to detect tails of intrusion",
    options: "d) All of the mentioned",
    answer: 4
    },
    {
    question: "10) What are the strengths of the host based IDS?",
    options: "a) Attack verification",
    options: "b) System specific activity",
    options: "c) No additional hardware required",
    options: "d) All of the mentioned",
    answer: 4
    }];