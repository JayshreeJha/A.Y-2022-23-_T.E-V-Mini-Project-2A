let MCQS = [{
    question: "1. Merge sort uses which of the following technique to implement sorting?",
    options: "a) backtracking",
    options: "b) greedy algorithm",
    options: "c) divide and conquer",
    options: "d) dynamic programming",
    answer: 3
    },
    {
    question: "2. What is the auxiliary space complexity of merge sort?",
    options: "a) O(1)",
    options: "b) O(log n)",
    options: "c) O(n)",
    options: "d) O(n log n)",
    answer: 3
    },
    {
    question: "3. Which of the following is not a variant of merge sort?",
    options: "a) in-place merge sort",
    options: "b) bottom up merge sort",
    options: "c) top down merge sort",
    options: "d) linear merge sort",
    answer: 4
    },
    {
    question: "4. Choose the incorrect statement about merge sort from the following?",
    options: "a) it is a comparison based sort",
    options: "b) it is an adaptive algorithm",
    options: "c) it is not an in place algorithm",
    options: "d) it is stable algorithm",
    answer: 2
    },
    {
    question: "5) Which of the following is not in place sorting algorithm by default?",
    options: "a) merge sort",
    options: "b) quick sort",
    options: "c) heap sort",
    options: "d) insertion sort",
    answer: 1
    },
    {
    question: "6) Which of the following is not a stable sorting algorithm?",
    options: "a) Quick sort",
    options: "b) Cocktail sort",
    options: "c) Bubble sort",
    options: "d) Merge sort",
    answer: 1
    },
    {
    question: "7) What is the objective of the knapsack problem?",
    options: "a) To get maximum total value in the knapsack",
    options: "b) To get minimum total value in the knapsack",
    options: "c) To get maximum weight in the knapsack",
    options: "d) To get minimum weight in the knapsack",
    answer: 1
    },
    {
    question: "8) Which of the following stable sorting algorithm takes the least time when applied to an almost sorted array?",
    options: "a) Quick sort",
    options: "b) Insertion sort",
    options: "c) Selection sort",
    options: "d) Merge sort",
    answer: 4
    },
    {
    question: "9) Which of the following sorting algorithm makes use of merge sort?",
    options: "a) tim sort",
    options: "b) intro sort",
    options: "c) bogo sort",
    options: "d) quick sort",
    answer: 1
    },
    {
    question: "10) 16. Which of the following sorting algorithm does not use recursion?",
    options: "a) quick sort",
    options: "b) merge sort",
    options: "c) heap sort",
    options: "d) bottom up merge sort",
    answer: 4
    }];