let MCQS = [{
    question: "1) A virus is made up of _______.",
    options: "a) Protein coat and nucleic acid",
    options: "b) Protein coat and mitochondria",
    options: "c) Nucleic acid and cell membrane",
    options: "d) Nucleic acid, cell wall and cell membrane",
    answer: 2
    },
    {
    question: "2) The protein coat of viruses that enclose the genetic material is called _______",
    options: "a) Virion",
    options: "b) Capsid",
    options: "c) Peplomers",
    options: "d) Capsomers",
    answer: 3
    },
    {
    question: "3) 3. Which of the following statements are true about a virion?",
    options: "a) Lytic phage",
    options: "b) Lysogenic phage",
    options: "c) The viral capsid",
    options: "d) An infectious and fully formed viral particle",
    answer: 4
    },
    {
    question: "4) Which of the following is the genome of the virus?",
    options: "a) DNA",
    options: "b) RNA",
    options: "c) DNA or RNA",
    options: "d) DNA and RNA",
    answer: 3
    },
    {
    question: "5) Which of the following is the largest virus?",
    options: "a) Megavirus chilensis",
    options: "b) Arbo virus",
    options: "c) Herpes virus",
    options: "d) Mumps virus",
    answer: 1
    },
    {
    question: "6) Which of the following has a complex symmetry?",
    options: "a) T4 phage",
    options: "b) Adenovirus",
    options: "c) Influenza virus",
    options: "d) All of the aoove",
    answer: 1
    },
    {
    question: "7) The viral envelope is made up of _______",
    options: "a) Proteins",
    options: "b) Glycoproteins",
    options: "c) Lipids and Proteins",
    options: "d) All of the above",
    answer: 4
    },
    {
    question: "8) Which of the following is a helical virus?",
    options: "a) TMV",
    options: "b) T4 phage",
    options: "c) Poxvirus",
    options: "d) Herpes virus",
    answer: 1
    },
    {
    question: "9) Which of the following statements are true about the viruses?",
    options: "a) Free-living",
    options: "b) Obligate parasites",
    options: "c) Both (a) and (b)",
    options: "d) None of the above",
    answer: 2
    },
    {
    question: "10) A fully formed infectious viral particle is called _________ ",
    options: "a) Virion",
    options: "b) Viriod",
    options: "c) Capsid",
    options: "d) Virusoid",
    answer: 1
    }];