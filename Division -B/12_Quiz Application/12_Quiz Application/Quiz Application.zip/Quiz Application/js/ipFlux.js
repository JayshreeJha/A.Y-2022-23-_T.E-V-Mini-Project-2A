let MCQS = [{
    question: "Which of the following is the correct name of React.js?",
    choice1: "a) React",
    choice2: "b) React.js",
    choice3: "c) ReactJS",
    choice4: "d) All of the above",
    answer: 4
    },
    {
    question: "Which of the following are the advantages of React.js?",
    choice1: "a) React.js can increase the application's performance with Virtual DOM.",
    choice2: "b) React.js is easy to integrate with other frameworks such as Angular, BackboneJS since it is only a view library.",
    choice3: "c) React.js can render both on client and server side.",
    choice4: "d) All of the above",
    answer: 4
    },
    {
    question: "Which of the following is not a disadvantage of React.js?",
    choice1: "a) React.js has only a view layer. We have put your code for Ajax requests, events and so on.",
    choice2: "b) The library of React.js is pretty large.",
    choice3: "c) The JSX in React.js makes code easy to read and write.",
    choice4: "d) The learning curve can be steep in React.js.",
    answer: 3
    },
    {
    question: "Which of the following command is used to install create-react-app?",
    choice1: "a) npm install -g create-react-app",
    choice2: "b) npm install create-react-app",
    choice3: "c) npm install -f create-react-app",
    choice4: "d) install -g create-react-app",
    answer: 1
    },
    {
    question: "What of the following is used in React.js to increase performance?",
    choice1: "a) Original DOM",
    choice2: "b) Virtual DOM",
    choice3: "c) Both A and B",
    choice4: "d) None of the above",
    answer: 2
    },
    {
    question: "A class is a type of function, but instead of using the keyword function to initiate it, which keyword do we use?",
    choice1: "a) Constructor",
    choice2: "b) Class",
    choice3: "c) Object",
    choice4: "d) DataObject",
    answer: 2
    },
    {
    question: "Which of the following acts as the input of a class-based component?",
    choice1: "a) Class",
    choice2: "b) Factory",
    choice3: "c) Render",
    choice4: "d) Props",
    answer: 4
    },
    {
    question: "Which of the following keyword is used to create a class inheritance?",
    choice1: "a) Create",
    choice2: "b) Inherits",
    choice3: "c) Extends",
    choice4: "d) This",
    answer: 3
    },
    {
    question: "What is the default port where webpack-server runs?",
    choice1: "a) 3000",
    choice2: "b) 8080",
    choice3: "c) 3030",
    choice4: "d) 6060",
    answer: 2
    },
    {
    question: "How many numbers of elements a valid react component can return?",
    choice1: "a) 1",
    choice2: "b) 2",
    choice3: "c) 4",
    choice4: "d) 5",
    answer: 1
    }];