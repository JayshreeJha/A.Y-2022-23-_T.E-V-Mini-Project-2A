let MCQS = [{
    question: "1. Job sequencing with deadline is based on ____________method",
    options: "a) greedy method",
    options: "b) branch and bound",
    options: "c) dynamic programming",
    options: "d) divide and conquer",
    answer: 1
    },
    {
    question: "2. Greedy job scheduling with deadlines algorithms’ complexity is defined as",
    options: "a) O(N)",
    options: "b) O(log n)",
    options: "c) O(n)",
    options: "d) O(n log n)",
    answer: 1
    },
    {
    question: "3. The method which return different solutions from a single point ,which is _________",
    options: "a) greedy method",
    options: "b) branch and bound",
    options: "c) dynamic programming",
    options: "d) divide and conquer",
    answer: 1
    },
    {
    question: "4. Job sequencing with deadline is based on ____________method",
    options: "a) greedy method",
    options: "b) branch and bound",
    options: "c) dynamic programming",
    options: "d) divide and conquer",
    answer: 1
    },
    {
    question: "5) fractional knapsack is based on ____________method",
    options: "a) greedy method",
    options: "b) branch and bound",
    options: "c) dynamic programming",
    options: "d) divide and conquer",
    answer: 1
    },
    {
    question: "6) The files x1,x2,x3 are 3 files of length 30,20,10 records each. What is the optimal merge pattern value?",
    options: "a) 110",
    options: "b) 60",
    options: "c) 90",
    options: "d) 50",
    answer: 3
    },
    {
    question: "7) The optimal merge pattern is based on _________ method",
    options: "a) Greedy method",
    options: "b) Dynamic programming",
    options: "c) Knapsack method",
    options: "d) Branch and bound",
    answer: 1
    },
    {
    question: "8) 7. Which of the following standard algorithms is not a Greedy algorithm?",
    options: "a) Dijkstra's shortest path algorithm",
    options: "b) Prim's algorithm",
    options: "c) Kruskal algorithm",
    options: "d) Bellmen Ford Shortest path algorithm",
    answer: 4
    },
    {
    question: "9) 8. What is the time complexity of Huffman Coding?",
    options: "a) O(N)",
    options: "b) O(NlogN)",
    options: "c) O(N(logN)2",
    options: "d) O(N2)",
    answer: 2
    },
    {
    question: "10) 9. Which of the following is true about Huffman Coding.",
    options: "a) Huffman coding may become lossy in some cases",
    options: "b) Huffman codes may not be optimal lossless codes in some cases",
    options: "c) In Huffman coding, no code is prefix of any other code",
    options: "d) All of the above",
    answer: 3
    }];