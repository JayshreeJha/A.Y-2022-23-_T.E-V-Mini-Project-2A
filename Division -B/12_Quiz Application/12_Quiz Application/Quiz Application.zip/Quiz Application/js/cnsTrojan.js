let MCQS = [{
    question: "1) A ___________ is a small malicious program that runs hidden on infected system.",
    options: "a) Virus",
    options: "b) Trojan",
    options: "c) Shareware",
    options: "d) Adware",
    answer: 2
    },
    {
    question: "2) ____________ works in background and steals sensitive data.",
    options: "a) Virus",
    options: "b) Shareware",
    options: "c) Trojan",
    options: "d) Adware",
    answer: 3
    },
    {
    question: "3) Trojan creators do not look for _______________",
    options: "a) Credit card information",
    options: "b) Confidential data",
    options: "c) Important documents",
    options: "d) Securing systems with such programs",
    answer: 4
    },
    {
    question: "4) Which of them is not a proper way of getting into the system?",
    options: "a) IM",
    options: "b) Attachments",
    options: "c) Official product sites",
    options: "d) Un-trusted sites, freeware and pirated software",
    answer: 3
    },
    {
    question: "5) Which of the following port is not used by Trojans?",
    options: "a) UDP",
    options: "b) TCP",
    options: "c) SMTP",
    options: "d) MP",
    answer: 4
    },
    {
    question: "6) Trojans do not do one of the following. What is that?",
    options: "a) Deleting Data",
    options: "b) Protecting Data",
    options: "c) Modifying Data",
    options: "d) Copying Data",
    answer: 2
    },
    {
    question: "7) Once activated __________ can enable ____________to spy on the victim, steal their sensitive information & gain backdoor access to the system.    ",
    options: "a) virus, cyber-criminals",
    options: "b) malware, penetration testers",
    options: "c) trojans, cyber-criminals",
    options: "d) virus, penetration testers",
    answer: 3
    },
    {
    question: "8) Trojans can not ______________",
    options: "a) steal data",
    options: "b) self-replicate",
    options: "c) c) steal financial information",
    options: "d) steal login credentials",
    answer: 2
    },
    {
    question: "9) A _______________ provides malicious users remote control over the targeted computer.",
    options: "a) DDoS-Trojan",
    options: "b) Backdoor Trojan",
    options: "c) Trojan-Banker",
    options: "d) Trojan-Downloader",
    answer: 1
    },
    {
    question: "10) ____________ work in background & keeps on downloading other malicious programs when the system is online.",
    options: "a) DDoS-Trojan",
    options: "b) Backdoor Trojan",
    options: "c) Trojan-Banker",
    options: "d) Trojan-Downloader",
    answer: 4
    }];