let MCQS = [{
    question: "How can we write comment along with CSS code ?",
    choice1: "a) /* a comment*/",
    choice2: "b) //a comment //",
    choice3: "c) / a comment/",
    choice4: "d) <’a comment’>",
    answer: 1
    },
    {
    question: "How can we write comment along with HTML code?",
    choice1: "a) #comment",
    choice2: "b) <!—comment -->",
    choice3: "c) //comment",
    choice4: "d) /*comment*/",
    answer: 2
    },
    {
    question: "The property in CSS used to change the background color of an element is -",
    choice1: "a) bgcolor",
    choice2: "b) color",
    choice3: "c) background-color",
    choice4: "d)All of the above",
    answer: 3
    },
    {
    question: "The property in CSS used to change the text color of an element is -",
    choice1: "a) bgcolor",
    choice2: "b) color",
    choice3: "c) background-color",
    choice4: "d) All of the above",
    answer: 2
    },
    {
    question: "The CSS property used to control the element's font-size is -",
    choice1: "a) text-style",
    choice2: "b) text-size",
    choice3: "c) font-size",
    choice4: "d) None of the above",
    answer: 3
    },
    {
    question: "The HTML attribute used to define the inline styles is -",
    choice1: "a) style",
    choice2: "b) styles",
    choice3: "c) class",
    choice4: "d) None of the above",
    answer: 1
    },
    {
    question: "The HTML attribute used to define the internal stylesheet is -",
    choice1: "a) <style>",
    choice2: "b) style",
    choice3: "c) <link>",
    choice4: "d) <script>",
    answer: 1
    },
    {
    question: "Which of the following CSS property is used to set the background image of an element?",
    choice1: "a) background-attachment",
    choice2: "b) background-image",
    choice3: "c) background-color",
    choice4: "d) None of the above",
    answer: 2
    },
    {
    question: "Which of the following is the correct syntax to make the background-color of all paragraph elements to yellow?",
    choice1: "a) p {background-color : yellow;}",
    choice2: "b) p {background-color : #yellow;}",
    choice3: "c) all {background-color : yellow;}",
    choice4: "d) all p {background-color : #yellow;}",
    answer: 1
    },
    {
    question: "Which of the following is the correct syntax to display the hyperlinks without any underline?",
    choice1: "a) a {text-decoration : underline;}",
    choice2: "b) a {decoration : no-underline;}",
    choice3: "c) a {text-decoration : none;}",
    choice4: "d) None of the above",
    answer: 3
    }];
  