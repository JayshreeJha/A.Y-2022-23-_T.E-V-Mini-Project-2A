let MCQS = [{
    question: "1. In a B+ tree, both the internal nodes and the leaves have keys.",
    choice1: "a) True",
    choice2: "b) False",
    choice3: "c) None",
    choice4: "d) All of the above",
    answer: 2
},
{
    question: "2. Which of the following is true?",
    choice1: "a) B + tree allows only the rapid random access",
    choice2: "b) B + tree allows only the rapid sequential access",
    choice3: "c) B + tree allows rapid random access as well as rapid sequential access",
    choice4: "d) B + tree allows rapid random access and slower sequential access",
    answer: 3
},
{
    question: "3. A B+ tree can contain a maximum of 7 pointers in a node. What is the minimum number of keys in leaves?",
    choice1: "a) 6",
    choice2: "b) 3",
    choice3: "c) 4",
    choice4: "d) 7",
    answer: 2
},
{
    question: "4. Which of the following is false?",
    choice1: "a) A B+ -tree grows downwards",
    choice2: "b) A B+ -tree is balanced",
    choice3: "c) In a B+ -tree, the sibling pointers allow sequential searching",
    choice4: "d) B+ -tree is shallower than B-tree",
    answer: 1
},
{
    question: "7. Efficiency of finding the next record in B+ tree is ____",
    choice1: "a) O(n)",
    choice2: "b) O(log n)",
    choice3: "c) O(nlog n)",
    choice4: "d) O(1)",
    answer: 4
},
{
    question: "8. What is the maximum number of keys that a B+ -tree of order 3 and of height 3 have?",
    choice1: "a) 3",
    choice2: "b) 80",
    choice3: "c) 27",
    choice4: "d) 26",
    answer: 4
},
{
    question: "9. Which of the following is false?",
    choice1: "a) Compared to B-tree, B+ -tree has larger fanout",
    choice2: "b) Deletion in B-tree is more complicated than in B+ -tree",
    choice3: "c) B+ -tree has greater depth than corresponding B-tree",
    choice4: "d) d) Both B-tree and B+ -tree have same search and insertion efficiencies",
    answer: 3
},
{
    question: "10. Which one of the following data structures are preferred in database-system implementation?",
    choice1: "a) AVL tree",
    choice2: "b) B-tree",
    choice3: "c) B+ -tree",
    choice4: "d) Splay tree",
    answer: 3
},
{
    question: "Which of the following is the most widely used external memory data structure?",
    choice1: "a) AVL tree",
    choice2: "b) B-tree",
    choice3: "c) Red-black tree",
    choice4: "d) Both AVL tree and Red-black tree",
    answer: 2
},
{
    question: "B-tree of order n is a order-n multiway tree in which each non-root node contains ______",
    choice1: "a) at most (n - 1)/2 keys",
    choice2: "b) exact (n - 1)/2 keys",
    choice3: "c) at least 2n keys",
    choice4: "d) at least (n - 1)/2 keys",
    answer: 4
}];