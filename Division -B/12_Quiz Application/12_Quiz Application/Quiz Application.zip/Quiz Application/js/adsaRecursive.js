let MCQS = [{
    question: "Recursion is a method in which the solution of a problem depends on ____________",
    choice1: "a) Larger instances of different problems",
    choice2: "b) Larger instances of the same problem",
    choice3: "c) Smaller instances of the same problem",
    choice4: "d) Smaller instances of different problems",
    answer: 3
},
{
    question: "Which of the following problems can’t be solved using recursion?    ",
    choice1: "a) Factorial of a number",
    choice2: "b) Nth fibonacci number",
    choice3: "c) Length of a string",
    choice4: "d) Problems without base case",
    answer: 4
},
{
    question: "Recursion is similar to which of the following?",
    choice1: "a) Switch Case",
    choice2: "b) Loop",
    choice3: "c) If-else",
    choice4: "d) if elif else",
    answer: 2
},
{
    question: "In recursion, the condition for which the function will stop calling itself is ____________",
    choice1: "a) Best case",
    choice2: "b) Worst case",
    choice3: "c) Base case",
    choice4: "d) There is no such condition",
    answer: 3
},
{
    question: "Which Data Structure is mainly used for implementing the recursive algorithm?",
    choice1: "a) Queue",
    choice2: "b) Stack",
    choice3: "c) Linked List",
    choice4: "D) Tree",
    answer: 2
},
{
    question: "3) What’s happen if base condition is not defined in recursion ?",
    choice1: "a) Stack underflow",
    choice2: "b) Stack Overflow",
    choice3: "c) None of these",
    choice4: "d) Both a and b",
    answer: 2
},
{
    question: "Recursion is similar to which of the following?",
    choice1: "a) Switch Case",
    choice2: "b) Loop",
    choice3: "c) If-else",
    choice4: "d) None",
    answer: 2
},
{
    question: "Recursion uses more memory compared to iteration.",
    choice1: "a) True",
    choice2: "b) False",
    choice3: "c) Both",
    choice4: "d) None of the above",
    answer: 1
},
{
    question: "12) Which of the following problem cannot be solved using recursion?",
    choice1: "a) Tower of Hanoi",
    choice2: "b) Fibonacci series",
    choice3: "c) Tree Traversal",
    choice4: "d) Problems without base case",
    answer: 4
},
{
    question: "13) Which searching can be performed recursively?",
    choice1: "a) Linear search",
    choice2: "b) Binary search",
    choice3: "c) Both",
    choice4: "d) None",
    answer: 3
}];