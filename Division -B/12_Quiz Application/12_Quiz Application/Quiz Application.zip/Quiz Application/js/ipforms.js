let MCQS = [{
    question: "What is the default type of ‘type’ attribute of <input> element?",
    choice1: "a) Text",
    choice2: "b) Password",
    choice3: "c) Numerals",
    choice4: "d) Special Characters",
    answer: 1
    },
    {
    question: "Which of the following is a new input attribute introduce by HTML5?",
    choice1: "a) text",
    choice2: "b) checkbox controls",
    choice3: "c) submit buttons",
    choice4: "d) date",
    answer: 4
    },
    {
    question: "How does the color attribute work?",
    choice1: "a) Changes color of the text",
    choice2: "b) Changes background color",
    choice3: "c) The color picker is defined by it",
    choice4: "d) Changes color of the text as well as background",
    answer: 3
    },
    {
    question: "Which attribute is used for activation of JavaScript?",
    choice1: "a) button",
    choice2: "b) checkbox",
    choice3: "c) url",
    choice4: "d) submit",
    answer: 1
    },
    {
    question: "Which attribute defines the file-select field?",
    choice1: "a) file",
    choice2: "b) checkbox",
    choice3: "c) button",
    choice4: "d) text",
    answer: 1
    },
    {
    question: "How image attribute works?",
    choice1: "a) Sets an image background",
    choice2: "b) Set an image as submit button",
    choice3: "c) Set an image anywhere on the page",
    choice4: "d) Bring default image to the page",
    answer: 2
    },
    {
    question: "month attribute defines __________",
    choice1: "a) the only month",
    choice2: "b) month and year",
    choice3: "c) date",
    choice4: "d) date and time",
    answer: 2
    },
    {
    question: "week attribute defines ____________ ",
    choice1: "a) week",
    choice2: "b) year",
    choice3: "c) week and year",
    choice4: "d) week, month and year",
    answer: 3
    },
    {
    question: "tel attribute is supported by the _________ browser.",
    choice1: "a) Chrome",
    choice2: "b) Safari",
    choice3: "c) Opera",
    choice4: "d) Internet Explorer",
    answer: 1
    },
    {
    question: "Which attribute is not used on new forms?",
    choice1: "a) size",
    choice2: "b) text",
    choice3: "c) name",
    choice4: "d) maxlength",
    answer: 1
    }];