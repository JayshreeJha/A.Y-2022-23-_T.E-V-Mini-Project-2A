let MCQS = [{
    question: "1. What is the special property of red-black trees and what root should always be?",
    choice1: "a) a color which is either red or black and root should always be black color only",
    choice2: "b) height of the tree",
    choice3: "c) pointer to next node",
    choice4: "d) a color which is either green or black",
    answer: 1
},
{
    question: "What are the operations that could be performed in O(logn) time complexity by red-black tree?",
    choice1: "a) insertion, deletion, finding predecessor, successor",
    choice2: "b) only insertion",
    choice3: "c) only finding predecessor, successor",
    choice4: "d) for sorting",
    answer: 1
},
{
    question: "5. Which of the following is an application of Red-black trees and why?",
    choice1: "a) used to store strings efficiently",
    choice2: "b) used to store integers efficiently",
    choice3: "c) can be used in process schedulers, maps, sets",
    choice4: "d) for efficient sorting",
    answer: 3
},
{
    question: "6. When it would be optimal to prefer Red-black trees over AVL trees?",
    choice1: "a) when there are more insertions or deletions",
    choice2: "b) when more search is needed",
    choice3: "c) when tree must be balanced",
    choice4: "d) when log(nodes) time complexity is needed",
    answer: 1
},
{
    question: "7. Why Red-black trees are preferred over hash tables though hash tables have constant time complexity?",
    choice1: "a) no they are not preferred",
    choice2: "b) because of resizing issues of hash table and better ordering in redblack trees",
    choice3: "c) because they can be implemented using trees",
    choice4: "d) because they are balanced",
    answer: 2
},
{
    question: "8. How can you save memory when storing color information in Red-Black tree?",
    choice1: "a) using least significant bit of one of the pointers in the node for color information",
    choice2: "b) using another array with colors of each node",
    choice3: "c) storing color information in the node structure",
    choice4: "d) using negative and positive numbering",
    answer: 1
},
{
    question: "9. When to choose Red-Black tree, AVL tree and B-trees?",
    choice1: "a) many inserts, many searches and when managing more items respectively",
    choice2: "b) many searches, when managing more items respectively and many inserts respectively",
    choice3: "c) sorting, sorting and retrieval respectively",
    choice4: "d) retrieval, sorting and retrieval respectively",
    answer: 1
},
{
    question: "Which of the following IS NOT a property of red-black trees",
    choice1: "a) every sentinel/leaf node has the same number of red ancestors",
    choice2: "b) the root of the tree must be black",
    choice3: "c) every red node must have black children",
    choice4: "d) every sentinel/leaf node is black",
    answer: 1
},
{
    question: "Red-black trees use color to ensure___",
    choice1: "a) O(h) recolorings and O(1) restructurings",
    choice2: "b) O(1) recolorings and O(h) restructurings",
    choice3: "c) O(log n) restructurings for each insert",
    choice4: "d) O(log n) restructurings for each delete",
    answer: 1
},
{
    question: "When inserting a new entry into a red-black tree, the newly created node will be___",
    choice1: "a) red, if the new node is not the root node",
    choice2: "b) red, if the new node is the root node",
    choice3: "c) black, if the new node is not the root node",
    choice4: "d) the same color as its sibling",
    answer: 1
}];