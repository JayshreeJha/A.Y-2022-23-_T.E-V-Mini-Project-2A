let MCQS = [{
    question: "1) Network layer firewall works as a _________",
    options: "a) Frame filter",
    options: "b) Packet filter",
    options: "c) Content filter",
    options: "d) Virus filter",
    answer: 2
    },
    {
    question: "2) Network layer firewall has two sub-categories as _________",
    options: "a) State full firewall and stateless firewall",
    options: "b) Bit oriented firewall and byte oriented firewall",
    options: "c) Frame firewall and packet firewall",
    options: "d) Network layer firewall and session layer firewall",
    answer: 1
    },
    {
    question: "3) Which of the following is / are the types of firewall?",
    options: "a) Packet Filtering Firewall",
    options: "b) Dual Homed Gateway Firewall",
    options: "c) Screen Host Firewall",
    options: "d) Dual Host Firewall",
    answer: 1
    },
    {
    question: "4) A proxy firewall filters at _____",
    options: "a) Physical layer",
    options: "b) Data link layer",
    options: "c) Network layer",
    options: "d) Application layer",
    answer: 4
    },
    {
    question: "5) A packet filter firewall filters at ______",
    options: "a) Physical layer",
    options: "b) Data link layer",
    options: "c) Network layer or Transport layer",
    options: "d) Application layer",
    answer: 3
    },
    {
    question: "6) What is one advantage of setting up a DMZ with two firewalls?",
    options: "a) You can control where traffic goes in three networks",
    options: "b) You can do stateful packet filtering",
    options: "c) You can do load balancing",
    options: "d) Improved network performance",
    answer: 3
    },
    {
    question: "7) A stateful firewall maintains a ___________ which is a list of active connections.",
    options: "a) Routing table",
    options: "b) Bridging table",
    options: "c) State table",
    options: "d) Connection table",
    answer: 1
    },
    {
    question: "8) Which of the following is a helical virus?",
    options: "a) TMV",
    options: "b) T4 phage",
    options: "c) Poxvirus",
    options: "d) Herpes virus",
    answer: 1
    },
    {
    question: "9) Which of the following statements are true about the viruses?",
    options: "a) Free-living",
    options: "b) Obligate parasites",
    options: "c) Both (a) and (b)",
    options: "d) None of the above",
    answer: 2
    },
    {
    question: "10) A firewall needs to be __________ so that it can grow proportionally with the network that it protects. ",
    options: "a) Robust",
    options: "b) Expansive",
    options: "c) Fast",
    options: "d) Scalable",
    answer: 2
    }];