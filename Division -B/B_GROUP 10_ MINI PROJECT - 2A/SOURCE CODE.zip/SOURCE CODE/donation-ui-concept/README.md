# Donation UI Concept

A Pen created on CodePen.io. Original URL: [https://codepen.io/drew_mc/pen/ZGGErL](https://codepen.io/drew_mc/pen/ZGGErL).

A concept UI for processing political donations. Still needs input validation...