<?php

/*session_start();

include("connection.php");
include("function.php");

$user_data = check_login($con);*/

?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Admin</title>
    <link rel="stylesheet" href="../css/superadmin.css">
</head>
<body>

    <div class="sidebar">
        <header>Super Admin</header>

        <ul>
            <li><a href="index.php" style="color: #ffa500;">Dashbord</a></li>
            <li><a href="add-admin.php">Add Admin</a></li>
            <li><a href="customer-details.php">Customer Details</a></li>
            <li><a href="order-details.php">Order Details</a></li>
            <li><a href="admin-details.php">Admin Details</a></li>
            <li><a href="delivery-member.php">Delivery Members</a></li>
            <li><a href="restaurant.php">Restaurant</a></li>
            <li><a href="payment.php">Payment</a></li>
            <li><a href="../index.php">Home Page</a></li>
        </ul>
    </div>

    <form>
        <h1 style="text-align: center; padding: 50px;">SUPER ADMIN DASHBORD</h1>

        <div style="display: flex; justify-content: center; align-items: center;">
            <img src="../images/Master.jpeg" alt="logo" >
        </div>
        
        <h2 style="text-align: center; padding: 40px; text-decoration: underline; color: #ff4500;">OUR VISION</h2>
        <P style="text-align: center;">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Omnis qui quibusdam sapiente, facere deserunt 
        repudiandae suscipit dolorem quae iusto veritatis magnam officia ipsa provident est ullam neque? Hic, quod iure. Lorem ipsum dolor sit 
        amet consectetur, adipisicing elit. Pariatur adipisci ab sunt cupiditate, voluptatum vitae recusandae omnis voluptate nostrum vero 
        molestiae harum accusamus dicta suscipit delectus repellat culpa architecto nam. Lorem ipsum dolor sit amet consectetur adipisicing elit. 
        In dolores libero quam vel qui ad, placeat quis dolor cum modi cumque adipisci quos soluta officiis odio suscipit a rerum laboriosam. 
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis distinctio tempora culpa consequuntur doloribus totam maxime aperiam dolorum 
        ipsum nisi amet odit, neque repellendus quasi maiores asperiores cupiditate. Maxime, quod. Lorem ipsum dolor sit amet, consectetur adipisicing 
        elit. Officiis, natus quam doloremque repudiandae sequi ea perspiciatis itaque deleniti voluptates dolorem incidunt reprehenderit non ratione 
        magni odit? Numquam, veniam consequatur? Laborum?</P>


        <h2 style="text-align: center; padding: 40px; text-decoration: underline; color: #ffa500;">OUR MISSION</h2>
        <P style="text-align: center;">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Omnis qui quibusdam sapiente, facere deserunt 
        repudiandae suscipit dolorem quae iusto veritatis magnam officia ipsa provident est ullam neque? Hic, quod iure. Lorem ipsum dolor sit 
        amet consectetur, adipisicing elit. Pariatur adipisci ab sunt cupiditate, voluptatum vitae recusandae omnis voluptate nostrum vero 
        molestiae harum accusamus dicta suscipit delectus repellat culpa architecto nam. Lorem ipsum dolor sit amet consectetur adipisicing elit. 
        In dolores libero quam vel qui ad, placeat quis dolor cum modi cumque adipisci quos soluta officiis odio suscipit a rerum laboriosam. 
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis distinctio tempora culpa consequuntur doloribus totam maxime aperiam dolorum 
        ipsum nisi amet odit, neque repellendus quasi maiores asperiores cupiditate. Maxime, quod. Lorem ipsum dolor sit amet, consectetur adipisicing 
        elit. Officiis, natus quam doloremque repudiandae sequi ea perspiciatis itaque deleniti voluptates dolorem incidunt reprehenderit non ratione 
        magni odit? Numquam, veniam consequatur? Laborum? Lorem ipsum, dolor sit amet consectetur adipisicing elit. Culpa reprehenderit quod, 
        id deleniti iste adipisci facilis nam similique cumque ipsa laudantium officiis eius quam eveniet voluptates sunt. Asperiores, dolorem 
        consectetur.</P>
    </form>
    
</body>
</html>