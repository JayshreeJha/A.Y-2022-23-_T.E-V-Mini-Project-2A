import React from 'react'
import StyledSpinner from './StyledSpinner'

const Spinner = () => <StyledSpinner />

export default Spinner