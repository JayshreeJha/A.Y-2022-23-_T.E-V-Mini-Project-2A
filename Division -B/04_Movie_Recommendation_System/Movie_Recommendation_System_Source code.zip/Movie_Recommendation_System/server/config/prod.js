module.exports = {
    mongoURI:process.env.MONGO_URI,
    sendGrid:process.env.SENDGRID_API_KEY
}