<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://code.iconify.design/iconify-icon/1.0.0-beta.3/iconify-icon.min.js"></script>
    <title>Payment Portal</title>
    <link rel="stylesheet" href="Payment.css">
</head>

<body>
    <header>
        <div class="container">
            <div class="left">
                <h3>PAYMENT PORTAL</h3>
                <img src="images/homeservice.jpg">
                <div class="right">
                    <form action="Pay.php" method="post">
                        Accepted Card<br>
                        <iconify-icon icon="cib:cc-visa"></iconify-icon>
                        <iconify-icon icon="logos:mastercard"></iconify-icon><br>
                        Card Holder Name
                        <input type="text" placeholder="Enter Card Holder Name" name="Name"><br>
                        Card Number
                        <input type="number" placeholder="Enter Card Number" name="Number">
                        <div id="zip">
                            <label>
                                Exp Month<br>
                                <select style="margin-top: 10px;width: 200px;" name="month">
                                    <option>Choose Month</option>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                    <option value="9">9</option>
                                    <option value="10">10</option>
                                    <option value="11">11</option>
                                    <option value="12">12</option>
                                </select>
                            </label>
                            <label class="zippp">
                                Exp Year<br>
                                <select style="margin-top: 10px;width: 200px;" name="year">
                                    <option>Choose Year</option>
                                    <option value="2022">2022</option>
                                    <option value="2023">2023</option>
                                    <option value="2024">2024</option>
                                    <option value="2025">2025</option>
                                    <option value="2026">2026</option>
                                    <option value="2027">2027</option>
                                    <option value="2028">2028</option>
                                </select>
                            </label>
                            <label class="zippp">
                                CVV
                                <input type="password" placeholder="Enter CVV" style="width: 200px; height:35px;margin-top:5px" name="cvv">
                            </label>
                        </div>
                        <a href="http://127.0.0.1:5500/Customer/MainP.html"><input type="submit" value="Proceed to Pay" name="save"></a>
                        <a href="http://localhost:3000/Customer/Carts.php"><button type="button">Back</button></a>
                    </form>
                </div>
            </div>
    </header>
</body>

</html>