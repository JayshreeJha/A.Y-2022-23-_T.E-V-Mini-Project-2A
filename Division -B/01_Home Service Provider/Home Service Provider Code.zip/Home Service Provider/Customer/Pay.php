<?php
include 'connection copy.php';
if (isset($_POST['save'])) {
	$Name = $_POST['Name'];
	$Number = $_POST['Number'];
	$month = $_POST['month'];
	$year = $_POST['month'];
	$cvv = $_POST['cvv'];

	$sql_query = "INSERT INTO card (Name, Number, month, year, cvv)
		VALUES ('$Name','$Number','$month','$year','$cvv')";

	if (mysqli_multi_query($conn, $sql_query)) {
		echo "New Details Entry inserted successfully !";
		$sql_query  =  "insert history select * from cart";
		if ($conn->query($sql_query) === true) {
			echo "Data Copied Successfully.";
			$new = "TRUNCATE TABLE `cart`";
			if (mysqli_multi_query($conn, $new)) {
				echo "History is done";
				header("Location: http://127.0.0.1:5500/Customer/MainP.html");
			} else {
				echo "Error: " . $sql . "" . mysqli_error($conn);
			}
		} else {
			echo "ERROR: Could not able to proceed $sql_query. "
				. $connection_link->error;
		}
	} else {
		echo "Error: " . $sql . "" . mysqli_error($conn);
	}
	mysqli_close($conn);
}
