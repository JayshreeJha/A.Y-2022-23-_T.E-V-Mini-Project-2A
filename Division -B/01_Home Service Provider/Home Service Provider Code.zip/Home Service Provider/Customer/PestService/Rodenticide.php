<!DOCTYPE html>
<html>

<head>
    <title>Rodenticide Service</title>
    <link rel="stylesheet" href="Rodenticide.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.iconify.design/iconify-icon/1.0.0-beta.3/iconify-icon.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script&family=Mouse+Memoirs&family=Oleo+Script+Swash+Caps&display=swap" rel="stylesheet">

<body>
    <!--MAIN PAGE BANNER-->
    <section>
        <div class="banner">
            <div class="navbar">
                <img src="../images/Loggo.PNG" class="logo">
                <ul>
                    <li><a href="http://127.0.0.1:5500/Customer/MainP.html">HOME <iconify-icon icon="clarity:home-solid"></iconify-icon> </a></li>
                    <li><a href="http://127.0.0.1:5500/Customer/AboutUs.html">ABOUT US <iconify-icon icon="bxs:help-circle"></iconify-icon></a></li>
                    <li><a href="http://127.0.0.1:5500/Customer/Services.html" class="active">SERVICES <iconify-icon icon="fa-solid:hands-helping"></iconify-icon></a></li>
                    <li><a href="http://localhost:3000/Customer/Carts.php">CART <iconify-icon icon="ant-design:shopping-cart-outlined" width="18">
                            </iconify-icon></a>
                    <li><a href="#">
                            <iconify-icon icon="ic:outline-account-circle" width="27" iconify-icon>
                        </a>
                        <ul class="reg">
                            <li><a href="http://localhost:3000/Customer/history.php">History</a></li>
                            <li><a href="../Normal View/MainP.html">Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
            <div class="content">
                <h1>RODENTICIDE TREATMENT SERVICE</h1>
                <h2>Tired of Rats!!! We will get rid of them for you.</h2>
            </div>
        </div>
    </section>
    <section>
        <div class="wrapper">
            <div class="single-price">
                <h1>1 BHK</h1>
                <div class="price">
                    <h2>&#x20B9 599</h2>
                </div>
                <div class="deals">
                    <h4>Approx. Rat Control Charges</h4>
                </div>
                <a href="?lis" onclick='alert("Added to cart")'>Select</a>
            </div>
            <div class="single-price">
                <h1>2 BHK</h1>
                <div class="price">
                    <h2>&#x20B9 899</h2>
                </div>
                <div class="deals">
                    <h4>Approx. Rat Control Charges</h4>
                </div>
                <a href="?list2" onclick='alert("Added to cart")'>Select</a>
            </div>
            <div class="single-price">
                <h1>3 BHK</h1>
                <div class="price">
                    <h2>&#x20B9 1099</h2>
                </div>
                <div class="deals">
                    <h4>Approx. Rat Control Charges</h4>
                </div>
                <a href="?list3" onclick='alert("Added to cart")'>Select</a>
            </div>
            <div class="single-price1">
                <h1>4 BHK</h1>
                <div class="price1">
                    <h2>&#x20B9 1399</h2>
                </div>
                <div class="deals1">
                    <h4>Approx. Rat Control Charges</h4>
                </div>
                <a href="?list4" onclick='alert("Added to cart")'>Select</a>
            </div>
            <div class="single-price1">
                <h1>Bunglow</h1>
                <div class="price1">
                    <h2>&#x20B9 1599</h2>
                </div>
                <div class="deals1">
                    <h4>Approx. Rat Control Charges</h4>
                </div>
                <a href="?list5" onclick='alert("Added to cart")'>Select</a>
            </div>
        </div>
    </section>
    <!--FOOTER-->
    <section id="footer">
        <img src="images/foot.webp" class="foot-img">
        <div class="title-text">
            <p>CONTACT</p>
            <h1>OUR CONTACT INFO</h1>
        </div>
        <div class="foot-row">
            <div class="foot-left">
                <h1>Service Hours</h1>
                <p><i class="fa fa-clock-o"></i> Monday to Saturday - 8am to 10pm</p>
                <p><i class="fa fa-clock-o"></i> Sunday - 7am to 11pm</p>
            </div>
            <div class="foot-right">
                <h1>Get in Touch</h1>
                <p>Universal Building, xyz road <i class="fa fa-map-marker"></i></p>
                <p>+91 123456789 <i class="fa fa-phone"></i></p>
                <p>@gmail.com <i class="fa fa-envelope"></i></p>
            </div>
        </div>
        <div class="social-link">
            <i class="fa fa-facebook"></i>
            <i class="fa fa-instagram"></i>
            <i class="fa fa-twitter"></i>
            <i class="fa fa-youtube-play"></i>
            <p>Copyright &copy; 2022</p>
        </div>
    </section>
</body>

</html>


<?php
if (isset($_GET['lis'])) {
    include 'connection copy 2.php';
    $sql = "INSERT INTO cart (srno, Item, total, amount) VALUES ('1','1 BHK Rodenticide treatment', '599', '599')";
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    mysqli_close($conn);
}
if (isset($_GET['list2'])) {
    include 'connection copy 2.php';
    $sql = "INSERT INTO cart (srno, Item, total, amount) VALUES ('','2 BHK Rodenticide treatment', '899', '899')";
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    mysqli_close($conn);
}
if (isset($_GET['list3'])) {
    include 'connection copy 2.php';
    $sql = "INSERT INTO cart (srno, Item, total, amount) VALUES ('','3 BHK Rodenticide treatment', '1099', '1099')";
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    mysqli_close($conn);
}
if (isset($_GET['list4'])) {
    include 'connection copy 2.php';
    $sql = "INSERT INTO cart (srno, Item, total, amount) VALUES ('','4 BHK Rodenticide treatment', '1399', '1399')";
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    mysqli_close($conn);
}
if (isset($_GET['list5'])) {
    include 'connection copy 2.php';
    $sql = "INSERT INTO cart (srno, Item, total, amount) VALUES ('','Bunglow Rodenticide treatment', '1599', '1599')";
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    mysqli_close($conn);
}
?>