<?php
$server_name = "localhost";
$username = "root";
$password = "";
$database_name = "homeservice";

$conn = mysqli_connect($server_name, $username, $password, $database_name);

if (isset($_GET['list1'])) {
    include 'connection copy 2.php';
    $sql = "INSERT INTO cart (srno, Item, total, amount) VALUES ('1','1 BHK Full Cleaing', '2999', '2999')";
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    } else {
        echo "ERROR";
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    mysqli_close($conn);
}
if (isset($_GET['list2'])) {
    include 'connection copy 2.php';
    $sql = "INSERT INTO cart (srno, Item, total, amount) VALUES ('','2 BHK Full Cleaing', '3499', '3499')";
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    mysqli_close($conn);
}
if (isset($_GET['list3'])) {
    include 'connection copy 2.php';
    $sql = "INSERT INTO cart (srno, Item, total, amount) VALUES ('','3 BHK Full Cleaing', '4499', '4499')";
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    mysqli_close($conn);
}
if (isset($_GET['list4'])) {
    include 'connection copy 2.php';
    $sql = "INSERT INTO cart (srno, Item, total, amount) VALUES ('','4 BHK Full Cleaing', '5149', '5149')";
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    mysqli_close($conn);
}
if (isset($_GET['list5'])) {
    include 'connection copy 2.php';
    $sql = "INSERT INTO cart (srno, Item, total, amount) VALUES ('','5 BHK Full Cleaing', '5899', '5899')";
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    mysqli_close($conn);
}
if (isset($_GET['list6'])) {
    include 'connection copy 2.php';
    $sql = "INSERT INTO cart (srno, Item, total, amount) VALUES ('1','Studio Apartment Full Cleaing', '1999', '1999')";
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    mysqli_close($conn);
}
