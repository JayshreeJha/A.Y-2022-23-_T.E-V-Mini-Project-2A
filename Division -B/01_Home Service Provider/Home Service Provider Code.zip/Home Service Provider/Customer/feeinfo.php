<?php
	@include 'connection.php';
    if(isset($_POST['save']))
	{	
		$name = $_POST['name'];  
        $email = $_POST['email'];
        $feed = $_POST['feed'];  
		$sql_query = "INSERT INTO feedback (name, email, feed)
		VALUES ('$name', '$email','$feed')";

		if (mysqli_multi_query($conn, $sql_query)) 
		{
			echo "New Details Entry inserted successfully !";
			header("Location: http://127.0.0.1:5500/Customer/MainP.html");
		} 
		else
		{
			echo "Error: " . $sql . "" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
