<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="Cart.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://code.iconify.design/iconify-icon/1.0.0-beta.3/iconify-icon.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round|Open+Sans">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <style type="text/css">
        .bs-example {
            margin: 20px;
        }
    </style>
    <script type="text/javascript">
        $(document).ready(function() {
            $('[data-toggle="tooltip"]').tooltip();
        });

        function Deleteqry(srno) {
            if (confirm("Are you sure you want to delete this row?") == true)
                alert("Data is deleted")
            return false;
        }
    </script>
</head>

<body>
    <!--MAIN PAGE BANNER-->
    <section>
        <div class="banner">
            <div class="navbar">
                <img src="images/Loggo.PNG" class="logo">
                <ul>
                    <li><a href="http://127.0.0.1:5500/Customer/MainP.html">HOME <iconify-icon icon="clarity:home-solid"></iconify-icon> </a></li>
                    <li><a href="http://127.0.0.1:5500/Customer/AboutUs.html">ABOUT US <iconify-icon icon="bxs:help-circle"></iconify-icon></a></li>
                    <li><a href="http://127.0.0.1:5500/Customer/Services.html">SERVICES <iconify-icon icon="fa-solid:hands-helping"></iconify-icon></a></li>
                    <li><a href="#">CART <iconify-icon icon="ant-design:shopping-cart-outlined" width="18">
                            </iconify-icon></a>
                    <li><a href="#" class="active">
                            <iconify-icon icon="ic:outline-account-circle" width="27" iconify-icon>
                        </a>
                        <ul class="reg">
                            <li><a href="http://localhost:3000/Customer/history.php">History</a></li>
                            <li><a href="../Normal View/MainP.html">Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </section>
    <div class="bs-example">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header clearfix">
                        <h2 class="pull-left">Order history</h2>
                    </div>
                    <?php
                    include_once 'connection copy 2.php';
                    $result = mysqli_query($conn, "SELECT * FROM history");
                    ?>
                    <?php
                    if (mysqli_num_rows($result) > 0) {
                    ?>
                        <table class='table table-bordered table-striped'>
                            <tr>
                                <td>Sr. No</td>
                                <td>Date</td>
                                <td>Item</td>
                                <td>Amount</td>
                                <td>Status</td>
                                <!-- <td>Delete</td> -->
                            </tr>
                            <?php
                            $i = 0;
                            while ($row = mysqli_fetch_array($result)) {
                            ?>
                                <tr>
                                    <td><?php echo $row["srno"]; ?></td>
                                    <td><?php echo $row["date"]; ?></td>
                                    <td><?php echo $row["Item"]; ?></td>
                                    <td><?php echo $row["amount"]; ?></td>
                                    <td><?php echo $row["status"]; ?></td>
                                    <!-- <td>
                                        <form action="del.php" method="post"><input type="button" onclick='alert("deleted from cart")' class="btnnn" value="delete" style="margin-top: 10px;"></form>
                                    </td> -->
                                </tr>
                            <?php
                                $i++;
                            }
                            ?>
                            <?php
                            $resul = mysqli_query($conn, "SELECT SUM(total) AS totalsum FROM history");

                            $row = mysqli_fetch_array($resul);
                            ?>
                        </table>
                    <?php
                    } else {
                        echo "No history have been added";
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</body>

</html>