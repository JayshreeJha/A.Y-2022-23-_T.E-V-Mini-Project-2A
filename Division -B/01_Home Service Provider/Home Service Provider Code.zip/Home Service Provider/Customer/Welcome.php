<?php
session_start();

if (!isset($_SESSION["Username"]) || $_SESSION["Username"]!==true){
    header("location:Login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Welcome <?php echo $_SESSION["Username"];?></title>
        
    </head>
</html>