<!DOCTYPE html>

<html>

<head>
    <title>HOME SERVICE PROVIDER</title>
    <link rel="stylesheet" href="Cart.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://code.iconify.design/iconify-icon/1.0.0-beta.3/iconify-icon.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script&family=Mouse+Memoirs&family=Oleo+Script+Swash+Caps&display=swap" rel="stylesheet">

<body>
    <!--MAIN PAGE BANNER-->
    <section>
        <div class="banner">
            <div class="navbar">
                <img src="images/Loggo.PNG" class="logo">
                <ul>
                    <li><a href="MainP.html" class="active">HOME <iconify-icon icon="clarity:home-solid"></iconify-icon>
                        </a></li>
                    <li><a href="AboutUs.html">ABOUT US <iconify-icon icon="bxs:help-circle"></iconify-icon></a></li>
                    <li><a href="Services.html">SERVICES <iconify-icon icon="fa-solid:hands-helping"></iconify-icon></a>
                    </li>
                    <li><a href="#">CART <iconify-icon icon="ant-design:shopping-cart-outlined" width="18">
                            </iconify-icon></a>
                    <li><a href="#">
                            <iconify-icon icon="ic:outline-account-circle" width="27" iconify-icon>
                        </a>
                        <ul class="reg">
                            <li><a href="#">History</a></li>
                            <li><a href="../Normal View/MainP.html">Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </section>
    <!--CART ITEMS-->
    <section id="cart-container" class="container">
        <table width="100%">
            <thead>
                <td>Sr. No</td>
                <td>Item</td>
                <td>Amount</td>
                <td>Remove </td>
            </thead>

            <tbody>
                <?php
                include 'connection copy 2.php';
                $query = "SELECT * FROM cart ORDER BY srno ASC";
                $result = mysqli_query($conn, $query);
                if (!empty($_SESSION["cart"])) {
                    $total = 0;
                    foreach ($_SESSION["cart"] as $keys => $values) {
                ?>
                        <tr>
                            <td><?php echo $values["srno"]; ?></td>
                            <td><?php echo $values["item"]; ?></td>
                            <td>$ <?php echo $values["amount"]; ?></td>
                            <td>$ <?php echo number_format($values["total"] * $values["total"], 2); ?></td>
                            <td><a href="index.php?action=delete&id=<?php echo $values["srno"]; ?>"><span class="text-danger">Remove</span></a></td>
                        </tr>
                    <?php
                        $total = $total + ($values["total"] * $values["total"]);
                    }
                    ?>
                    <tr>
                        <td colspan="3" align="right">Total</td>
                        <td align="right">$ <?php echo number_format($total, 2); ?></td>
                        <td></td>
                    </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </section>

</body>

</html>