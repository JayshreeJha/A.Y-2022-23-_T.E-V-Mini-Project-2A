<?php
	$server_name = "localhost";
	$username = "root";
	$password = "";
	$database_name = "homeservice";

	$conn=mysqli_connect($server_name,$username,$password,$database_name);
	
    // if($conn)
    // {
    //     echo "Connection OK";
    // }
    // else{
    //     echo "Connection failed";
    // }
?>