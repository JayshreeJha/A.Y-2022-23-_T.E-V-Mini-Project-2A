<!DOCTYPE html>
<html>

<head>
    <title>Full Home Cleaning Service</title>
    <link rel="stylesheet" href="FullClean.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <script src="https://code.iconify.design/iconify-icon/1.0.0-beta.3/iconify-icon.min.js"></script>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script&family=Mouse+Memoirs&family=Oleo+Script+Swash+Caps&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/d5b937b0f9.js" crossorigin="anonymous"></script>

<body>
    <!--MAIN PAGE BANNER-->
    <section>
        <div class="banner">
            <div class="navbar">
                <img src="../images/Loggo.PNG" class="logo">
                <ul>
                    <li><a href="http://127.0.0.1:5500/Customer/MainP.html">HOME <iconify-icon icon="clarity:home-solid"></iconify-icon> </a></li>
                    <li><a href="http://127.0.0.1:5500/Customer/AboutUs.html">ABOUT US <iconify-icon icon="bxs:help-circle"></iconify-icon></a></li>
                    <li><a href="http://127.0.0.1:5500/Customer/Services.html" class="active">SERVICES <iconify-icon icon="fa-solid:hands-helping"></iconify-icon></a></li>
                    <li><a href="http://localhost:3000/Customer/Carts.php">CART <iconify-icon icon="ant-design:shopping-cart-outlined" width="18">
                            </iconify-icon></a>
                    <li><a href="#">
                            <iconify-icon icon="ic:outline-account-circle" width="27" iconify-icon>
                        </a>
                        <ul class="reg">
                            <li><a href="http://localhost:3000/Customer/history.php">History</a></li>
                            <li><a href="../Normal View/MainP.html">Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
            <div class="content">
                <h1>FULL HOUSE CLEAN SERVICE</h1>
                <h2>We will clean your house from A to Z</h2>
            </div>
        </div>
    </section>
    <section id="feature">
        <div class="title">
            <p>Classic </p>
            <div class="container mt-3">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal">
                    Details
                </button>
            </div>
            <!-- The Modal -->
            <div class="modal" id="myModal">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Details</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col"></th>
                                        <th scope="col">Classic</th>
                                        <th scope="col">Premium</th>
                                        <th scope="col">Platinum</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <th scope="row">Bathroom & Balcony</th>
                                        <td>Deep Cleaning</td>
                                        <td>Deep Cleaning</td>
                                        <td>Deep Cleaning</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Kitchen</th>
                                        <td>Floor, tiles, stove, cabinet exterior</td>
                                        <td>Classic + cabinet interiors + chimney</td>
                                        <td>Premium + microwave + fridge</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Floor</th>
                                        <td>Wipping + mopping</td>
                                        <td>Wipping + mopping</td>
                                        <td>Wipping + mopping</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Curtains & mattresses</th>
                                        <td>No</td>
                                        <td>Dry Vacuuming</td>
                                        <td>Dry Vacuuming</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Carpet, sofa & chairs</th>
                                        <td>Dry Vacuuming</td>
                                        <td>Dry Vacuuming</td>
                                        <td>Dry + wet Vacuuming</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Walls & ceiling</th>
                                        <td>Dry dusting</td>
                                        <td>Dry dusting</td>
                                        <td>Dry dusting</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Windows & electical fittings</th>
                                        <td>Wet wiping</td>
                                        <td>Wet wiping</td>
                                        <td>Wet wiping</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Wooden furniture</th>
                                        <td>Dry dusting</td>
                                        <td>Dry dusting</td>
                                        <td>Dry dusting + shining</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
        </div>
    </section>
    <section>
        <div class="wrapper">
            <div class="single-price">
                <h1>1 BHK Flat</h1>
                <div class="price">
                    <h2>&#8377 2999</h2>
                </div>
                <div class="deals">
                    <h4></h4>
                </div>
                <a href="?list1" onclick='alert("Added to cart")'>Select</a>
            </div>
            <div class="single-price">
                <h1>2 BHK Flat</h1>
                <div class="price">
                    <h2>&#8377 3499</h2>
                </div>
                <div class="deals">
                    <h4></h4>
                </div>
                <a href="?list2" onclick='alert("Added to cart")'>Select</a>
            </div>
            <div class="single-price">
                <h1>3 BHK Flat</h1>
                <div class="price">
                    <h2>&#8377 4499</h2>
                </div>
                <div class="deals">
                    <h4></h4>
                </div>
                <a href="?list3" onclick='alert("Added to cart")'>Select</a>
            </div>
            <div class="single-price">
                <h1>4 BHK</h1>
                <div class="price">
                    <h2>&#8377 5149</h2>
                </div>
                <div class="deals">
                    <h4></h4>
                </div>
                <a href="?list4" onclick='alert("Added to cart")'>Select</a>
            </div>
            <div class="single-price">
                <h1>5 BHK</h1>
                <div class="price">
                    <h2>&#8377 5899</h2>
                </div>
                <div class="deals">
                    <h4></h4>
                </div>
                <a href="?list5" onclick='alert("Added to cart")'>Select</a>
            </div>
            <div class="single-price">
                <h1>Studio Apartment</h1>
                <div class="price">
                    <h2>&#8377 1999</h2>
                </div>
                <div class="deals">
                    <h4></h4>
                </div>
                <a href="?list6" onclick='alert("Added to cart")'>Select</a>
            </div>
        </div>
    </section>
    <section id="feature1">
        <div class="title1">
            <p>Premium</p>
        </div>
    </section>
    <section>
        <div class="wrapper">
            <div class="single-price">
                <h1>1 BHK Flat</h1>
                <div class="price">
                    <h2>&#8377 4999</h2>
                </div>
                <div class="deals">
                    <h4></h4>
                </div>
                <a href="#">Select</a>
            </div>
            <div class="single-price">
                <h1>2 BHK Flat</h1>
                <div class="price">
                    <h2>&#8377 5299</h2>
                </div>
                <div class="deals">
                    <h4></h4>
                </div>
                <a href="#">Select</a>
            </div>
            <div class="single-price">
                <h1>3 BHK Flat</h1>
                <div class="price">
                    <h2>&#8377 5799</h2>
                </div>
                <div class="deals">
                    <h4></h4>
                </div>
                <a href="#">Select</a>
            </div>
            <div class="single-price">
                <h1>4 BHK</h1>
                <div class="price">
                    <h2>&#8377 7549</h2>
                </div>
                <div class="deals">
                    <h4></h4>
                </div>
                <a href="#">Select</a>
            </div>
            <div class="single-price">
                <h1>5 BHK</h1>
                <div class="price">
                    <h2>&#8377 8299</h2>
                </div>
                <div class="deals">
                    <h4></h4>
                </div>
                <a href="#">Select</a>
            </div>
            <div class="single-price">
                <h1>Studio Apartment</h1>
                <div class="price">
                    <h2>&#8377 2999</h2>
                </div>
                <div class="deals">
                    <h4></h4>
                </div>
                <a href="#">Select</a>
            </div>
        </div>
    </section>
    <section id="feature2">
        <div class="title2">
            <p>Platinum</p>
        </div>
    </section>
    <section>
        <div class="wrapper">
            <div class="single-price">
                <h1>1 BHK Flat</h1>
                <div class="price">
                    <h2>&#8377 5999</h2>
                </div>
                <div class="deals">
                    <h4></h4>
                </div>
                <a href="#">Select</a>
            </div>
            <div class="single-price">
                <h1>2 BHK Flat</h1>
                <div class="price">
                    <h2>&#8377 6199</h2>
                </div>
                <div class="deals">
                    <h4></h4>
                </div>
                <a href="#">Select</a>
            </div>
            <div class="single-price">
                <h1>3 BHK Flat</h1>
                <div class="price">
                    <h2>&#8377 7199</h2>
                </div>
                <div class="deals">
                    <h4></h4>
                </div>
                <a href="#">Select</a>
            </div>
            <div class="single-price">
                <h1>4 BHK</h1>
                <div class="price">
                    <h2>&#8377 8549</h2>
                </div>
                <div class="deals">
                    <h4></h4>
                </div>
                <a href="#">Select</a>
            </div>
            <div class="single-price">
                <h1>5 BHK</h1>
                <div class="price">
                    <h2>&#8377 9599</h2>
                </div>
                <div class="deals">
                    <h4></h4>
                </div>
                <a href="#">Select</a>
            </div>
            <div class="single-price">
                <h1>Studio Apartment</h1>
                <div class="price">
                    <h2>&#8377 3599</h2>
                </div>
                <div class="deals">
                    <h4></h4>
                </div>
                <a href="#">Select</a>
            </div>
        </div>
    </section>
    <!--FOOTER-->
    <section id="footer">
        <img src="images/foot.webp" class="foot-img">
        <div class="title-text">
            <p>CONTACT</p>
            <h1>OUR CONTACT INFO</h1>
        </div>
        <div class="foot-row">
            <div class="foot-left">
                <h1>Service Hours</h1>
                <p><i class="fa fa-clock-o"></i> Monday to Saturday - 8am to 10pm</p>
                <p><i class="fa fa-clock-o"></i> Sunday - 7am to 11pm</p>
            </div>
            <div class="foot-right">
                <h1>Get in Touch</h1>
                <p>Universal Building, xyz road <i class="fa fa-map-marker"></i></p>
                <p>+91 123456789 <i class="fa fa-phone"></i></p>
                <p>@gmail.com <i class="fa fa-envelope"></i></p>
            </div>
        </div>
        <div class="social-link">
            <i class="fa fa-facebook"></i>
            <i class="fa fa-instagram"></i>
            <i class="fa fa-twitter"></i>
            <i class="fa fa-youtube-play"></i>
            <p>Copyright &copy; 2022</p>
        </div>
    </section>
</body>

</html>


<?php
if (isset($_GET['list1'])) {
    include 'connection copy 2.php';
    $sql = "INSERT INTO cart (srno, Item, total, amount) VALUES ('1','1 BHK Full Cleaing', '2999', '2999')";
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    mysqli_close($conn);
}
if (isset($_GET['list2'])) {
    include 'connection copy 2.php';
    $sql = "INSERT INTO cart (srno, Item, total, amount) VALUES ('','2 BHK Full Cleaing', '3499', '3499')";
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    mysqli_close($conn);
}
if (isset($_GET['list3'])) {
    include 'connection copy 2.php';
    $sql = "INSERT INTO cart (srno, Item, total, amount) VALUES ('','3 BHK Full Cleaing', '4499', '4499')";
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    mysqli_close($conn);
}
if (isset($_GET['list4'])) {
    include 'connection copy 2.php';
    $sql = "INSERT INTO cart (srno, Item, total, amount) VALUES ('','4 BHK Full Cleaing', '5149', '5149')";
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    mysqli_close($conn);
}
if (isset($_GET['list5'])) {
    include 'connection copy 2.php';
    $sql = "INSERT INTO cart (srno, Item, total, amount) VALUES ('','5 BHK Full Cleaing', '5899', '5899')";
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    mysqli_close($conn);
}
if (isset($_GET['list6'])) {
    include 'connection copy 2.php';
    $sql = "INSERT INTO cart (srno, Item, total, amount) VALUES ('1','Studio Apartment Full Cleaing', '1999', '1999')";
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    mysqli_close($conn);
}
?>