<?php
include 'connection.php';
$sql = mysqli_query($conn, "DELETE FROM cart WHERE srno='$srno");
$sql = "INSERT INTO cart (srno, Item, total, amount) VALUES ('1','1 BHK Full Cleaing', '2999', '2999')";
if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
    mysqli_close($conn);
?>