<!DOCTYPE html>
<html>
    <head>
        <title>Feedback</title>
        <link rel="stylesheet" href="fee.css">
        <script src="https://kit.fontawesome.com/d5b937b0f9.js" crossorigin="anonymous"></script>
    </head>
    <body>
        <div class="container">
            <form action="feeinfo.php" method="post">
                <h1>Give your Feedback</h1>
                <div class="id">
                    <input type="text" placeholder="Name" name="name">
                    <i class="fa-solid fa-user"></i>
                </div>
                <div class="id">
                    <input type="email" placeholder="Email" name="email">
                    <i class="fa-solid fa-envelope"></i>
                </div>
                <textarea name="Feedback" id="Feedback" cols="15" rows="5" placeholder="Enter your feedback" name="feed"></textarea>
                <button name="save">Submit</button>
            </form>

        </div>
    </body>
</html>