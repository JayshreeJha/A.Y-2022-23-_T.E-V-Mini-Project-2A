<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Star rating</title>
	<script src="https://kit.fontawesome.com/d5b937b0f9.js" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="style.css">
</head>

<body>
	<div class="container">
		<h2>Feedback</h2>
		<div class="skills">
			<h3 class="name">Arriving of worker</h3>
			<div class="rating">
				<input type="radio" name="time" id="time">
				<input type="radio" name="time" id="time">
				<input type="radio" name="time" id="time">
				<input type="radio" name="time" id="time">
				<input type="radio" name="time" id="time">
				<input type="radio" name="time" id="time">
				<input type="radio" name="time" id="time">
				<input type="radio" name="time" id="time">
				<input type="radio" name="time" id="time">
				<input type="radio" name="time" id="time">
			</div>
		</div>
		<div class="skills">
			<h3 class="name">Service Satisfaction</h3>
			<div class="rating">
				<input type="radio" name="sats" id="sats">
				<input type="radio" name="sats" id="sats">
				<input type="radio" name="sats" id="sats">
				<input type="radio" name="sats" id="sats">
				<input type="radio" name="sats" id="sats">
				<input type="radio" name="sats" id="sats">
				<input type="radio" name="sats" id="sats">
				<input type="radio" name="sats" id="sats">
				<input type="radio" name="sats" id="sats">
				<input type="radio" name="sats" id="sats">
			</div>
		</div>
		<div class="skills">
			<h3 class="name">Behavior of Worker</h3>
			<div class="rating">
				<input type="radio" name="bhe" id="bhe">
				<input type="radio" name="bhe" id="bhe">
				<input type="radio" name="bhe" id="bhe">
				<input type="radio" name="bhe" id="bhe">
				<input type="radio" name="bhe" id="bhe">
				<input type="radio" name="bhe" id="bhe">
				<input type="radio" name="bhe" id="bhe">
				<input type="radio" name="bhe" id="bhe">
				<input type="radio" name="bhe" id="bhe">
				<input type="radio" name="bhe" id="bhe">
			</div>
		</div>
		<div class="skills">
			<h3 class="name">Assisting the Questions</h3>
			<div class="rating">
				<input type="radio" name="que" id="que">
				<input type="radio" name="que" id="que">
				<input type="radio" name="que" id="que">
				<input type="radio" name="que" id="que">
				<input type="radio" name="que" id="que">
				<input type="radio" name="que" id="que">
				<input type="radio" name="que" id="que">
				<input type="radio" name="que" id="que">
				<input type="radio" name="que" id="que">
				<input type="radio" name="que" id="que">
			</div>
		</div>
		<div class="skills">
			<h3 class="name">Overall Experience</h3>
			<div class="rating">
				<input type="radio" name="exp" id="exp">
				<input type="radio" name="exp" id="exp">
				<input type="radio" name="exp" id="exp">
				<input type="radio" name="exp" id="exp">
				<input type="radio" name="exp" id="exp">
				<input type="radio" name="exp" id="exp">
				<input type="radio" name="exp" id="exp">
				<input type="radio" name="exp" id="exp">
				<input type="radio" name="exp" id="exp">
				<input type="radio" name="exp" id="exp">
			</div>
		</div>
	</div>
	</container>
</body>

</html>