<!DOCTYPE html>
<html lang="en">

<head>
    <script src="https://kit.fontawesome.com/d5b937b0f9.js" crossorigin="anonymous"></script>
    <title>Login </title>
    <link rel="stylesheet" href="Login.css">
    <script>$.post( "LogInfo.php", { htmlCode : htmlCode }); </script>
</head>

<body>
    <form action="LogInfo.php" method="post">
        <div class="container">
            <h1>Login to Astre</h1>
            <div class="box">
                <i class="fa-solid fa-envelope"></i>
                <input type="text" name="Username" id="email" placeholder="Enter Your Username" required>

            </div>
            <div class="box">
                <i class="fa-solid fa-lock"></i>
                <input type="password" name="Password" id="password" placeholder="Enter your password" required>

            </div>
            <input type="submit" name="save" value="Login" class="btn">
            <a href="MainP.html"><input type="button" class="btn" value="Back" style="margin-top: 10px;"></a>
        </div>
    </form>
</body>

</html>