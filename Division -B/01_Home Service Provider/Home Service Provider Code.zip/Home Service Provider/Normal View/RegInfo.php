<?php
	@include 'connection.php';

	if(isset($_POST['save']))
	{	
		$Name = $_POST['Name'];
		$Username = $_POST['Username'];
		$Email = $_POST['Email'];
		$PhoneNo = $_POST['PhoneNo'];
		$Password = $_POST['Password'];
		$ConfPassword = $_POST['ConfPassword'];
		$Address = $_POST['Address'];
		$Gender = $_POST['Gender'];

		$sql_query = "INSERT INTO register (Name, Username, Email, PhoneNo, Password, ConfPassword, Address, Gender)
		VALUES ('$Name','$Username','$Email','$PhoneNo','$Password','$ConfPassword','$Address','$Gender');
		INSERT INTO login (Username, Password) VALUES ('$Username','$Password')";

		if (mysqli_multi_query($conn, $sql_query)) 
		{
			echo "New Details Entry inserted successfully !";
			header("Location: http://localhost:3000/Normal%20View/Login.php");
		} 
		else
		{
			echo "Error: " . $sql . "" . mysqli_error($conn);
		}
		mysqli_close($conn);
	}
	 
?>