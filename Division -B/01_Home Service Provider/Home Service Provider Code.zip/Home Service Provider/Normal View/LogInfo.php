<?php
	@include 'connection.php';
    @include '.htaccess';
    
    $Username = $_POST['Username'];  
    $Password = $_POST['Password'];  
      
        //to prevent from mysqli injection  
        $Username = stripcslashes($Username);  
        $Password = stripcslashes($Password);  
        $Username = mysqli_real_escape_string($conn, $Username);  
        $Password = mysqli_real_escape_string($conn, $Password);  
      
        $sql = "select *from login where Username = '$Username' and Password = '$Password'";  
        $result = mysqli_query($conn, $sql);  
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
        $count = mysqli_num_rows($result);  
          
        if($count == 1){  
            // echo "<h1><center> Login successful </center></h1>"; 
            header("location:http://127.0.0.1:5500/Customer/MainP.html"); 
        }  
        else{  
            echo "<h1> Login failed. Invalid username or password.</h1>";  
        }     
	 
?>