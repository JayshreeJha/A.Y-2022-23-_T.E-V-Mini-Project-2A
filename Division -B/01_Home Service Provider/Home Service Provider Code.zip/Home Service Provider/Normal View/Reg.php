<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="Reg.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
</head>

<body>
    <div class="container">
        <div class="title">Registration</div>
        <div class="content">
            <form action="RegInfo.php" method="POST">
                <div class="user-details">
                    <div class="input-box">
                        <span class="details">Full Name</span>
                        <input type="text" name="Name" placeholder="Enter your name" required>
                    </div>
                    <div class="input-box">
                        <span class="details">Username</span>
                        <input type="text" name="Username" placeholder="Enter your username" required>
                    </div>
                    <div class="input-box">
                        <span class="details">Email</span>
                        <input type="email" name="Email" placeholder="Enter your email" required>
                    </div>
                    <div class="input-box">
                        <span class="details">Phone Number</span>
                        <input type="tel" pattern="[7-9]{1}[0-9]{9}" name="PhoneNo" placeholder="Enter your number" required>
                    </div>
                    <div class="input-box">
                        <span class="details">Password</span>
                        <input type="password" name="Password" placeholder="Enter your password" required>
                    </div>
                    <div class="input-box">
                        <span class="details">Confirm Password</span>
                        <input type="password" name="ConfPassword" placeholder="Confirm your password" required>
                    </div>
                    <div class="input-box">
                        <span class="add">Address</span>
                        <input type="text" name="Address" placeholder="Enter your Address" style="width: 640px;" required>
                    </div>
                </div>
                <div class="gender-details">
                    <input type="radio" name="Gender" value="m" id="dot-1">
                    <input type="radio" name="Gender" value="f" id="dot-2">
                    <input type="radio" name="Gender" value="p" id="dot-3">
                    <span class="gender-title">Gender</span>
                    <div class="category">
                        <label for="dot-1">
                            <span class="dot one"></span>
                            <span class="gender">Male</span>
                        </label>
                        <label for="dot-2">
                            <span class="dot two"></span>
                            <span class="gender">Female</span>
                        </label>
                        <label for="dot-3">
                            <span class="dot three"></span>
                            <span class="gender">Prefer not to say</span>
                        </label>
                    </div>
                </div>
                <div class="button">
                    <a href="http://localhost:3000/Normal%20View/Login.php"><input type="submit" name="save" value="Register"></a>
                    <a href="http://127.0.0.1:5500/Customer/MainP.html"><input type="button" value="Back" style="margin-top: 10px;"></a>
                </div>
            </form>
        </div>
    </div>
</body>

</html>