CREATE TABLE [dbo].[Register]
(
  [Name] TEXT NOT NULL ,
  [Username] VARCHAR(50) , 
  [Email] VARCHAR(100) NOT NULL , 
  [PhoneNo] INT(12) NOT NULL , 
  [Password] VARCHAR(50) NOT NULL , 
  [ConfPassword] VARCHAR(50) NOT NULL , 
  [Address] VARCHAR(200) NOT NULL , 
  [Gender] CHAR NOT NULL 
)
