<?php
	$server_name = "localhost";
	$username = "root";
	$password = "";
	$database_name = "homeservice";

	$conn=mysqli_connect($server_name,$username,$password,$database_name);
?>