<!Doctype HTML>
<html>

<head>
    <title></title>
    <!-- <link rel="stylesheet" href="AdminD.html" type="text/css"/> -->
    <link rel="stylesheet" href="cust.css">
    <script src="https://code.iconify.design/iconify-icon/1.0.0/iconify-icon.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://kit.fontawesome.com/d5b937b0f9.js" crossorigin="anonymous"></script>
</head>

<title>Admin Dashboard</title>

<body>

    <div id="mySidenav" class="sidenav">
        <p class="logo"><span>A</span>stre</p>
        <a href="http://127.0.0.1:5500/Admin/AdminD.html" class="icon-a" i class="fa fa-dashboard icons"></i> &nbsp;&nbsp;Dashboard</a>
        <a href="http://localhost:3000/Admin/cust.php" class="icon-a"><i class="fa fa-users icons"></i> &nbsp;&nbsp;Customers</a>
        <a href="http://localhost:3000/Admin/worker.php#" class="icon-a"><i class="fa-solid fa-circle-user"></i>&nbsp;&nbsp;Workers</a>
        <a href="http://localhost:3000/Admin/worker.php#" class="icon-a">
            <iconify-icon icon="carbon:document"></iconify-icon>&nbsp;&nbsp;Worker Resume
        </a>
        <a href="http://localhost:3000/Admin/worker.php#" class="icon-a" id="active">
            <iconify-icon icon="codicon:feedback"></iconify-icon>&nbsp;&nbsp;Feedback
        </a>
        <a href="http://127.0.0.1:5500/Admin/To-Do-List%20Of%20Admin.html" class="icon-a"><i class="fa fa-list-alt icons"></i> &nbsp;&nbsp;Tasks</a>

    </div>

    <div class="bs-example">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header clearfix">
                        <h2 class="pull-left">Cart</h2>
                    </div>
                    <?php
                    include 'connect.php';
                    $result = mysqli_query($conn, "SELECT * FROM feedback");
                    ?>
                    <?php
                    if (mysqli_num_rows($result) > 0) {
                    ?>
                        <table style="margin-left: 250px;" class='table table-bordered table-striped'>
                            <tr>
                                <td>Name</td>
                                <td>Email</td>
                                <td>Feedback</td>
                            </tr>
                            <?php
                            $i = 0;
                            while ($row = mysqli_fetch_array($result)) {
                            ?>
                                <tr>
                                    <td><?php echo $row["name"]; ?></td>
                                    <td><?php echo $row["email"]; ?></td>
                                    <td><?php echo $row["feed"]; ?></td>
                                    <!-- <td>
                                        <form action="del.php" method="post"><input type="button" onclick='alert("deleted from cart")' class="btnnn" value="delete" style="margin-top: 10px;"></form>
                                    </td> -->
                                </tr>
                            <?php
                                $i++;
                            }
                            ?>
                        </table>
                    <?php
                    } else {
                        echo "No service have been added";
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
    <div>
        <a href="Payment.html"><button class="btn">Pay</button></a>
    </div>

</body>


</html>