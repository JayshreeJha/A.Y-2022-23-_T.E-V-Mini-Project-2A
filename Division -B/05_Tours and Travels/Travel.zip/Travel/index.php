<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Welcome to ClearTripClone</title>
    <link rel="shortcut icon" type="image/x-icon" href="assets/images/inner/favicon.png" />
    <link rel="stylesheet" type="text/css" href="calenplugin/css/daterangepicker.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css" />
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="assets/css/animate.css" />
    <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">
</head>
<body>
    <!--start Header-->
    <header id="header">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light">
                <a href="index.html" class="navbar-brand font-weight-bold wow fadeInDown">
                    <h2>
                    Travel Agents
                     <!--<img src="" class="img-logo img-fluid" alt="logo"/>-->
                  </h2>
                </a>
                <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#collapsenavbar">
                    <i class="fa fa-align-justify"></i>
                </button>
                <div class="collapse navbar-collapse text-center" id="collapsenavbar">
                    <ul class="navbar-nav ml-auto ">
                        <li class="nav-item dropdown nav-left">
                            <div class="wow fadeInDown" data-wow-delay="70ms">
                                <a href="index.html" class="nav-link dropdown-toggle scroll active" data-toggle="dropdown">
                                    Currency <span class="inr">INR</span><img src="assets/images/inner/rupees.png" class="curr-img" alt="currency">
                                  </a >
                                  <div class="dropdown-menu">
                                  <a class="dropdown-item" href=""><span class="inr">Australian Dollar</span><img src="assets/images/inner/dollar.png" class="curr1-img" alt="currency"></a>
                                <a class="dropdown-item" href=""><span class="inr">Canadian Dollar</span><img src="assets/images/inner/dollar.png" class="curr1-img" alt="currency"></a>
                                <a class="dropdown-item" href=""><span class="inr">Hong Kong Dollar</span><img src="assets/images/inner/dollar.png" class="curr1-img" alt="currency"></a>
                                <a class="dropdown-item" href=""><span class="inr">Euro</span><img src="assets/images/inner/euro.png" class="curr1-img" alt="currency"></a>
                                <a class="dropdown-item" href=""><span class="inr">Malaysian Ringgit M</span><img src="assets/images/inner/dollar.png" class="curr1-img" alt="currency"></a>
                                <a class="dropdown-item" href=""><span class="inr">Pakistan Rs</span></a>
                                <a class="dropdown-item" href=""><span class="inr">US Dollar</span><img src="assets/images/inner/dollar.png" class="curr1-img" alt="currency"></a>
                            </div>
                    </div>
                </li>
                <li class="nav-item dropdown nav-left">
                    <div class="wow fadeInDown nav-img" data-wow-delay="70ms">
                        <a href="index.html" class="nav-link dropdown-toggle scroll active" data-toggle="dropdown">
                            <img src="assets/images/inner/flag.png" alt="currency">
                        </a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="">UAE</a>
                            <a class="dropdown-item" href="">OMAN</a>
                            <a class="dropdown-item" href="">QATAR</a>
                            <a class="dropdown-item" href="">Bahrain</a>
                            <a class="dropdown-item" href="">Kuwait</a>
                            <a class="dropdown-item" href="">Saudi Arabia</a>
                            <a class="dropdown-item" href="">Middle East</a>
                        </div>
                    </div>
                </li>
                <li class="nav-item dropdown nav-left">
                    <div class="wow fadeInDown nav-img trip" data-wow-delay="70ms">
                        <a href="index.html" class="nav-link dropdown-toggle scroll active" data-toggle="dropdown">
                            <img src="assets/images/inner/user.png" alt="currency">Your Trips
                        </a>
                        <div class="dropdown-menu">
                            <a href="login.php" class="btn-register">Sign In</a>
                            <br>
                            <!-- <a href="" class="btn-register" data-toggle="modal" data-target="#myModal">Now Here ? Register</a> -->
                            <a class="dropdown-item" href="cancellation.html">Cancellations</a>
                            <a class="dropdown-item" href="change-flight.html">Change Flights</a>
                            <a class="dropdown-item" href="">Check PNR Status</a>
                            <a class="dropdown-item" href="">Print ticket</a>
                            <a class="dropdown-item" href="">Print hotel Voucher</a>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
        </nav>
        </div>
        <div class="clearfix"></div>
    </header>
    <!--end header-->
    <section id="section-one">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-xl-3 col-md-4 col-12 mb-3 ">
                    <ul class="nav nav-pills flex-column" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="flight-tab" data-toggle="tab" href="#flight" role="tab" aria-controls="flight" aria-selected="true">
                                <i class="fa fa-plane" aria-hidden="true"></i>Flights
                                <i class="fa fa-angle-right float-right" aria-hidden="true"></i>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="hotel-tab" data-toggle="tab" href="#hotel" role="tab" aria-controls="hotel" aria-selected="false"><i class="fa fa-bed" aria-hidden="true"></i>Hotels<i class="fa fa-angle-right float-right" aria-hidden="true"></i></a>
                        </li>                       
                        <li class="nav-item">
                            <a class="nav-link" id="train-tab" data-toggle="tab" href="#train" role="tab" aria-controls="train" aria-selected="false"><i class="fa fa-train" aria-hidden="true"></i>Trains<i class="fa fa-angle-right float-right" aria-hidden="true"></i></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="activities.html" role="tab" aria-selected="false"><i class="fa fa-motorcycle" aria-hidden="true"></i>Activities<i class="fa fa-angle-right float-right" aria-hidden="true"></i></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="flight-deals.html" role="tab" aria-selected="false"><i class="fa fa-fighter-jet" aria-hidden="true"></i>Flight Deals<i class="fa fa-angle-right float-right" aria-hidden="true"></i></a>
                        </li>
                    </ul>
                </div>
                <!-- /.col-md-4 -->
                <div class="col-lg-6 col-xl-6 col-md-8 col-12 flight-search">
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="flight" role="tabpanel" aria-labelledby="flight-tab">
                            <h3>Search Flights</h3>
                            <p>Fly anywhere. Fly everywhere.</p>
                            <h6 class="flashDiv"><strong>Flash Sale:</strong> Grab the lowest airfares starting at Rs.999. Hurry, book now.</h6>
                            <div class="row mx-auto">
                                <div class="col-12 ">
                                   <div class="wayDiv">
                                        <label><input type="radio" name="colorRadio" value="red">  One Way</label>
                                        <label><input type="radio" name="colorRadio" value="green">  Round Trip</label>
                                        <label><input type="radio" name="colorRadio" value="blue">  Multi-city</label>
                                           </div>
                                           <div class="red box" id ="redbox1"> 
                                               <form id="myForm">
                                                <div class="row">
                                                    <div class="col-md-12 col-lg-6 col-xl-6 col-12">
                                                        <div class="form-group">
                                                            <label>From *</label>
                                                            <select id="country" name="country" class="custom-select form-control">
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 col-lg-6 col-xl-6 col-12">
                                                        <div class="form-group">
                                                            <label>To*</label>
                                                            <select id="country1" name ="country1" class="custom-select form-control">
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 col-lg-12 col-xl-12 col-12">
                                                        <div class="row">
                                                            <div class="col-md-12 col-lg-6 col-xl-6 col-12">
                                                                <div class="form-group">
                                                                    <label>Depart on*</label>
                                                                    <div class="input-group margin-bottom-sm">
                                                                        <input type="text" value="" id="picker" name="picker" class="form-control" required>
                                                                        <div class="input-group-append">
                                                                            <span class="input-group-text"><i class="fa fa-calendar fa-fw"></i></span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 col-lg-3 col-xl-3 col-12">
                                                        <div class="form-group">
                                                            <label>Adult*</label>
                                                            <select id="adultDiv" name="adultDiv" class="custom-select form-control">
                                                                <option value="">12+yr</option>
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                                <option value="5">5</option>
                                                                <option value="6">6</option>
                                                                <option value="7">7</option>
                                                                <option value="8">8</option>
                                                                <option value="9">9</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 col-lg-3 col-xl-3 col-12">
                                                        <div class="form-group">
                                                            <label>Children*</label>
                                                            <select id="childDiv" name="childDiv" class="custom-select form-control">
                                                                <option value="">0+11yr</option>
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="1">4</option>
                                                                <option value="2">5</option>
                                                                <option value="3">6</option>
                                                                <option value="1">7</option>
                                                                <option value="2">8</option>
                                                                <option value="3">9</option>
                                                                <option value="2">10</option>
                                                                <option value="3">11</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 col-lg-3 col-xl-3 col-12">
                                                        <div class="form-group">
                                                            <label>Infants*</label>
                                                            <select id="infantDiv" name="infantDiv" class="custom-select form-control">
                                                                <option value="" >Select</option>
                                                                <option value="1">0</option>
                                                                <option value="2">1</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-12 toggleDiv">
                                                    <i class="fa fa-play" aria-hidden="true"></i>
                                                    <b>More options:</b> Class of travel, Airline preference 
                                                </div>
                                                <div class="row hiddenDiv" style="display: none;">
                                                    <div class="col-md-12 col-lg-6 col-xl-6 col-12">
                                                        <div class="form-group">
                                                            <label>Class of Travel</label>
                                                            <select id="economyDiv" name="economyDiv" class="custom-select form-control">
                                                                <option value="">Select</option>
                                                                <option value="1">Economy</option>
                                                                <option value="2">Business</option>
                                                                <option value="3">First</option>
                                                                <option value="4">Premium Economy</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 col-lg-6 col-xl-6 col-12">
                                                        <div class="form-group">
                                                            <label>Preferred Airline</label>
                                                            <input type="text" class="form-control" placeholder="Airline Name" name="fname" id="fname" />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="buttonDiv float-right">
                                                     <input type="submit" name="submit" class="submitButton" value="Search Flights">
                                                </div>
                                            </form>
                                        </div>
                                        <div class="green box" style="display: none;">
                                              <form id="secondForm">
                                                <div class="row">
                                                    <div class="col-md-12 col-lg-6 col-xl-6 col-12">
                                                        <div class="form-group">
                                                            <label>From *</label>
                                                            <select id="country2" name ="country2" class="custom-select form-control">
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 col-lg-6 col-xl-6 col-12">
                                                        <div class="form-group">
                                                            <label>To*</label>
                                                            <select id="country3" name ="country3" class="custom-select form-control">
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 col-lg-12 col-xl-12 col-12">
                                                        <div class="row">
                                                            <div class="col-md-12 col-lg-6 col-xl-6 col-12">
                                                                <div class="form-group">
                                                                    <label>Depart on*</label>
                                                                    <div class="input-group margin-bottom-sm">
                                                                        <input type="text" value="10/24/1984" id="picker1" name="picker" class="form-control" required>
                                                                        <div class="input-group-append">
                                                                            <span class="input-group-text"><i class="fa fa-calendar fa-fw"></i></span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-12 col-lg-6 col-xl-6 col-12">
                                                                <div class="form-group">
                                                                    <label>Return on*</label>
                                                                    <div class="input-group margin-bottom-sm">
                                                                        <input type="text" value="10/24/1984" id="picker2" name="picker" class="form-control" required>
                                                                        <div class="input-group-append">
                                                                            <span class="input-group-text"><i class="fa fa-calendar fa-fw"></i></span>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 col-lg-3 col-xl-3 col-12">
                                                        <div class="form-group">
                                                            <label>Adult*</label>
                                                            <select id="adultOneDiv" name="adultOneDiv" class="custom-select form-control">
                                                                <option value="">12+yr</option>
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                                <option value="5">5</option>
                                                                <option value="6">6</option>
                                                                <option value="7">7</option>
                                                                <option value="8">8</option>
                                                                <option value="9">9</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 col-lg-3 col-xl-3 col-12">
                                                        <div class="form-group">
                                                            <label>Children*</label>
                                                        <select id="childOneDiv" name="childOneDiv" class="custom-select form-control">
                                                                <option value="">2-11yr</option>
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                                <option value="5">5</option>
                                                                <option value="6">6</option>
                                                                <option value="7">7</option>
                                                                <option value="8">8</option>
                                                                <option value="9">9</option>
                                                                <option value="10">10</option>
                                                                <option value="11">11</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 col-lg-3 col-xl-3 col-12">
                                                        <div class="form-group">
                                                            <label>Infants*</label>
                                                            <select id="infantOneDiv" name="infantOneDiv" class="custom-select form-control">
                                                                <option value="">Below 2yr
                                                                </option>
                                                                <option value="1">0</option>
                                                                <option value="2">1</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-12 toggleDiv">
                                                    <i class="fa fa-play" aria-hidden="true"></i><b>More options:</b> Class of travel, Airline preference
                                                </div>
                                                <div class="row hiddenDiv" style="display: none;">
                                                    <div class="col-md-12 col-lg-6 col-xl-6 col-12">
                                                        <div class="form-group">
                                                            <label>Class of Travel</label>
                                                            <select id="travelClass" name="travelClass" class="custom-select form-control">  
                                                                <option value="">Select</option>
                                                                <option value="1">Economy</option>
                                                                <option value="2">Business</option>
                                                                <option value="3">First</option>
                                                                <option value="4">Premium Economy</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 col-lg-6 col-xl-6 col-12">
                                                        <div class="form-group">
                                                            <label>Preferred Airline</label>
                                                            <input type="text" class="form-control" placeholder="Airline Name" name=airName id=airName />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="buttonDiv float-right">
                                                   <input type="submit" name="submit" value="Search Flights" class="submitButton">
                                                </div>
                                            </form>
                                            </div>
                                            <div class="blue box" style="display: none;">
                                            <form id="thirdForm">
                                                <div class="row">
                                                    <div class="col-md-12 col-lg-4 col-xl-4 col-12">
                                                        <div class="form-group">
                                                            <label>From*</label>
                                                            <select id="country4" name ="country4" class="custom-select form-control">
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 col-lg-4 col-xl-4 col-12">
                                                        <div class="form-group">
                                                            <label>To*</label>
                                                            <select id="country5" name ="country5" class="custom-select form-control">
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 col-lg-4 col-xl-4 col-12">
                                                        <div class="form-group">
                                                            <label>Depart on*</label>
                                                            <div class="input-group margin-bottom-sm">
                                                                <input type="text" value="10/24/1984" id="picker3" name="picker" class="form-control" required>
                                                                <div class="input-group-append">
                                                                    <span class="input-group-text"><i class="fa fa-calendar fa-fw"></i></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 col-lg-4 col-xl-4 col-12">
                                                        <div class="form-group">
                                                            <label>From *</label>
                                                           <select id="country6" name ="country6" class="custom-select form-control">
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 col-lg-4 col-xl-4 col-12">
                                                        <div class="form-group">
                                                            <label>To*</label>
                                                            <select id="country7" name ="country7" class="custom-select form-control">
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 col-lg-4 col-xl-4 col-12">
                                                        <div class="form-group">
                                                            <label>Depart on*</label>
                                                            <div class="input-group margin-bottom-sm">
                                                                <input type="text" value="10/24/1984" id="picker4" name="picker" class="form-control" required>
                                                                <div class="input-group-append">
                                                                    <span class="input-group-text"><i class="fa fa-calendar fa-fw"></i></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 col-lg-4 col-xl-4 col-12">
                                                        <div class="form-group">
                                                            <label>From *</label>
                                                            <select id="country8" name ="country8" class="custom-select form-control">
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 col-lg-4 col-xl-4 col-12">
                                                        <div class="form-group">
                                                            <label>To*</label>
                                                            <select id="country9" name ="country9" class="custom-select form-control">
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 col-lg-4 col-xl-4 col-12">
                                                        <div class="form-group">
                                                            <label>Depart on*</label>
                                                            <div class="input-group margin-bottom-sm">
                                                                <input type="text" value="10/24/1984" id="picker5" name="picker" class="form-control" required>
                                                                <div class="input-group-append">
                                                                    <span class="input-group-text"><i class="fa fa-calendar fa-fw"></i></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 col-lg-3 col-xl-3 col-12">
                                                        <div class="form-group">
                                                            <label>Adult*</label>
                                                            <select id="selectAdult" name="selectAdult" class="custom-select form-control">
                                                                <option value="">12+yr</option>
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                                <option value="5">5</option>
                                                                <option value="6">6</option>
                                                                <option value="7">7</option>
                                                                <option value="8">8</option>
                                                                <option value="9">9</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 col-lg-3 col-xl-3 col-12">
                                                        <div class="form-group">
                                                            <label>Children*</label>
                                                            <select id="selectChild" name="selectChild" class="custom-select form-control">
                                                                <option value="">2-11yr</option>
                                                                <option value="1">1</option>
                                                                <option value="2">2</option>
                                                                <option value="3">3</option>
                                                                <option value="4">4</option>
                                                                <option value="5">5</option>
                                                                <option value="6">6</option>
                                                                <option value="7">7</option>
                                                                <option value="8">8</option>
                                                                <option value="9">9</option>
                                                                <option value="10">10</option>
                                                                <option value="11">11</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 col-lg-3 col-xl-3 col-12">
                                                        <div class="form-group">
                                                            <label>Infants*</label>
                                                            <select id="selectInfant" name="selectInfant" class="custom-select form-control">
                                                                <option value="">Below 2yr</option>
                                                                <option value="1">0</option>
                                                                <option value="2">1</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-12 col-lg-3 col-xl-3 col-12">
                                                        <div class="form-group">
                                                            <label>Class of Travel</label>
                                                            <select id="selectClass" name="selectClass" class="custom-select form-control">
                                                                <option value="">Economy</option>
                                                                <option value="1">Business</option>
                                                                <option value="2">First</option>
                                                                <option value="3">Premium Economy</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="buttonDiv float-right">
                                                    <input type="submit" name="submit" Value="Search Flights" class="submitButton">
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>                       
                           <div class="tab-pane fade" id="hotel" role="tabpanel" aria-labelledby="hotel-tab">
                            <h3>Search for Hotels</h3>
                            <p>Over 600,000 hotels around the world</p>
                             <h6 class="flashDiv"><strong>Flash Sale:</strong> Grab the lowest airfares starting at Rs.999. Hurry, book now.</h6>
                            <div class="hotelSearch">
                                <form id="hotelForm">
                                    <div class="row">
                                        <div class="col-md-12 col-lg-12 col-xl-12 col-12">
                                             <label>Where*</label>
                                            <div class="form-group">
                                               <input type="text" placeholder="Enter Locality, Landmark, City or Hotel" id="selectCity" name="selectCity" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-12 col-lg-6 col-xl-6 col-12">
                                            <div class="form-group">
                                                <label>Check In*</label>
                                                <div class="input-group margin-bottom-sm">
                                                    <input type="text" value="10/24/1984" id="picker6" name="picker" class="form-control" required>
                                                    <div class="input-group-append">
                                                        <span class="input-group-text"><i class="fa fa-calendar fa-fw"></i></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12 col-lg-6 col-xl-6 col-12">
                                            <div class="form-group">
                                                <label>Check Out*</label>
                                                <div class="input-group margin-bottom-sm">
                                                    <input type="text" value="10/24/1984" id="picker7" name="picker" class="form-control" required>
                                                    <div class="input-group-append">
                                                        <span class="input-group-text"><i class="fa fa-calendar fa-fw"></i></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-group">
                                                <label>Travellers</label>
                                                <select id="travelRoom" name="travelRoom" class="custom-select form-control">
                                                    <option value="">Select</option>
                                                    <option value="1">1 Room, 1 Adults</option>
                                                    <option value="2">1 Room, 2 Adults</option>
                                                    <option value="3">2 Room, 4 Adults</option>
                                                    <option value="4">2 Room, 8 Adults</option>
                                                    <option value="5">More Travellers</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="buttonDiv float-right">
                                        <input type="submit" name="submit" value="Search Hotels" class="submitButton">
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="train" role="tabpanel" aria-labelledby="train-tab">
                            <h3>Search trains</h3>
                            <p>Indian Railways IRCTC Train Tickets Reservation</p>
                             <h6 class="flashDiv"><strong>Flash Sale:</strong> Grab the lowest airfares starting at Rs.999. Hurry, book now.</h6>
                            <div class="hotelSearch">
                                <form id="trainForm">
                                    <div class="row">
                                        <div class="col-md-12 col-lg-6 col-xl-6 col-12">
                                            <div class="form-group">
                                                <label>From *</label>
                                                <input type="text" placeholder="Enter a City or Station" id="selectStation" name="selectStation" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-12 col-lg-6 col-xl-6 col-12">
                                            <div class="form-group">
                                                <label>To *</label>
                                                <input type="text" placeholder="Enter a City or Station" id="selectStation1" name="selectStation1" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-md-12 col-lg-6 col-xl-6 col-12">
                                            <div class="form-group">
                                                <label>Class</label>
                                                <select id="trainClass" name="trainClass" class="custom-select form-control">
                                                    <option value="">Select Class</option>
                                                    <option value="1">AC First Class (1A)</option>
                                                    <option value="2">AC 2 Tier (2A)</option>
                                                    <option value="3">AC 3 Tier (3A)</option>
                                                    <option value="4">AC 3 Economy (3E)</option>
                                                    <option value="5">Exec, Chair Car (EC)</option>
                                                    <option value="6">AC Chair Car (CC)</option>
                                                    <option value="7">First Class (FC)</option>
                                                    <option value="8">Sleeper (SL)</option>
                                                    <option value="9">Second Sitting (2S)</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-12 col-lg-6 col-xl-6 col-12">
                                            <div class="form-group">
                                                <label>Check Out*</label>
                                                <div class="input-group margin-bottom-sm">
                                                    <input type="text" value="10/24/1984" id="picker10" name="picker" class="form-control" required>
                                                    <div class="input-group-append">
                                                        <span class="input-group-text"><i class="fa fa-calendar fa-fw"></i></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row hiddenDiv1">
                                            <div class="col-md-12 col-lg-3 col-xl-3 col-12">
                                                <div class="form-group">
                                                    <label>Adults*</label>
                                                    <select id="trainAdults" name="trainAdults" class="custom-select form-control">
                                                        <option value="">12-60yr</option>
                                                        <option value="1">1</option>
                                                        <option value="2">2</option>
                                                        <option value="3">3</option>
                                                        <option value="4">4</option>
                                                        <option value="5">5</option>
                                                        <option value="6">6</option>
                                                        <option value="7">7</option>
                                                        <option value="8">8</option>
                                                        <option value="9">9</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-3 col-xl-3 col-12">
                                                <div class="form-group">
                                                    <label>Children*</label>
                                                    <select id="trainChild" name="trainChild" class="custom-select form-control">
                                                        <option value="">5-11yr</option>
                                                        <option value="1">1</option>
                                                        <option value="2">2</option>
                                                        <option value="3">3</option>
                                                        <option value="4">4</option>
                                                        <option value="5">5</option>
                                                        <option value="6">6</option>
                                                        <option value="7">7</option>
                                                        <option value="8">8</option>
                                                        <option value="9">9</option>
                                                        <option value="10">10</option>
                                                        <option value="11">11</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-3 col-xl-3 col-12">
                                                <div class="form-group">
                                                    <label>Senior Men*</label>
                                                    <select id="trainSenior" name="trainSenior" class="custom-select form-control">
                                                        <option value="">60+yr</option>
                                                        <option value="1">1</option>
                                                        <option value="2">2</option>
                                                        <option value="3">3</option>
                                                        <option value="4">4</option>
                                                        <option value="5">5</option>
                                                        <option value="6">6</option>
                                                        <option value="7">7</option>
                                                        <option value="8">8</option>
                                                        <option value="9">9</option>
                                                        <option value="10">10</option>
                                                        <option value="11">11</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-12 col-lg-3 col-xl-3 col-12">
                                                <div class="form-group">
                                                    <label>Senior Women*</label>
                                                    <select id="trainWomen" name="trainWomen" class="custom-select form-control">
                                                        <option value="">58+yr</option>
                                                        <option value="1">1</option>
                                                        <option value="2">2</option>
                                                        <option value="3">3</option>
                                                        <option value="4">4</option>
                                                        <option value="5">5</option>
                                                        <option value="6">6</option>
                                                        <option value="7">7</option>
                                                        <option value="8">8</option>
                                                        <option value="9">9</option>
                                                        <option value="10">10</option>
                                                        <option value="11">11</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="buttonDiv float-right">
                                      <input type="submit" name="submit" value="Search Trains" class="submitButton">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="dealsDiv text-center">
                        <h2><img src="assets/images/inner/Deals.png" alt="Deals">Hot Deals</h2>
                        <a href="">Grab 10% cashback:</a>
                        <div id="myCarousel" class="carousel slide bg-inverse ml-auto mr-auto" data-ride="carousel">
                            <ol class="carousel-indicators">
                                <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                                <li data-target="#myCarousel" data-slide-to="1"></li>
                                <li data-target="#myCarousel" data-slide-to="2"></li>
                            </ol>
                            <div class="carousel-inner" role="listbox">
                                <div class="carousel-item active">
                                    <img class="d-block w-100" src="assets/images/inner/back.jpg" alt="First slide">
                                    <div class="carousel-caption">
                                        <p>Flight Special! Up to Rs.1,500 Cashback on Domestic Flight Bookings. Use Coupon Code CT2020.</p>
                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <img class="d-block w-100" src="assets/images/inner/back.jpg" alt="First slide">
                                    <div class="carousel-caption">
                                        <p>Book Cleartrip Activities, Flights & Hotels with Airtel Payments Bank! Avail maximum cashback upto Rs.250/-</p>
                                    </div>
                                </div>
                                <div class="carousel-item">
                                    <img class="d-block w-100" src="assets/images/inner/back.jpg" alt="First slide">
                                    <div class="carousel-caption">
                                        <p>Grab 10% Instant Cashback on Domestic Hotels. Use Coupon Code CT2020.</p>
                                    </div>
                                </div>
                            </div>
                            <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    The Modal
    <div class="modal" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Get a Cleartrip Account</h4>
                    <button type="button" class="close" data-dismiss="modal"><i class="fa fa-times" aria-hidden="true"></i></button>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                    <button type="button" class="registerfb" onclick="window.location.href = 'https://www.facebook.com/';"><i class="fa fa-facebook" aria-hidden="true"></i>Sign up with Facebook</button>

                    <form id="loginForm">
                        <div class="container">
                            <p>or, Sign up with your current email address</p>
                            <hr>
                            <label><b>Email</b></label>
                            <input type="email" class="textBox" placeholder="Enter Email" name="email" required>

                            <label><b>Password</b></label>
                            <input type="password" class="textBox" placeholder="Enter Password" name="psw" required>

                            <label><b>Repeat Password</b></label>
                            <input type="password" class="textBox" placeholder="Repeat Password" name="psw-repeat" required>
                            <hr>
                            <p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>
                            <button type="submit" class="registerbtn">Create Account</button>
                        </div>

                        <div class="container signin">
                            <p>Already have an account? <a href="#">Sign in</a>.</p>
                        </div>
                    </form>
                </div>
                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="myModal1">
        <div class="modal-dialog">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Sign in to Cleartrip</h4>
                    <button type="button" class="close" data-dismiss="modal"><i class="fa fa-times" aria-hidden="true"></i></button>
                </div>
                <!-- Modal body -->
                <div class="modal-body">
                    <button type="button" class="registerfb"><i class="fa fa-facebook" aria-hidden="true">
                   </i>Sign in with Facebook</button>
                    <form>
                        <div class="container">
                            <p>or Log in with your Cleartrip account</p>
                            <hr>
                            <label><b>Email</b></label>
                            <input type="email" class="textBox" placeholder="Enter Email" name="email" required>
                            <label><b>Password</b></label>
                            <input type="password" class="textBox" placeholder="Enter Password" name="psw" required>
                            <hr>
                            <p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>
                            <button type="submit" class="registerbtn">Sign in</button>
                        </div>
                        <div class="container signin">
                            <p>Don’t have a Cleartrip Account? <a href="" data-toggle="modal" data-target="#myModal">Sign Up</a>.</p>
                        </div>
                    </form>
                </div>
                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!--start footer-->
    <footer class="page-footer font-small mdb-color pt-2">
        <div class="container">
            <div class="row">
                <div class="col-lg-9 col-md-8 col-12">
                    <!--Copyright-->
                    <p class="text-md-left">© 2020 Copyright :
                        <a href="http://travjury.com">
                            <strong> Travel Agents</strong>
                        </a>Powered By Travjury
                    </p>
                </div>
                <div class="col-lg-3 col-md-4 col-12 foot-social">
                    connect
                    <a class="social-footer" href="https://www.facebook.com/travjurys" target="_blank">
                        <i class="fa fa-facebook"></i>
                    </a>
                    <a class="social-footer" href="https://twitter.com/travjuryS" target="_blank">
                        <i class="fa fa-twitter"></i>
                    </a>
                    <a class="social-footer" href="https://www.linkedin.com/company/travjury-software-pvt-ltd" target="_blank">
                        <i class="fa fa-linkedin"></i>
                    </a>
                    <a class="social-footer" href="https://in.pinterest.com/travjurysoftware/?autologin=true" target="_blank">
                        <i class="fa fa-pinterest-p" aria-hidden="true"></i>
                    </a>
                </div>
            </div>
        </div>
    </footer>
    <!--End footer-->
    <script src="assets/js/jquery-3.4.1.js"></script>
    <script src="assets/js/jquery.validate.min.js"></script>
    <script  src="assets/js/countries.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/custom-dynamic.js"></script>
    <script src="assets/js/validate.js"></script>
    <script src="calenplugin/js/moment.min.js"></script>
    <script src="calenplugin/js/daterangepicker.min.js"></script>
    <script src="calenplugin/js/select.js"></script>
</body>
</html>