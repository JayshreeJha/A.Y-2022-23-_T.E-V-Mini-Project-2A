import React from "react";
import "./Contact.css";
import { Button } from "@material-ui/core";

const Contact = () => {
  return (
    <div className="contactContainer">
      <a className="mailBtn" href="mailto:yashumredkar0245@hotmail.com">
        <Button>Contact: yashumredkar0245@hotmail.com</Button>
      </a>
    </div>
  );
};

export default Contact;
